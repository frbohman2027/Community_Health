/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import {
  HeartPulse,
  Languages,
  FileText,
  Phone,
  AlertTriangle,
  ZoomIn,
  ZoomOut,
  Type,
  Moon,
  Sun,
  Info,
  CheckCircle2,
  HelpCircle,
  PhoneCall,
  Headphones,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  MapPin,
  ShieldCheck,
  Building2,
  Pill,
  MessageSquare,
  Bus,
  UserCheck,
  Globe2,
  Lock,
  GraduationCap,
  Users,
  HandHeart,
  HeartHandshake,
  ArrowDown,
  Briefcase,
  FolderKanban,
} from 'lucide-react';
import {
  StateCode,
  LanguageCode,
  HospitalMessage,
  Hospital,
  InterpreterRequest,
  CommunityResource,
  PatientSharingPreferences,
  UserAppSectionRole,
} from './types';
import {
  PLACEHOLDER_COUNTIES,
  PLACEHOLDER_HOSPITALS,
  PLACEHOLDER_PHARMACIES,
  getPharmaciesForCounty,
} from './data/placeholderData';
import { getCommunityResourcesForCounty } from './data/communityResourcesData';
import { TRANSLATIONS } from './utils/translations';
import { DisclaimerBanner } from './components/DisclaimerBanner';
import { LanguageSelector } from './components/LanguageSelector';
import { CountySelectionSection } from './components/CountySelectionSection';
import { InsuranceSection } from './components/InsuranceSection';
import { MedicaidHHASection } from './components/MedicaidHHASection';
import { NeedHelpSection } from './components/NeedHelpSection';
import { PharmacySection } from './components/PharmacySection';
import { CommunitySupportSection } from './components/CommunitySupportSection';
import { HospitalMessaging } from './components/HospitalMessaging';
import { CommunityVolunteerSection } from './components/CommunityVolunteerSection';
import { CaseManagerSection } from './components/CaseManagerSection';
import { EmploymentSection } from './components/EmploymentSection';
import { CallAndTalkModal } from './components/CallAndTalkModal';
import { PatientPrivacyEquityModal } from './components/PatientPrivacyEquityModal';

export default function App() {
  // 1. Language State: Choice of language (en, es, de, my, fr, vi, zh, ar)
  const [lang, setLang] = useState<LanguageCode>('en');

  // Text size option for arm's length readability on phones with localStorage persistence
  const [isLargeText, setIsLargeText] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('wellness_large_text');
      if (saved !== null) {
        return saved === 'true';
      }
    }
    return false;
  });

  useEffect(() => {
    if (isLargeText) {
      document.documentElement.classList.add('large-text');
      document.body.classList.add('large-text');
      localStorage.setItem('wellness_large_text', 'true');
    } else {
      document.documentElement.classList.remove('large-text');
      document.body.classList.remove('large-text');
      localStorage.setItem('wellness_large_text', 'false');
    }
  }, [isLargeText]);

  // Dark mode state with persistence in localStorage and system preference detection
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('wellness_dark_mode');
      if (saved !== null) {
        return saved === 'true';
      }
      return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
      localStorage.setItem('wellness_dark_mode', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
      localStorage.setItem('wellness_dark_mode', 'false');
    }
  }, [isDarkMode]);

  // Interpreter request state (User Request: "for the language portion add need an interpreter")
  const [interpreterRequest, setInterpreterRequest] = useState<InterpreterRequest>({
    needed: false,
    language: 'Spanish',
    format: 'video_or_phone',
  });

  // 2. State selection & County dropdown (IN, KY, OH, IL)
  const [selectedState, setSelectedState] = useState<StateCode | 'ALL'>('IN');
  const [selectedCountyCode, setSelectedCountyCode] = useState<string>('IN-MONROE');

  // Choice of insurance
  const [selectedInsuranceId, setSelectedInsuranceId] = useState<string>('uninsured');

  // 4. Pharmacy selection
  const localPharmacies = useMemo(
    () => getPharmaciesForCounty(selectedCountyCode),
    [selectedCountyCode]
  );
  const [selectedPharmacyId, setSelectedPharmacyId] = useState<string>(() => {
    const initialLocal = getPharmaciesForCounty('IN-MONROE');
    return initialLocal[0]?.id || 'pharm-in-monroe-1';
  });

  // Automatically ensure the selected pharmacy belongs to the chosen county
  useEffect(() => {
    if (localPharmacies.length > 0) {
      if (!localPharmacies.some((p) => p.id === selectedPharmacyId)) {
        setSelectedPharmacyId(localPharmacies[0].id);
      }
    }
  }, [selectedCountyCode, localPharmacies, selectedPharmacyId]);

  // Community care messaging state
  const [messages, setMessages] = useState<HospitalMessage[]>([
    {
      id: 'welcome-msg',
      sender: 'hospital',
      text: 'Hello from your community health & volunteer help desk. If you need assistance finding free clinics, food deliveries, rides, or connecting with Medicaid in-home family caregivers, feel free to send us a message here.',
      timestamp: 'Today at 8:00 AM',
      category: 'Community Welcome',
    },
  ]);

  // Modal for Call & Talk
  const [isCallModalOpen, setIsCallModalOpen] = useState(false);

  const t = TRANSLATIONS[lang];

  // Helper objects
  const currentPharmacy =
    localPharmacies.find((p) => p.id === selectedPharmacyId) ||
    PLACEHOLDER_PHARMACIES.find((p) => p.id === selectedPharmacyId) ||
    localPharmacies[0] ||
    PLACEHOLDER_PHARMACIES[0];
  const currentCounty =
    PLACEHOLDER_COUNTIES.find((c) => c.code === selectedCountyCode) ||
    PLACEHOLDER_COUNTIES[0];

  // CommunityRx: Social Needs Navigation Resources for chosen county
  const communityResources = useMemo(
    () => getCommunityResourcesForCounty(currentCounty.name, currentCounty.state),
    [currentCounty.name, currentCounty.state]
  );

  const [selectedResourceIds, setSelectedResourceIds] = useState<string[]>([]);

  const handleToggleResource = (id: string) => {
    setSelectedResourceIds((prev) =>
      prev.includes(id) ? prev.filter((r) => r !== id) : [...prev, id]
    );
  };

  // Active Section Role: 'in_need_of_help' | 'case_manager' | 'wanting_employment' | 'wanting_help'
  const [activeRole, setActiveRole] = useState<UserAppSectionRole>('in_need_of_help');

  // Patient Voice & Granular Sharing Controls (Hartzler et al., 2023)
  const [sharingPreferences, setSharingPreferences] = useState<PatientSharingPreferences>({
    shareAssistanceNeeds: true,
    shareInsuranceStatus: true,
    shareTransportationNeeds: true,
    shareFoodAssistanceNeeds: true,
    shareClinicalNotes: true,
  });

  const handleToggleSharingPref = (key: keyof PatientSharingPreferences) => {
    setSharingPreferences((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  // Patient Privacy & Health Equity Modal (SDG 3.8, Alhammad et al., Antonio et al.)
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false);

  const handleClearAllData = () => {
    setSelectedResourceIds([]);
    setMessages([
      {
        id: `reset-${Date.now()}`,
        sender: 'hospital',
        text: 'All your previously stored local health selections, notes, and community requests have been cleared from your browser.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        category: 'Privacy Reset',
      },
    ]);
  };

  const handleSendMessage = (text: string, category: string) => {
    const userMsg: HospitalMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      category,
    };

    setMessages((prev) => [...prev, userMsg]);

    // Simulated reassuring community response in plain 8th-grade language
    setTimeout(() => {
      let replyText =
        'Thank you for reaching out. Our community health workers and volunteer care desk have received your message.';
      if (category.toLowerCase().includes('insurance') || category.toLowerCase().includes('sliding') || category.toLowerCase().includes('clinic')) {
        replyText =
          'We received your question regarding community clinic access and coverage. You do not need health insurance to receive care. A community care counselor will assist you with free clinic support.';
      } else if (category.toLowerCase().includes('volunteer') || category.toLowerCase().includes('help')) {
        replyText =
          'We noted your volunteer request. A local community helper or student volunteer will be matched to assist you with vital checks, companion visits, or pharmacy pickup.';
      } else if (category.toLowerCase().includes('medicaid') || category.toLowerCase().includes('caregiver')) {
        replyText =
          'We received your Medicaid in-home care question. Our waiver coordinator will provide details on local home health aides and family paid caregiver enrollment.';
      } else {
        replyText =
          'We received your health note. If you or a family member has severe chest pain, shortness of breath, or emergency symptoms, call 911 immediately. Otherwise, a community health volunteer or nurse will review your note shortly.';
      }

      const replyMsg: HospitalMessage = {
        id: `hosp-${Date.now()}`,
        sender: 'hospital',
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        category: 'Staff Reply',
      };
      setMessages((prev) => [...prev, replyMsg]);
    }, 750);
  };

  // Horizontal menu scroll and drag state for the menu under "Wellness Online"
  const menuScrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);
  const [isMouseDown, setIsMouseDown] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeftPos, setScrollLeftPos] = useState(0);
  const [hasDragged, setHasDragged] = useState(false);

  const checkMenuScroll = useCallback(() => {
    if (menuScrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = menuScrollRef.current;
      const maxScroll = scrollWidth - clientWidth;
      setCanScrollLeft(scrollLeft > 6);
      setCanScrollRight(maxScroll > 6 && scrollLeft < maxScroll - 6);
    }
  }, []);

  useEffect(() => {
    checkMenuScroll();
    const t1 = setTimeout(checkMenuScroll, 100);
    const t2 = setTimeout(checkMenuScroll, 350);
    const t3 = setTimeout(checkMenuScroll, 1000);

    const handleResize = () => checkMenuScroll();
    window.addEventListener('resize', handleResize);

    const el = menuScrollRef.current;
    let resizeObserver: ResizeObserver | null = null;
    if (el && typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(() => checkMenuScroll());
      resizeObserver.observe(el);
    }

    // Wheel listener to translate vertical wheel into horizontal scroll
    const onWheel = (e: WheelEvent) => {
      if (el && el.scrollWidth > el.clientWidth) {
        if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
          e.preventDefault();
          el.scrollLeft += e.deltaY;
          checkMenuScroll();
        }
      }
    };

    if (el) {
      el.addEventListener('wheel', onWheel, { passive: false });
    }

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      window.removeEventListener('resize', handleResize);
      resizeObserver?.disconnect();
      if (el) {
        el.removeEventListener('wheel', onWheel);
      }
    };
  }, [checkMenuScroll]);

  const scrollMenu = (direction: 'left' | 'right') => {
    if (menuScrollRef.current) {
      menuScrollRef.current.scrollBy({
        left: direction === 'left' ? -280 : 280,
        behavior: 'smooth',
      });
      setTimeout(checkMenuScroll, 350);
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!menuScrollRef.current) return;
    setIsMouseDown(true);
    setHasDragged(false);
    setStartX(e.pageX - menuScrollRef.current.offsetLeft);
    setScrollLeftPos(menuScrollRef.current.scrollLeft);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDown || !menuScrollRef.current) return;
    e.preventDefault();
    const x = e.pageX - menuScrollRef.current.offsetLeft;
    const walk = (x - startX) * 1.5;
    if (Math.abs(walk) > 4) {
      setHasDragged(true);
    }
    menuScrollRef.current.scrollLeft = scrollLeftPos - walk;
    checkMenuScroll();
  };

  const handleMouseUpOrLeave = () => {
    setIsMouseDown(false);
    // Brief timeout so clicking a button after a drag gesture doesn't trigger the click
    setTimeout(() => {
      setHasDragged(false);
    }, 60);
  };

  const handleClickCapture = (e: React.MouseEvent) => {
    if (hasDragged) {
      e.stopPropagation();
      e.preventDefault();
    }
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div
      className={`min-h-screen bg-[#F8FAFB] text-coffee-bean font-sans transition-all w-full max-w-full overflow-x-hidden relative ${
        isLargeText ? 'text-lg sm:text-xl' : 'text-base'
      }`}
    >
      {/* Top Visible Disclaimer Banner */}
      <DisclaimerBanner lang={lang} />

      {/* Main App Bar / Header */}
      <header className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-pale-sky/80 dark:border-slate-800 sticky top-0 z-40 shadow-[0_2px_10px_-3px_rgba(25,21,22,0.04)] w-full max-w-full">
        {/* Top Branding Row */}
        <div className="max-w-4xl mx-auto px-3 sm:px-6 py-2.5 sm:py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-seaweed-light text-seaweed border border-seaweed/30 flex items-center justify-center shadow-2xs shrink-0">
              <HeartPulse className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h1 className="text-base sm:text-xl font-bold tracking-tight text-coffee-bean dark:text-slate-100 truncate">
                {t.appName}
              </h1>
              <p className="text-xs text-coffee-bean-muted dark:text-slate-400 hidden sm:block font-medium">
                {t.appTagline}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Jump to bottom button if interested in helping community members for experience */}
            <button
              type="button"
              id="top-jump-to-bottom-btn"
              onClick={() => scrollToSection('community-volunteers-section')}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/60 dark:hover:bg-purple-900/60 text-purple-800 dark:text-purple-300 border border-purple-300 dark:border-purple-800 text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all shadow-2xs active:scale-95 cursor-pointer"
              title="Interested in helping community members for experience? Jump to bottom"
            >
              <GraduationCap className="w-4 h-4 text-purple-600 dark:text-purple-400 shrink-0" />
              <span className="hidden lg:inline text-purple-700 dark:text-purple-300 font-semibold">Help for Experience:</span>
              <span className="font-extrabold flex items-center gap-0.5 text-purple-800 dark:text-purple-200">
                <span>Jump to Bottom</span>
                <span className="text-purple-600 dark:text-purple-400">↓</span>
              </span>
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* HORIZONTALLY SCROLLABLE MENU UNDER "WELLNESS ONLINE"                      */}
        {/* Allows users to slide/move sideways to see all controls & sections       */}
        {/* ========================================================================= */}
        <div
          id="wellness-online-horizontal-menu-wrapper"
          className="relative border-t border-pale-sky/50 dark:border-slate-800 bg-slate-50/95 dark:bg-slate-900/95 w-full select-none"
        >
          <div className="max-w-4xl mx-auto relative flex items-center px-1 sm:px-3 py-1.5">
            {/* Scroll arrow Left */}
            <button
              type="button"
              id="menu-scroll-left-btn"
              onClick={() => scrollMenu('left')}
              disabled={!canScrollLeft}
              aria-label="Scroll menu to the left"
              className={`shrink-0 z-20 w-8 h-8 rounded-full bg-white dark:bg-slate-800 shadow-sm border border-pale-sky dark:border-slate-700 flex items-center justify-center text-seaweed hover:bg-seaweed-light hover:border-seaweed transition-all cursor-pointer mr-1 sm:mr-2 ${
                canScrollLeft
                  ? 'opacity-100 scale-100'
                  : 'opacity-20 pointer-events-none scale-90'
              }`}
              title="Move left to previous options"
            >
              <ChevronLeft className="w-5 h-5 text-seaweed" />
            </button>

            {/* Left gradient fade indicator when scrollable left */}
            {canScrollLeft && (
              <div className="pointer-events-none absolute left-10 sm:left-12 top-0 bottom-0 w-6 bg-gradient-to-r from-slate-50 dark:from-slate-900 to-transparent z-10" />
            )}

            {/* Horizontally scrollable track */}
            <div
              id="wellness-online-horizontal-menu"
              ref={menuScrollRef}
              onScroll={checkMenuScroll}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUpOrLeave}
              onMouseLeave={handleMouseUpOrLeave}
              onClickCapture={handleClickCapture}
              className={`w-full overflow-x-auto flex items-center gap-1.5 sm:gap-2 py-1 scroll-smooth overscroll-x-contain touch-pan-x flex-nowrap scrollbar-thin scrollbar-thumb-seaweed/30 hover:scrollbar-thumb-seaweed/60 scrollbar-track-transparent ${
                isMouseDown ? 'cursor-grabbing' : 'cursor-grab'
              }`}
              style={{ WebkitOverflowScrolling: 'touch' }}
            >

              {/* Ability to Call & Talk directly to clinic nurse */}
              <button
                type="button"
                id="top-call-and-talk-btn"
                onClick={() => {
                  setIsCallModalOpen(true);
                }}
                className="shrink-0 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-pale-sky-light dark:hover:bg-slate-700 text-seaweed-dark dark:text-seaweed-light border border-seaweed/40 text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-all shadow-2xs active:scale-95 cursor-pointer whitespace-nowrap"
                title="Call and talk directly with clinic team"
              >
                <PhoneCall className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-seaweed" />
                <span>{t.callAndTalk || 'Call & Talk'}</span>
              </button>

              {/* Arm's length text size toggle */}
              <button
                type="button"
                id="text-size-toggle-btn"
                onClick={() => setIsLargeText(!isLargeText)}
                title="Toggle larger text and buttons for easy reading on phone at arm's length"
                aria-pressed={isLargeText}
                className={`shrink-0 px-3 py-1.5 rounded-xl border text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs active:scale-95 whitespace-nowrap ${
                  isLargeText
                    ? 'bg-seaweed text-white border-seaweed ring-2 ring-seaweed/30 shadow-xs'
                    : 'bg-white dark:bg-slate-800 hover:bg-pale-sky-light dark:hover:bg-slate-700 text-coffee-bean dark:text-slate-100 border-pale-sky dark:border-slate-700'
                }`}
              >
                <Type className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
                <span className="font-extrabold text-[11px] sm:text-xs tracking-tight bg-black/10 dark:bg-white/15 px-1 py-0.2 rounded">
                  Aa+
                </span>
                <span>{isLargeText ? 'Text: Large (Active)' : (t.largeText || 'Larger Text')}</span>
              </button>

              {/* Dark Mode Toggle Button */}
              <button
                type="button"
                id="dark-mode-toggle-btn"
                onClick={() => setIsDarkMode(!isDarkMode)}
                title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
                aria-label={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
                className={`shrink-0 px-2.5 py-1.5 rounded-xl border text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
                  isDarkMode
                    ? 'bg-seaweed-light text-seaweed border-seaweed shadow-2xs'
                    : 'bg-white dark:bg-slate-800 hover:bg-pale-sky-light dark:hover:bg-slate-700 text-coffee-bean dark:text-slate-100 border-pale-sky dark:border-slate-700 shadow-2xs'
                }`}
              >
                {isDarkMode ? (
                  <Sun className="w-4 h-4 text-neon-ice" />
                ) : (
                  <Moon className="w-4 h-4 text-coffee-bean" />
                )}
                <span>{isDarkMode ? 'Light' : 'Dark'}</span>
              </button>

              {/* Language Selector in Header */}
              <div className="shrink-0">
                <LanguageSelector
                  currentLang={lang}
                  onSelectLang={setLang}
                  variant="header"
                  interpreterRequest={interpreterRequest}
                  onInterpreterChange={setInterpreterRequest}
                />
              </div>

              {/* Role Switcher in Header Menu */}
              <div className="shrink-0 flex items-center bg-slate-200/80 dark:bg-slate-800 p-0.5 rounded-xl border border-slate-300 dark:border-slate-700">
                <button
                  type="button"
                  id="role-nav-in-need-of-help"
                  onClick={() => setActiveRole('in_need_of_help')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                    activeRole === 'in_need_of_help'
                      ? 'bg-seaweed text-white shadow-2xs'
                      : 'text-coffee-bean dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700'
                  }`}
                  title="In Need of Help: Free clinics, food, rides, care"
                >
                  <HeartHandshake className="w-3.5 h-3.5" />
                  <span>In Need of Help</span>
                </button>
                <button
                  type="button"
                  id="role-nav-case-manager"
                  onClick={() => setActiveRole('case_manager')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                    activeRole === 'case_manager'
                      ? 'bg-seaweed text-white shadow-2xs'
                      : 'text-coffee-bean dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700'
                  }`}
                  title="Case Manager Account: View client caseload & personal info"
                >
                  <FolderKanban className="w-3.5 h-3.5" />
                  <span>Case Manager</span>
                  <Lock className="w-2.5 h-2.5 text-neon-ice" />
                </button>
                <button
                  type="button"
                  id="role-nav-wanting-employment"
                  onClick={() => setActiveRole('wanting_employment')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                    activeRole === 'wanting_employment'
                      ? 'bg-seaweed text-white shadow-2xs'
                      : 'text-coffee-bean dark:text-slate-300 hover:bg-white dark:hover:bg-slate-700'
                  }`}
                  title="Wanting Employment: Medicaid Paid Caregiver jobs ($15–$22/hr)"
                >
                  <Briefcase className="w-3.5 h-3.5" />
                  <span>Employment</span>
                </button>
                <button
                  type="button"
                  id="role-nav-wanting-help"
                  onClick={() => setActiveRole('wanting_help')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                    activeRole === 'wanting_help'
                      ? 'bg-purple-700 text-white shadow-2xs'
                      : 'text-purple-800 dark:text-purple-300 hover:bg-white dark:hover:bg-slate-700'
                  }`}
                  title="Wanting to Help: Student & community volunteer opportunities"
                >
                  <GraduationCap className="w-3.5 h-3.5 text-purple-400" />
                  <span>Wanting to Help</span>
                </button>
              </div>

              {/* Privacy & SDG 3.8 Health Equity Button */}
              <button
                type="button"
                id="top-privacy-equity-btn"
                onClick={() => setIsPrivacyModalOpen(true)}
                className="shrink-0 px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-pale-sky-light dark:hover:bg-slate-700 text-coffee-bean dark:text-slate-100 border border-pale-sky dark:border-slate-700 text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer whitespace-nowrap"
                title="Patient Privacy, Autonomy & UN SDG 3.8 Health Equity Rights"
              >
                <ShieldCheck className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-seaweed" />
                <span>Privacy & SDG 3.8</span>
              </button>

              {/* Vertical Separator */}
              <div className="h-5 w-px bg-slate-300 dark:bg-slate-700 shrink-0 mx-1" />

              {/* Section Quick Jump Buttons */}
              <button
                type="button"
                onClick={() => scrollToSection('county-selection-section')}
                className="shrink-0 px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-seaweed-light dark:hover:bg-slate-700 text-coffee-bean dark:text-slate-200 border border-pale-sky dark:border-slate-700 text-xs font-semibold flex items-center gap-1 shadow-2xs cursor-pointer whitespace-nowrap transition-colors"
              >
                <MapPin className="w-3.5 h-3.5 text-seaweed" />
                <span>1. County</span>
              </button>

              <button
                type="button"
                id="menu-jump-to-need-help"
                onClick={() => scrollToSection('need-help-section')}
                className="shrink-0 px-2.5 py-1.5 rounded-xl bg-seaweed-light/40 dark:bg-seaweed-dark/40 hover:bg-seaweed-light text-seaweed-dark dark:text-seaweed-light border border-seaweed/30 text-xs font-semibold flex items-center gap-1 shadow-2xs cursor-pointer whitespace-nowrap transition-colors"
              >
                <HeartHandshake className="w-3.5 h-3.5 text-seaweed" />
                <span>2. Assistance Needed</span>
              </button>

              <button
                type="button"
                onClick={() => scrollToSection('insurance-section')}
                className="shrink-0 px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-seaweed-light dark:hover:bg-slate-700 text-coffee-bean dark:text-slate-200 border border-pale-sky dark:border-slate-700 text-xs font-semibold flex items-center gap-1 shadow-2xs cursor-pointer whitespace-nowrap transition-colors"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-seaweed" />
                <span>3. Insurance</span>
              </button>

              {selectedInsuranceId === 'medicaid-hip' && (
                <button
                  type="button"
                  id="menu-jump-to-medicaid-hha"
                  onClick={() => scrollToSection('medicaid-hha-section')}
                  className="shrink-0 px-2.5 py-1.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 hover:bg-purple-100 text-purple-800 dark:text-purple-300 border border-purple-300 dark:border-purple-800 text-xs font-semibold flex items-center gap-1 shadow-2xs cursor-pointer whitespace-nowrap transition-colors"
                >
                  <HandHeart className="w-3.5 h-3.5 text-purple-600" />
                  <span>4. Medicaid Caregivers</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => scrollToSection('pharmacy-section')}
                className="shrink-0 px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-seaweed-light dark:hover:bg-slate-700 text-coffee-bean dark:text-slate-200 border border-pale-sky dark:border-slate-700 text-xs font-semibold flex items-center gap-1 shadow-2xs cursor-pointer whitespace-nowrap transition-colors"
              >
                <Pill className="w-3.5 h-3.5 text-seaweed" />
                <span>{selectedInsuranceId === 'medicaid-hip' ? '5. Pharmacy' : '4. Pharmacy'}</span>
              </button>

              <button
                type="button"
                onClick={() => scrollToSection('community-support-section')}
                className="shrink-0 px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-seaweed-light dark:hover:bg-slate-700 text-coffee-bean dark:text-slate-200 border border-pale-sky dark:border-slate-700 text-xs font-semibold flex items-center gap-1 shadow-2xs cursor-pointer whitespace-nowrap transition-colors"
              >
                <Bus className="w-3.5 h-3.5 text-seaweed" />
                <span>{selectedInsuranceId === 'medicaid-hip' ? '6. CommunityRx' : '5. CommunityRx'}</span>
              </button>

              <button
                type="button"
                onClick={() => scrollToSection('hospital-messaging-section')}
                className="shrink-0 px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-seaweed-light dark:hover:bg-slate-700 text-coffee-bean dark:text-slate-200 border border-pale-sky dark:border-slate-700 text-xs font-semibold flex items-center gap-1 shadow-2xs cursor-pointer whitespace-nowrap transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5 text-seaweed" />
                <span>{selectedInsuranceId === 'medicaid-hip' ? '7. Help Desk' : '6. Help Desk'}</span>
              </button>

              <button
                type="button"
                id="menu-jump-to-volunteers-btn"
                onClick={() => scrollToSection('community-volunteers-section')}
                className="shrink-0 px-2.5 py-1.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 hover:bg-purple-100 text-purple-800 dark:text-purple-300 border border-purple-300 dark:border-purple-800 text-xs font-bold flex items-center gap-1 shadow-2xs cursor-pointer whitespace-nowrap transition-colors"
              >
                <GraduationCap className="w-3.5 h-3.5 text-purple-600" />
                <span>Help for Experience ↓</span>
              </button>
            </div>

            {/* Right gradient fade indicator when scrollable right */}
            {canScrollRight && (
              <div className="pointer-events-none absolute right-10 sm:right-12 top-0 bottom-0 w-6 bg-gradient-to-l from-slate-50 dark:from-slate-900 to-transparent z-10" />
            )}

            {/* Scroll arrow Right */}
            <button
              type="button"
              id="menu-scroll-right-btn"
              onClick={() => scrollMenu('right')}
              disabled={!canScrollRight}
              aria-label="Scroll menu to the right"
              className={`shrink-0 z-20 w-8 h-8 rounded-full bg-white dark:bg-slate-800 shadow-sm border border-pale-sky dark:border-slate-700 flex items-center justify-center text-seaweed hover:bg-seaweed-light hover:border-seaweed transition-all cursor-pointer ml-1 sm:ml-2 ${
                canScrollRight
                  ? 'opacity-100 scale-100 ring-2 ring-seaweed/30'
                  : 'opacity-20 pointer-events-none scale-90 ring-0'
              }`}
              title="Move right to see the rest of the options"
            >
              <ChevronRight className="w-5 h-5 text-seaweed" />
            </button>
          </div>

          {/* Quick helper caption under horizontal bar */}
          <div className="max-w-4xl mx-auto px-4 pb-1.5 pt-0.5 flex items-center justify-between text-[11px] text-coffee-bean-muted dark:text-slate-400">
            <span className="flex items-center gap-1.5 font-medium">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-seaweed"></span>
              <span>Slide sideways, use arrows, or drag to explore all tools</span>
            </span>
            {canScrollRight && (
              <button
                type="button"
                onClick={() => scrollMenu('right')}
                className="font-bold text-seaweed hover:underline flex items-center gap-0.5 cursor-pointer text-[11px]"
              >
                <span>Move to see the rest</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </header>

      {/* High-Visibility Notice When Large Text is Active */}
      {isLargeText && (
        <aside
          id="large-text-active-banner"
          aria-label="Large text accessibility status"
          className="bg-seaweed-dark text-white text-xs sm:text-sm font-semibold px-3 sm:px-6 py-2 border-b border-seaweed shadow-xs transition-all"
        >
          <div className="max-w-4xl mx-auto flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-2">
              <span className="bg-white/20 text-white px-2 py-0.5 rounded-full font-extrabold text-[11px] uppercase tracking-wider flex items-center gap-1">
                <Type className="w-3.5 h-3.5" />
                Large Text Active
              </span>
              <span className="text-white/90 hidden sm:inline text-xs">
                All fonts, buttons, forms, and cards enlarged for easy arm&apos;s-length reading on phones.
              </span>
            </div>
            <button
              type="button"
              id="reset-text-size-btn"
              onClick={() => setIsLargeText(false)}
              className="px-2.5 py-1 rounded-lg bg-white text-seaweed-dark hover:bg-slate-100 text-xs font-bold transition-colors cursor-pointer shrink-0 shadow-2xs"
            >
              Reset to Standard Size
            </button>
          </div>
        </aside>
      )}

      {/* Main Mobile-First Content Container */}
      <main className="max-w-4xl mx-auto px-3 sm:px-6 py-5 sm:py-8 space-y-6 w-full max-w-full overflow-x-hidden">
        {/* Top Direct Action: Call and Talk with Community Care Team */}
        <div
          id="top-direct-helpline-spot"
          className="bg-gradient-to-br from-pale-sky-light via-white to-seaweed-light border border-pale-sky rounded-3xl p-5 sm:p-6 shadow-[0_2px_14px_-4px_rgba(25,21,22,0.04)] flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        >
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-seaweed text-white flex items-center justify-center shrink-0 shadow-2xs">
              <PhoneCall className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                <h2 className="font-bold text-base sm:text-lg text-coffee-bean">
                  Call & Talk with Community Care
                </h2>
                <span className="text-xs bg-seaweed-light text-seaweed-dark border border-seaweed/30 px-2.5 py-0.5 rounded-full font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-neon-ice"></span>
                  Live Clinic Desk
                </span>
                {interpreterRequest.needed && (
                  <span className="text-xs bg-pale-sky text-coffee-bean border border-pale-sky-dark/40 px-2 py-0.5 rounded-full font-semibold flex items-center gap-1">
                    <Headphones className="w-3 h-3 text-seaweed-dark" />
                    Interpreter Ready
                  </span>
                )}
              </div>
              <p className="text-xs sm:text-sm text-coffee-bean-muted leading-relaxed max-w-xl">
                Speak directly with community clinic nurses and local care coordinators to get answers, schedule appointments, and coordinate support.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto shrink-0">
            {/* Ability to call and talk */}
            <button
              type="button"
              id="top-spot-call-and-talk"
              onClick={() => {
                setIsCallModalOpen(true);
              }}
              className="w-full md:w-auto px-5 py-2.5 rounded-xl bg-seaweed hover:bg-seaweed-hover text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-2xs transition-all active:scale-95 cursor-pointer"
            >
              <PhoneCall className="w-4 h-4" />
              <span>{t.callAndTalk || 'Call & Talk'}</span>
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* WHEN APP IS FIRST OPENED: 4-SECTION ROLE PORTAL SELECTOR                   */}
        {/* In Need of Help | Case Manager | Wanting Employment | Wanting to Help     */}
        {/* ========================================================================= */}
        <section
          id="app-role-selection-portal"
          aria-label="Community Healthcare Role Selection"
          className="bg-white dark:bg-slate-900 rounded-3xl border border-pale-sky/80 dark:border-slate-800 p-5 sm:p-7 shadow-[0_2px_14px_-4px_rgba(25,21,22,0.04)] space-y-5"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-seaweed-light text-seaweed-dark text-xs font-bold border border-seaweed/30">
                  <Sparkles className="w-3.5 h-3.5 text-seaweed" />
                  Select Your Section
                </span>
                <span className="text-xs text-coffee-bean-muted dark:text-slate-400">
                  Choose who you are visiting as:
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-coffee-bean dark:text-slate-100 tracking-tight">
                How Can Community Healthcare Support You Today?
              </h2>
            </div>
            <div className="text-xs text-slate-500 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 shrink-0">
              <ShieldCheck className="w-4 h-4 text-seaweed" />
              <span>Personal records protected</span>
            </div>
          </div>

          {/* 4 Interactive Role Selection Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
            {/* 1. IN NEED OF HELP */}
            <button
              type="button"
              id="role-card-in-need-of-help"
              onClick={() => setActiveRole('in_need_of_help')}
              className={`text-left p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between relative group ${
                activeRole === 'in_need_of_help'
                  ? 'bg-seaweed-light/40 border-seaweed ring-2 ring-seaweed shadow-xs'
                  : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 hover:border-seaweed/60 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {activeRole === 'in_need_of_help' && (
                <span className="absolute top-3 right-3 text-seaweed">
                  <CheckCircle2 className="w-5 h-5 fill-seaweed text-white" />
                </span>
              )}
              <div>
                <div className="w-10 h-10 rounded-xl bg-seaweed-light text-seaweed border border-seaweed/30 flex items-center justify-center mb-3">
                  <HeartHandshake className="w-5 h-5" />
                </div>
                <div className="font-bold text-sm sm:text-base text-coffee-bean dark:text-slate-100 mb-1">
                  In Need of Help
                </div>
                <p className="text-xs text-coffee-bean-muted dark:text-slate-400 leading-relaxed mb-3">
                  Find free clinics, doorstep meals, utility help, medical rides, local pharmacies, and check insurance case management coverage.
                </p>
              </div>
              <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs font-semibold text-seaweed">
                <span>View Healthcare Resources</span>
                <span>→</span>
              </div>
            </button>

            {/* 2. CASE MANAGER ACCOUNT */}
            <button
              type="button"
              id="role-card-case-manager"
              onClick={() => setActiveRole('case_manager')}
              className={`text-left p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between relative group ${
                activeRole === 'case_manager'
                  ? 'bg-seaweed-light/40 border-seaweed ring-2 ring-seaweed shadow-xs'
                  : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 hover:border-seaweed/60 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {activeRole === 'case_manager' && (
                <span className="absolute top-3 right-3 text-seaweed">
                  <CheckCircle2 className="w-5 h-5 fill-seaweed text-white" />
                </span>
              )}
              <div>
                <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-300 dark:border-blue-800 flex items-center justify-center mb-3">
                  <FolderKanban className="w-5 h-5" />
                </div>
                <div className="font-bold text-sm sm:text-base text-coffee-bean dark:text-slate-100 mb-1 flex items-center gap-1.5">
                  <span>Case Manager</span>
                  <span className="text-[10px] bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded-full font-extrabold border border-blue-300">
                    🔒 Authorized
                  </span>
                </div>
                <p className="text-xs text-coffee-bean-muted dark:text-slate-400 leading-relaxed mb-3">
                  Confidential caseload portal. View clients&apos; full names, home addresses, phone numbers, care plans, and insurance coverage.
                </p>
              </div>
              <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs font-semibold text-blue-700 dark:text-blue-300">
                <span>Open Caseload Portal</span>
                <span>→</span>
              </div>
            </button>

            {/* 3. WANTING EMPLOYMENT */}
            <button
              type="button"
              id="role-card-wanting-employment"
              onClick={() => setActiveRole('wanting_employment')}
              className={`text-left p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between relative group ${
                activeRole === 'wanting_employment'
                  ? 'bg-seaweed-light/40 border-seaweed ring-2 ring-seaweed shadow-xs'
                  : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 hover:border-seaweed/60 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {activeRole === 'wanting_employment' && (
                <span className="absolute top-3 right-3 text-seaweed">
                  <CheckCircle2 className="w-5 h-5 fill-seaweed text-white" />
                </span>
              )}
              <div>
                <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800 flex items-center justify-center mb-3">
                  <Briefcase className="w-5 h-5" />
                </div>
                <div className="font-bold text-sm sm:text-base text-coffee-bean dark:text-slate-100 mb-1">
                  Wanting Employment
                </div>
                <p className="text-xs text-coffee-bean-muted dark:text-slate-400 leading-relaxed mb-3">
                  Medicaid Paid Family Caregiver Attendant jobs ($15–$22.50/hr), certified HHA/CNA openings, and rural medical transit driver roles.
                </p>
              </div>
              <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs font-semibold text-amber-800 dark:text-amber-300">
                <span>Browse Paid Jobs</span>
                <span>→</span>
              </div>
            </button>

            {/* 4. WANTING TO HELP */}
            <button
              type="button"
              id="role-card-wanting-help"
              onClick={() => setActiveRole('wanting_help')}
              className={`text-left p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between relative group ${
                activeRole === 'wanting_help'
                  ? 'bg-purple-100/60 dark:bg-purple-950/40 border-purple-600 ring-2 ring-purple-600 shadow-xs'
                  : 'bg-white dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 hover:border-purple-500/60 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              {activeRole === 'wanting_help' && (
                <span className="absolute top-3 right-3 text-purple-700">
                  <CheckCircle2 className="w-5 h-5 fill-purple-700 text-white" />
                </span>
              )}
              <div>
                <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-300 dark:border-purple-800 flex items-center justify-center mb-3">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div className="font-bold text-sm sm:text-base text-coffee-bean dark:text-slate-100 mb-1">
                  Wanting to Help
                </div>
                <p className="text-xs text-coffee-bean-muted dark:text-slate-400 leading-relaxed mb-3">
                  Gain clinical and patient-care experience. Volunteer for vital checks, companion visits, food pantry deliveries, and help neighbors.
                </p>
              </div>
              <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs font-semibold text-purple-700 dark:text-purple-300">
                <span>Volunteer for Experience</span>
                <span>→</span>
              </div>
            </button>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* CONDITIONAL RENDERING OF THE ACTIVE ROLE SECTION                           */}
        {/* ========================================================================= */}

        {/* SECTION FOR CASE MANAGERS */}
        {activeRole === 'case_manager' && (
          <div className="space-y-6">
            <CaseManagerSection
              lang={lang}
              countyName={currentCounty.name}
              state={currentCounty.state}
            />
            <CommunityVolunteerSection
              lang={lang}
              countyName={currentCounty.name}
              state={currentCounty.state}
              isCaseManager={true}
            />
          </div>
        )}

        {/* SECTION FOR JOB SEEKERS (WANTING EMPLOYMENT) */}
        {activeRole === 'wanting_employment' && (
          <EmploymentSection
            lang={lang}
            countyName={currentCounty.name}
            state={currentCounty.state}
          />
        )}

        {/* SECTION FOR VOLUNTEERS (WANTING TO HELP) */}
        {activeRole === 'wanting_help' && (
          <CommunityVolunteerSection
            lang={lang}
            countyName={currentCounty.name}
            state={currentCounty.state}
            isCaseManager={false}
          />
        )}

        {/* SECTION FOR CLIENTS IN NEED OF HELP (FULL PATIENT-FACING ACCESS) */}
        {activeRole === 'in_need_of_help' && (
          <div className="space-y-6">
            {/* Intro Welcome Card */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-pale-sky/80 dark:border-slate-800 p-5 sm:p-7 shadow-[0_2px_14px_-4px_rgba(25,21,22,0.04)]">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-seaweed-light text-seaweed-dark text-xs font-semibold border border-seaweed/30">
                      <Sparkles className="w-3.5 h-3.5 text-seaweed" />
                      Free Community Healthcare & Neighborhood Support
                    </span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold text-coffee-bean dark:text-slate-100 tracking-tight mb-1.5">
                    Free Community Healthcare & Neighborhood Support Network
                  </h2>
                  <p className="text-coffee-bean-muted dark:text-slate-400 text-xs sm:text-sm max-w-2xl leading-relaxed">
                    Connect with free community health clinics, certified Home Health Aides (HHA), Medicaid paid family caregiving programs, and local volunteers offering vital checks and everyday assistance.
                  </p>
                </div>
                <div className="shrink-0 bg-pale-sky-light/80 dark:bg-slate-800 border border-pale-sky dark:border-slate-700 rounded-2xl p-3.5 text-xs text-coffee-bean-muted dark:text-slate-300 max-w-xs shadow-2xs space-y-2">
                  <div>
                    <strong className="text-coffee-bean dark:text-slate-100 block mb-0.5">Want to gain experience?</strong>
                    Nursing students, pre-meds, and caring neighbors can help local families.
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveRole('wanting_help')}
                    className="w-full py-1.5 px-2 rounded-lg bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs flex items-center justify-center gap-1 transition-colors cursor-pointer"
                  >
                    <span>Go to Wanting to Help Section</span>
                    <span>→</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Choice of Language & Need an Interpreter Section */}
            <LanguageSelector
              currentLang={lang}
              onSelectLang={setLang}
              variant="banner"
              interpreterRequest={interpreterRequest}
              onInterpreterChange={setInterpreterRequest}
            />

            {/* SECTION 1: County Selection */}
            <CountySelectionSection
              lang={lang}
              selectedState={selectedState}
              onStateChange={setSelectedState}
              selectedCountyCode={selectedCountyCode}
              onCountyChange={(newCounty) => {
                setSelectedCountyCode(newCounty);
                const countyPharmacies = getPharmaciesForCounty(newCounty);
                if (countyPharmacies.length > 0) {
                  setSelectedPharmacyId(countyPharmacies[0].id);
                }
              }}
            />

            {/* SECTION 2: What Assistance Is Needed (Churches, Food Banks, Meals on Wheels, etc.) */}
            <NeedHelpSection
              lang={lang}
              countyName={currentCounty.name}
              state={currentCounty.state}
              stepNumber={2}
            />

            {/* SECTION 3: Choice of Insurance (With Case Manager Covered Check & Uninsured Options) */}
            <InsuranceSection
              lang={lang}
              selectedInsuranceId={selectedInsuranceId}
              onInsuranceChange={setSelectedInsuranceId}
            />

            {/* SECTION 4 (If Medicaid is chosen): In-Home Care & Family Attendant Program */}
            {selectedInsuranceId === 'medicaid-hip' && (
              <MedicaidHHASection
                lang={lang}
                selectedState={currentCounty.state}
                countyName={currentCounty.name}
              />
            )}

            {/* SECTION 5: Pharmacies nearby */}
            <PharmacySection
              lang={lang}
              selectedCountyCode={selectedCountyCode}
              selectedPharmacyId={selectedPharmacyId}
              onSelectPharmacy={setSelectedPharmacyId}
            />

            {/* SECTION 6: CommunityRx: Local Health & Social Needs Navigation */}
            <CommunitySupportSection
              lang={lang}
              countyName={currentCounty.name}
              state={currentCounty.state}
              resources={communityResources}
              selectedResourceIds={selectedResourceIds}
              onToggleResource={handleToggleResource}
            />

            {/* SECTION 7: Community Health & Volunteer Care Desk */}
            <HospitalMessaging
              lang={lang}
              messages={messages}
              onSendMessage={handleSendMessage}
              selectedCountyName={currentCounty.name}
            />

            {/* SECTION 8: Community Volunteers (Masked contact for privacy) */}
            <CommunityVolunteerSection
              lang={lang}
              countyName={currentCounty.name}
              state={currentCounty.state}
              isCaseManager={false}
            />
          </div>
        )}
      </main>

      {/* Footer with Visible Disclaimer */}
      <footer className="bg-coffee-bean text-slate-300 mt-12 py-8 border-t border-coffee-bean-muted w-full max-w-full overflow-x-hidden">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-coffee-bean-muted">
            <div>
              <div className="flex items-center gap-2 text-white font-bold text-base sm:text-lg">
                <HeartPulse className="w-5 h-5 text-neon-ice" />
                <span>Community Healthcare</span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Healthcare access navigator for rural communities in IN, KY, OH, and IL.
              </p>
            </div>

            <div className="flex flex-col sm:items-end gap-1.5">
              <a
                href="tel:911"
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-cherry-rose hover:bg-cherry-rose-hover text-white font-bold text-xs rounded-xl transition-colors shadow-2xs"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call 911 for Emergencies</span>
              </a>
              <span className="text-xs text-slate-400 mt-0.5">
                988 Suicide & Crisis Lifeline: Call or Text 988
              </span>
            </div>
          </div>

          {/* Mandatory visible disclaimer */}
          <div className="bg-coffee-bean-muted/70 p-4 rounded-2xl border border-coffee-bean-muted text-xs text-slate-300 space-y-2">
            <div className="font-bold text-neon-ice flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" />
              <span>Mandatory Educational Disclaimer</span>
            </div>
            <p className="leading-relaxed">
              This tool is strictly for educational purposes and is not a substitute for an emergency or all regional hospitals. It does not provide medical diagnosis, prescription writing, or clinical treatment. If you or a family member is suffering from a medical emergency, call 911 immediately.
            </p>
            <p className="text-[11px] text-slate-400 italic">
              Notice: All hospital directories, county boundaries, distances, and doctor schedules are placeholders clearly marked with TODO for cited data integration.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 text-xs text-slate-500">
            <div>&copy; 2026 Community Healthcare • Rural Healthcare Access Guide</div>
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                id="footer-privacy-btn"
                onClick={() => setIsPrivacyModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-coffee-bean-muted/60 hover:bg-coffee-bean-muted text-neon-ice border border-coffee-bean-muted text-xs transition-colors cursor-pointer"
                title="View Patient Privacy, Autonomy & UN SDG 3.8 Equity Guarantee"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-seaweed" />
                <span>Privacy & SDG 3.8 Rights</span>
              </button>
              <button
                type="button"
                id="footer-text-size-btn"
                onClick={() => setIsLargeText(!isLargeText)}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs transition-colors cursor-pointer border ${
                  isLargeText
                    ? 'bg-seaweed text-white border-seaweed font-bold'
                    : 'bg-coffee-bean-muted/60 hover:bg-coffee-bean-muted text-slate-300 border-coffee-bean-muted'
                }`}
                title="Toggle larger text for easy reading"
              >
                <Type className="w-3.5 h-3.5" />
                <span>{isLargeText ? 'Text Size: Large (Active)' : 'Text Size: Standard'}</span>
              </button>
              <button
                type="button"
                id="footer-dark-mode-btn"
                onClick={() => setIsDarkMode(!isDarkMode)}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-coffee-bean-muted/60 hover:bg-coffee-bean-muted text-slate-300 border border-coffee-bean-muted text-xs transition-colors cursor-pointer"
              >
                {isDarkMode ? <Sun className="w-3.5 h-3.5 text-neon-ice" /> : <Moon className="w-3.5 h-3.5" />}
                <span>{isDarkMode ? 'Dark Mode (Active)' : 'Light Mode (Active)'}</span>
              </button>
            </div>
          </div>
        </div>
      </footer>


      {/* Call and Talk Interactive Clinic Audio Modal */}
      <CallAndTalkModal
        isOpen={isCallModalOpen}
        onClose={() => setIsCallModalOpen(false)}
        lang={lang}
        interpreterRequest={interpreterRequest}
      />


      {/* Patient Privacy, Autonomy & UN SDG 3.8 Health Equity Modal */}
      <PatientPrivacyEquityModal
        isOpen={isPrivacyModalOpen}
        onClose={() => setIsPrivacyModalOpen(false)}
        onClearAllData={handleClearAllData}
      />
    </div>
  );
}
