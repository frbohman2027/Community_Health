import { DailyHours, PharmacyOperatingHours } from '../types';

export interface WeeklyScheduleEntry {
  dayName: string;
  dayShort: string;
  hoursText: string;
  isToday: boolean;
  isClosed: boolean;
}

export interface PharmacyStatusInfo {
  isOpen: boolean;
  statusBadgeText: string;
  timingNote: string;
  todayHoursText: string;
  weeklySchedule: WeeklyScheduleEntry[];
  summaryText: string;
}

const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const DAY_SHORTS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/**
 * Creates default, realistic operating hours for any pharmacy.
 * Provides 3 common community pharmacy patterns to ensure realism across rural areas.
 */
export function getDefaultPharmacyHours(seed: string | number): PharmacyOperatingHours {
  const numSeed = typeof seed === 'number'
    ? seed
    : seed.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);

  const pattern = Math.abs(numSeed) % 3;

  if (pattern === 0) {
    // Extended Hours Community Pharmacy (Mon-Fri 8:00 AM - 8:00 PM, Sat 9:00 AM - 5:00 PM, Sun 10:00 AM - 3:00 PM)
    const mf: DailyHours = {
      open: '8:00 AM',
      close: '8:00 PM',
      openMinutes: 8 * 60,
      closeMinutes: 20 * 60,
      isClosed: false,
    };
    const sat: DailyHours = {
      open: '9:00 AM',
      close: '5:00 PM',
      openMinutes: 9 * 60,
      closeMinutes: 17 * 60,
      isClosed: false,
    };
    const sun: DailyHours = {
      open: '10:00 AM',
      close: '3:00 PM',
      openMinutes: 10 * 60,
      closeMinutes: 15 * 60,
      isClosed: false,
    };

    return {
      mondayFriday: '8:00 AM – 8:00 PM',
      saturday: '9:00 AM – 5:00 PM',
      sunday: '10:00 AM – 3:00 PM',
      schedule: {
        0: sun,
        1: mf,
        2: mf,
        3: mf,
        4: mf,
        5: mf,
        6: sat,
      },
    };
  } else if (pattern === 1) {
    // Traditional Hometown Family Drugstore (Mon-Fri 8:30 AM - 6:30 PM, Sat 9:00 AM - 2:00 PM, Sun Closed)
    const mf: DailyHours = {
      open: '8:30 AM',
      close: '6:30 PM',
      openMinutes: 8 * 60 + 30,
      closeMinutes: 18 * 60 + 30,
      isClosed: false,
    };
    const sat: DailyHours = {
      open: '9:00 AM',
      close: '2:00 PM',
      openMinutes: 9 * 60,
      closeMinutes: 14 * 60,
      isClosed: false,
    };
    const sun: DailyHours = {
      open: 'Closed',
      close: 'Closed',
      openMinutes: 0,
      closeMinutes: 0,
      isClosed: true,
    };

    return {
      mondayFriday: '8:30 AM – 6:30 PM',
      saturday: '9:00 AM – 2:00 PM',
      sunday: 'Closed',
      schedule: {
        0: sun,
        1: mf,
        2: mf,
        3: mf,
        4: mf,
        5: mf,
        6: sat,
      },
    };
  } else {
    // Early Care Rural Apothecary & Courier (Mon-Fri 7:30 AM - 7:00 PM, Sat 8:30 AM - 4:00 PM, Sun 11:00 AM - 3:00 PM)
    const mf: DailyHours = {
      open: '7:30 AM',
      close: '7:00 PM',
      openMinutes: 7 * 60 + 30,
      closeMinutes: 19 * 60,
      isClosed: false,
    };
    const sat: DailyHours = {
      open: '8:30 AM',
      close: '4:00 PM',
      openMinutes: 8 * 60 + 30,
      closeMinutes: 16 * 60,
      isClosed: false,
    };
    const sun: DailyHours = {
      open: '11:00 AM',
      close: '3:00 PM',
      openMinutes: 11 * 60,
      closeMinutes: 15 * 60,
      isClosed: false,
    };

    return {
      mondayFriday: '7:30 AM – 7:00 PM',
      saturday: '8:30 AM – 4:00 PM',
      sunday: '11:00 AM – 3:00 PM',
      schedule: {
        0: sun,
        1: mf,
        2: mf,
        3: mf,
        4: mf,
        5: mf,
        6: sat,
      },
    };
  }
}

/**
 * Calculates whether a pharmacy is currently open or closed and formats timing notes.
 */
export function getPharmacyStatus(
  customHours?: PharmacyOperatingHours,
  fallbackSeed: string | number = 0,
  targetDate: Date = new Date()
): PharmacyStatusInfo {
  const hours = customHours || getDefaultPharmacyHours(fallbackSeed);

  const currentDay = targetDate.getDay(); // 0 = Sunday, 1 = Monday ... 6 = Saturday
  const currentMinutes = targetDate.getHours() * 60 + targetDate.getMinutes();

  const todaySchedule = hours.schedule[currentDay];
  let isOpen = false;
  let timingNote = '';

  if (todaySchedule && !todaySchedule.isClosed) {
    if (currentMinutes >= todaySchedule.openMinutes && currentMinutes < todaySchedule.closeMinutes) {
      isOpen = true;
      timingNote = `Closes at ${todaySchedule.close}`;
    } else if (currentMinutes < todaySchedule.openMinutes) {
      isOpen = false;
      timingNote = `Opens today at ${todaySchedule.open}`;
    } else {
      isOpen = false;
      // Already closed for today, check upcoming days
      timingNote = findNextOpening(hours, currentDay, 1);
    }
  } else {
    // Closed today
    isOpen = false;
    timingNote = findNextOpening(hours, currentDay, 1);
  }

  // Format today's hours text
  const todayHoursText = todaySchedule && !todaySchedule.isClosed
    ? `${todaySchedule.open} – ${todaySchedule.close}`
    : 'Closed Today';

  // Build 7-day weekly schedule array
  // Starting with Monday (1) through Sunday (0) for natural weekly flow
  const displayOrder = [1, 2, 3, 4, 5, 6, 0];
  const weeklySchedule: WeeklyScheduleEntry[] = displayOrder.map((dayIdx) => {
    const sched = hours.schedule[dayIdx];
    const isClosed = !sched || !!sched.isClosed;
    return {
      dayName: DAY_NAMES[dayIdx],
      dayShort: DAY_SHORTS[dayIdx],
      hoursText: isClosed ? 'Closed' : `${sched.open} – ${sched.close}`,
      isToday: dayIdx === currentDay,
      isClosed,
    };
  });

  const summaryText = `Mon–Fri: ${hours.mondayFriday} • Sat: ${hours.saturday} • Sun: ${hours.sunday}`;

  return {
    isOpen,
    statusBadgeText: isOpen ? 'Open Now' : 'Closed',
    timingNote,
    todayHoursText,
    weeklySchedule,
    summaryText,
  };
}

function findNextOpening(hours: PharmacyOperatingHours, currentDay: number, offsetDays: number): string {
  for (let offset = offsetDays; offset <= 7; offset++) {
    const checkDay = (currentDay + offset) % 7;
    const checkSched = hours.schedule[checkDay];
    if (checkSched && !checkSched.isClosed) {
      if (offset === 1) {
        return `Opens tomorrow at ${checkSched.open}`;
      } else {
        return `Opens ${DAY_SHORTS[checkDay]} at ${checkSched.open}`;
      }
    }
  }
  return 'Closed';
}
