import React, { useState } from 'react';
import {
  FolderKanban,
  UserCheck,
  ShieldCheck,
  Phone,
  MapPin,
  Calendar,
  AlertTriangle,
  Plus,
  Search,
  CheckCircle2,
  Users,
  FileText,
  Clock,
  HeartHandshake,
  Lock,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { ClientCaseRecord, CommunityVolunteer, LanguageCode, StateCode } from '../types';
import { INITIAL_COMMUNITY_VOLUNTEERS } from '../data/communityVolunteersData';

interface CaseManagerSectionProps {
  lang: LanguageCode;
  countyName: string;
  state: StateCode;
}

const INITIAL_CLIENT_RECORDS: ClientCaseRecord[] = [
  {
    id: 'client-1',
    clientName: 'Robert Miller',
    age: 68,
    county: 'Sullivan County',
    state: 'IN',
    phone: '(812) 555-0142',
    address: '1420 W Maple St, Sullivan, IN 47882',
    insuranceId: 'medicaid-hip',
    insuranceName: 'Medicaid / Healthy Indiana Plan (HIP)',
    caseManagerCovered: true,
    assignedCaseManager: 'Sarah Jenkins, LSW (License #34091)',
    urgentNeeds: ['Meals on Wheels Doorstep Delivery', 'Diabetic Insulin Refill Delivery', 'Fall Prevention Rails'],
    carePlanStatus: 'Active',
    notes: 'Client lives on rural gravel road. Enrolled in county doorstep meal delivery. Transportation van scheduled for upcoming eye exam.',
    assignedVolunteerName: 'Marcus Brody (Pre-Med Helper)',
    assignedVolunteerPhone: '(812) 555-0329',
    lastContactDate: 'Yesterday at 2:15 PM',
  },
  {
    id: 'client-2',
    clientName: 'Mary Jenkins',
    age: 74,
    county: 'Greene County',
    state: 'IN',
    phone: '(812) 555-0198',
    address: '488 Rural Route 3, Linton, IN 47441',
    insuranceId: 'medicare',
    insuranceName: 'Medicare Part B & Advantage Plan',
    caseManagerCovered: true,
    assignedCaseManager: 'David Cole, RN Care Coordinator',
    urgentNeeds: ['Wheelchair Transit to Terre Haute Clinic', 'Family Paid Caregiver Enrollment ($18.50/hr)'],
    carePlanStatus: 'Active',
    notes: 'Daughter Sarah is applying to be paid family attendant through Medicaid waiver. Assisting with paperwork submission to fiscal agency.',
    assignedVolunteerName: 'Hannah Albright (OT Assistant Trainee)',
    assignedVolunteerPhone: '(812) 555-0344',
    lastContactDate: '3 days ago',
  },
  {
    id: 'client-3',
    clientName: 'David Thompson',
    age: 52,
    county: 'Clay County',
    state: 'IN',
    phone: '(812) 555-0233',
    address: '812 E National Ave, Brazil, IN 47834',
    insuranceId: 'uninsured',
    insuranceName: 'Uninsured (Community Care / Sliding Scale)',
    caseManagerCovered: false,
    assignedCaseManager: 'Elena Cooper (Community Health Center FQHC Navigator)',
    urgentNeeds: ['Food Pantry Delivery Box', 'Winter Heating Assistance (LIHEAP)', 'Free Clinic Primary Care'],
    carePlanStatus: 'Intake',
    notes: 'Insurance does not cover private case manager; linked to FQHC sliding scale care coordinator. Filed LIHEAP utility voucher with Township Trustee.',
    assignedVolunteerName: 'David O’Connor (Retired Paramedic)',
    assignedVolunteerPhone: '(812) 555-0377',
    lastContactDate: 'Today at 9:30 AM',
  },
  {
    id: 'client-4',
    clientName: 'Evelyn Rodriguez',
    age: 61,
    county: 'Monroe County',
    state: 'IN',
    phone: '(812) 555-0371',
    address: '2105 S Rockport Rd, Bloomington, IN 47403',
    insuranceId: 'medicaid-hip',
    insuranceName: 'Medicaid / HIP Managed Care',
    caseManagerCovered: true,
    assignedCaseManager: 'Sarah Jenkins, LSW',
    urgentNeeds: ['Spanish Medical Interpreter for Clinic Visit', 'Hypertension Medication Delivery'],
    carePlanStatus: 'Active',
    notes: 'Bi-lingual Spanish interpreter requested for next Tuesday appointment. Local pharmacy delivery confirmed for prescriptions.',
    assignedVolunteerName: 'Emily Chen (BSN Nursing Senior)',
    assignedVolunteerPhone: '(812) 555-0312',
    lastContactDate: '4 days ago',
  },
];

export const CaseManagerSection: React.FC<CaseManagerSectionProps> = ({
  countyName,
  state,
}) => {
  const [clients, setClients] = useState<ClientCaseRecord[]>(INITIAL_CLIENT_RECORDS);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterInsurance, setFilterInsurance] = useState<'all' | 'covered' | 'uncovered'>('all');
  const [selectedClient, setSelectedClient] = useState<ClientCaseRecord | null>(INITIAL_CLIENT_RECORDS[0]);
  const [showAddClientModal, setShowAddClientModal] = useState(false);

  // New Client Form
  const [newClientName, setNewClientName] = useState('');
  const [newClientAge, setNewClientAge] = useState('');
  const [newClientPhone, setNewClientPhone] = useState('');
  const [newClientAddress, setNewClientAddress] = useState('');
  const [newClientInsurance, setNewClientInsurance] = useState('medicaid-hip');
  const [newClientNeeds, setNewClientNeeds] = useState('');
  const [newClientNotes, setNewClientNotes] = useState('');

  const filteredClients = clients.filter((c) => {
    const matchesSearch =
      c.clientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.county.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (filterInsurance === 'covered') return c.caseManagerCovered;
    if (filterInsurance === 'uncovered') return !c.caseManagerCovered;
    return true;
  });

  const handleAddClientSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClientName.trim() || !newClientPhone.trim()) return;

    const isCovered = newClientInsurance === 'medicaid-hip' || newClientInsurance === 'medicare';
    const insLabel =
      newClientInsurance === 'medicaid-hip'
        ? 'Medicaid / HIP'
        : newClientInsurance === 'medicare'
        ? 'Medicare Part B / Advantage'
        : 'Uninsured (Community FQHC)';

    const newRecord: ClientCaseRecord = {
      id: `client-${Date.now()}`,
      clientName: newClientName.trim(),
      age: parseInt(newClientAge, 10) || 60,
      county: countyName,
      state,
      phone: newClientPhone.trim(),
      address: newClientAddress.trim() || `${countyName}, ${state}`,
      insuranceId: newClientInsurance,
      insuranceName: insLabel,
      caseManagerCovered: isCovered,
      assignedCaseManager: 'Active Case Manager (You)',
      urgentNeeds: newClientNeeds
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean),
      carePlanStatus: 'Intake',
      notes: newClientNotes.trim() || 'New client intake registered through case manager portal.',
      lastContactDate: 'Just now',
    };

    setClients((prev) => [newRecord, ...prev]);
    setSelectedClient(newRecord);
    setShowAddClientModal(false);
    setNewClientName('');
    setNewClientAge('');
    setNewClientPhone('');
    setNewClientAddress('');
    setNewClientNeeds('');
    setNewClientNotes('');
  };

  return (
    <div id="case-manager-portal-section" className="space-y-6">
      {/* Header Banner: Authenticated & Confidential Access */}
      <div className="bg-gradient-to-r from-coffee-bean via-slate-900 to-coffee-bean text-white rounded-3xl p-6 sm:p-8 shadow-md border border-slate-700">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-seaweed text-white flex items-center justify-center shrink-0 shadow-sm">
              <FolderKanban className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-extrabold text-[11px] uppercase tracking-wider border border-emerald-500/40 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Case Manager Account Active
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-sky-500/20 text-sky-300 font-semibold text-[11px] border border-sky-500/30">
                  Full Information & Direct Contacts Unlocked
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                Case Manager Caseload & Client Directory
              </h2>
              <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
                Protected client records, contact numbers, residential addresses, and insurance case management coverage for {countyName}, {state}.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setShowAddClientModal(true)}
              className="px-4 py-2.5 rounded-xl bg-seaweed hover:bg-seaweed-hover text-white text-xs sm:text-sm font-bold flex items-center gap-2 transition-all shadow-sm active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Client to Caseload</span>
            </button>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-800 text-xs">
          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <span className="text-slate-400 block text-[11px]">Total Active Clients</span>
            <span className="text-lg font-extrabold text-white">{clients.length} Clients</span>
          </div>
          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <span className="text-slate-400 block text-[11px]">Insurance-Covered CM</span>
            <span className="text-lg font-extrabold text-emerald-400">
              {clients.filter((c) => c.caseManagerCovered).length} Fully Covered
            </span>
          </div>
          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <span className="text-slate-400 block text-[11px]">Uncovered (FQHC Options)</span>
            <span className="text-lg font-extrabold text-amber-400">
              {clients.filter((c) => !c.caseManagerCovered).length} Free Clinic Nav
            </span>
          </div>
          <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <span className="text-slate-400 block text-[11px]">Assigned Volunteers</span>
            <span className="text-lg font-extrabold text-sky-400">
              {INITIAL_COMMUNITY_VOLUNTEERS.length} Helpers Active
            </span>
          </div>
        </div>
      </div>

      {/* Main Two-Column Layout: Client Directory on Left, Case File Details on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Client Directory List (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-coffee-bean dark:text-slate-100 flex items-center gap-2">
                <Users className="w-4 h-4 text-seaweed" />
                <span>Caseload Roster ({filteredClients.length})</span>
              </h3>
              <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                <Lock className="w-3 h-3" /> PII Authorized
              </span>
            </div>

            {/* Search Input */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by client name, address, or county..."
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-coffee-bean dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-seaweed"
              />
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-1.5 text-[11px]">
              <button
                type="button"
                onClick={() => setFilterInsurance('all')}
                className={`px-2.5 py-1 rounded-lg font-semibold transition-colors cursor-pointer ${
                  filterInsurance === 'all'
                    ? 'bg-seaweed text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-coffee-bean-muted dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                All ({clients.length})
              </button>
              <button
                type="button"
                onClick={() => setFilterInsurance('covered')}
                className={`px-2.5 py-1 rounded-lg font-semibold transition-colors cursor-pointer ${
                  filterInsurance === 'covered'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-coffee-bean-muted dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                Covered by Insurance ({clients.filter((c) => c.caseManagerCovered).length})
              </button>
              <button
                type="button"
                onClick={() => setFilterInsurance('uncovered')}
                className={`px-2.5 py-1 rounded-lg font-semibold transition-colors cursor-pointer ${
                  filterInsurance === 'uncovered'
                    ? 'bg-amber-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-coffee-bean-muted dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                Uncovered / Free FQHC ({clients.filter((c) => !c.caseManagerCovered).length})
              </button>
            </div>

            {/* Client Cards List */}
            <div className="space-y-2.5 max-h-[540px] overflow-y-auto pr-1">
              {filteredClients.map((client) => {
                const isSelected = selectedClient?.id === client.id;
                return (
                  <div
                    key={client.id}
                    onClick={() => setSelectedClient(client)}
                    className={`p-3.5 rounded-2xl border text-left cursor-pointer transition-all ${
                      isSelected
                        ? 'border-seaweed bg-seaweed-light/40 dark:bg-seaweed-dark/30 ring-2 ring-seaweed/30'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-bold text-sm text-coffee-bean dark:text-slate-100 flex items-center gap-1.5">
                          <span>{client.clientName}</span>
                          <span className="text-xs text-coffee-bean-muted dark:text-slate-400 font-normal">
                            ({client.age} yrs)
                          </span>
                        </div>
                        <p className="text-[11px] text-coffee-bean-muted dark:text-slate-400 mt-0.5 flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-seaweed shrink-0" />
                          <span className="truncate">{client.address}</span>
                        </p>
                      </div>

                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-md whitespace-nowrap shrink-0 ${
                          client.caseManagerCovered
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-300 dark:border-amber-800'
                        }`}
                      >
                        {client.caseManagerCovered ? '✓ Covered CM' : 'Free FQHC'}
                      </span>
                    </div>

                    <div className="mt-2 flex items-center justify-between text-[11px] pt-2 border-t border-slate-100 dark:border-slate-800 text-coffee-bean-muted dark:text-slate-400">
                      <span className="font-semibold text-seaweed flex items-center gap-1">
                        <Phone className="w-3 h-3" />
                        {client.phone}
                      </span>
                      <span>Last: {client.lastContactDate}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right: Selected Client Full Case File (7 cols) */}
        <div className="lg:col-span-7">
          {selectedClient ? (
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-sm space-y-5">
              {/* Client Header Info */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-xl font-bold text-coffee-bean dark:text-slate-100">
                      {selectedClient.clientName}
                    </h3>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-coffee-bean dark:text-slate-300 font-semibold">
                      Age {selectedClient.age} • {selectedClient.county}, {selectedClient.state}
                    </span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 font-bold">
                      Status: {selectedClient.carePlanStatus}
                    </span>
                  </div>
                  <p className="text-xs text-coffee-bean-muted dark:text-slate-400 mt-1 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-seaweed" />
                    <span>{selectedClient.address}</span>
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={`tel:${selectedClient.phone.replace(/[^0-9]/g, '')}`}
                    className="px-3.5 py-2 rounded-xl bg-seaweed hover:bg-seaweed-hover text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-2xs"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call {selectedClient.phone}</span>
                  </a>
                </div>
              </div>

              {/* Insurance & Case Manager Coverage Card */}
              <div
                className={`p-4 rounded-2xl border space-y-2 ${
                  selectedClient.caseManagerCovered
                    ? 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800'
                    : 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldCheck
                      className={`w-5 h-5 ${
                        selectedClient.caseManagerCovered ? 'text-emerald-600' : 'text-amber-600'
                      }`}
                    />
                    <strong className="text-sm font-bold text-coffee-bean dark:text-slate-100">
                      Insurance: {selectedClient.insuranceName}
                    </strong>
                  </div>
                  <span
                    className={`text-xs font-extrabold px-2.5 py-0.5 rounded-md ${
                      selectedClient.caseManagerCovered
                        ? 'bg-emerald-600 text-white'
                        : 'bg-amber-600 text-white'
                    }`}
                  >
                    {selectedClient.caseManagerCovered
                      ? '✓ Case Manager Covered by Insurance'
                      : '✕ Not Covered by Insurance'}
                  </span>
                </div>

                {selectedClient.caseManagerCovered ? (
                  <p className="text-xs text-coffee-bean-muted dark:text-slate-300 leading-relaxed">
                    Case management services are 100% billed and covered under the client’s state plan with $0 copay. All caregiver paperwork, transit authorizations, and in-home assessments qualify for reimbursement.
                  </p>
                ) : (
                  <div className="text-xs text-coffee-bean-muted dark:text-slate-300 space-y-1.5">
                    <p className="font-semibold text-amber-900 dark:text-amber-300">
                      Case manager is not covered under this plan. Active alternative options in place:
                    </p>
                    <ul className="list-disc list-inside space-y-0.5 text-[11px] text-coffee-bean dark:text-slate-300">
                      <li><strong>FQHC Clinic Navigation:</strong> Local Federally Qualified Health Center case coordinator assigned at $0 sliding fee.</li>
                      <li><strong>Area Agency on Aging (AAA):</strong> County social services navigator assigned for food and transit vouchers.</li>
                      <li><strong>Township Trustee:</strong> Utility and emergency prescription voucher active.</li>
                    </ul>
                  </div>
                )}
              </div>

              {/* Client Urgent Needs */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-coffee-bean dark:text-slate-200 flex items-center gap-1.5">
                  <HeartHandshake className="w-4 h-4 text-seaweed" />
                  <span>Immediate Assistance Needs</span>
                </h4>
                <div className="flex flex-wrap gap-2">
                  {selectedClient.urgentNeeds.map((need, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-coffee-bean dark:text-slate-200 text-xs font-semibold border border-slate-200 dark:border-slate-700 flex items-center gap-1"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-seaweed" />
                      <span>{need}</span>
                    </span>
                  ))}
                </div>
              </div>

              {/* Assigned Volunteer Helper (Available only to Case Manager) */}
              <div className="p-4 rounded-2xl bg-purple-50/70 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-purple-950 dark:text-purple-200 uppercase tracking-wider">
                    <Users className="w-4 h-4 text-purple-600" />
                    <span>Assigned Healthcare Volunteer</span>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-200 dark:bg-purple-900 text-purple-800 dark:text-purple-200">
                    Contact Authorized
                  </span>
                </div>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-coffee-bean dark:text-slate-200">
                  <div>
                    <span className="font-bold">{selectedClient.assignedVolunteerName || 'No volunteer assigned yet'}</span>
                    <p className="text-[11px] text-coffee-bean-muted dark:text-slate-400">
                      Dispatched for doorstep visits, grocery delivery, and companion checks.
                    </p>
                  </div>
                  {selectedClient.assignedVolunteerPhone && (
                    <a
                      href={`tel:${selectedClient.assignedVolunteerPhone}`}
                      className="inline-flex items-center gap-1 text-purple-700 dark:text-purple-300 font-bold hover:underline"
                    >
                      <Phone className="w-3 h-3" />
                      <span>{selectedClient.assignedVolunteerPhone}</span>
                    </a>
                  )}
                </div>
              </div>

              {/* Case Manager Notes & Coordination Log */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-coffee-bean dark:text-slate-200 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-seaweed" />
                  <span>Case Coordination Notes</span>
                </h4>
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs text-coffee-bean-muted dark:text-slate-300 leading-relaxed">
                  {selectedClient.notes}
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                  <span>Assigned Manager: {selectedClient.assignedCaseManager}</span>
                  <span>Last Updated: {selectedClient.lastContactDate}</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 text-center text-coffee-bean-muted">
              Select a client from the caseload roster to view full information.
            </div>
          )}
        </div>
      </div>

      {/* Add Client Modal */}
      {showAddClientModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn"
        >
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-lg text-coffee-bean dark:text-slate-100 flex items-center gap-2">
                <Plus className="w-5 h-5 text-seaweed" />
                <span>New Client Intake Form</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddClientModal(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddClientSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-coffee-bean dark:text-slate-200 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={newClientName}
                  onChange={(e) => setNewClientName(e.target.value)}
                  placeholder="e.g. John Henderson"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-coffee-bean dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-semibold text-coffee-bean dark:text-slate-200 mb-1">
                    Age
                  </label>
                  <input
                    type="number"
                    value={newClientAge}
                    onChange={(e) => setNewClientAge(e.target.value)}
                    placeholder="e.g. 71"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-coffee-bean dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-coffee-bean dark:text-slate-200 mb-1">
                    Direct Phone *
                  </label>
                  <input
                    type="tel"
                    required
                    value={newClientPhone}
                    onChange={(e) => setNewClientPhone(e.target.value)}
                    placeholder="(812) 555-0100"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-coffee-bean dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-coffee-bean dark:text-slate-200 mb-1">
                  Home Physical Address
                </label>
                <input
                  type="text"
                  value={newClientAddress}
                  onChange={(e) => setNewClientAddress(e.target.value)}
                  placeholder="Street address, county, rural route..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-coffee-bean dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-semibold text-coffee-bean dark:text-slate-200 mb-1">
                  Client Insurance Plan
                </label>
                <select
                  value={newClientInsurance}
                  onChange={(e) => setNewClientInsurance(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-coffee-bean dark:text-slate-100"
                >
                  <option value="medicaid-hip">Medicaid / Healthy Indiana Plan (Case Manager Covered ✓)</option>
                  <option value="medicare">Medicare Part B & Advantage (Case Manager Covered ✓)</option>
                  <option value="private-insurance">Private / Employer (May Require Rider)</option>
                  <option value="uninsured">Uninsured (Not Covered - Assign FQHC Navigator)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-coffee-bean dark:text-slate-200 mb-1">
                  Urgent Needs (comma separated)
                </label>
                <input
                  type="text"
                  value={newClientNeeds}
                  onChange={(e) => setNewClientNeeds(e.target.value)}
                  placeholder="e.g. Meals on wheels, clinic ride, heating voucher"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-coffee-bean dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-semibold text-coffee-bean dark:text-slate-200 mb-1">
                  Case Notes
                </label>
                <textarea
                  rows={2}
                  value={newClientNotes}
                  onChange={(e) => setNewClientNotes(e.target.value)}
                  placeholder="Intake notes, physician contacts, family attendant notes..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-coffee-bean dark:text-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddClientModal(false)}
                  className="px-3 py-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-seaweed hover:bg-seaweed-hover text-white font-bold"
                >
                  Save to Caseload
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
