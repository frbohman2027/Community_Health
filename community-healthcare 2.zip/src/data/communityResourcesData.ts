import { CommunityResource, StateCode } from '../types';

export const STATE_HEALTH_EQUITY_INFO: Record<StateCode, {
  sdgGoal: string;
  equityCommitment: string;
  nemtPhone: string;
}> = {
  IN: {
    sdgGoal: 'SDG 3.8: Universal Health Coverage & Essential Rural Access',
    equityCommitment: 'Indiana State Department of Health (IDOH) Rural Health Initiative & Division of Chronic Disease Prevention',
    nemtPhone: '1-800-457-4584', // Indiana Medicaid Transportation dispatch
  },
  KY: {
    sdgGoal: 'SDG 3.8: Universal Health Coverage & Appalachian Health Equity',
    equityCommitment: 'Kentucky Department for Public Health Rural Health Network',
    nemtPhone: '1-800-635-2570',
  },
  OH: {
    sdgGoal: 'SDG 3.8: Universal Health Coverage & Rural Health Access',
    equityCommitment: 'Ohio Department of Health State Office of Rural Health',
    nemtPhone: '1-800-324-8680',
  },
  IL: {
    sdgGoal: 'SDG 3.8: Universal Health Coverage & Agricultural Health Equity',
    equityCommitment: 'Illinois Department of Public Health Center for Rural Health',
    nemtPhone: '1-877-725-0569',
  },
};

/**
 * Returns tailored CommunityRx resources for any selected county and state.
 * Grounded in Drewry et al. (2023), Steeves-Reece et al. (2022), and Lindau et al. (2019 CommunityRx).
 */
export function getCommunityResourcesForCounty(
  countyName: string,
  state: StateCode
): CommunityResource[] {
  const cleanCounty = countyName.replace(/\s+County/i, '').trim();

  return [
    {
      id: `nemt-transit-${state}-${cleanCounty.toLowerCase()}`,
      category: 'transportation',
      name: `${cleanCounty} Rural Medical Transit & NEMT Rides`,
      serviceType: 'Door-to-Door Non-Emergency Medical Transportation',
      description: `Free or low-cost round-trip rides for doctor visits, hospital telehealth rooms, and clinic follow-ups for ${cleanCounty} residents. Wheelchair accessible vans available.`,
      eligibility: 'Open to rural residents, Medicaid members, seniors 60+, and low-income families without personal transport.',
      phone: state === 'IN' ? '1-800-457-4584' : state === 'KY' ? '1-800-635-2570' : '1-800-324-8680',
      actionText: 'Call for Free Medical Ride',
      isDirectReferral: true,
      coverageArea: `${countyName}, ${state}`,
    },
    {
      id: `food-pantry-${state}-${cleanCounty.toLowerCase()}`,
      category: 'food',
      name: `${cleanCounty} Community Food Bank & Rural Mobile Pantry`,
      serviceType: 'Emergency Groceries & Fresh Produce Distribution',
      description: `Provides weekly pre-packed fresh produce, canned staples, and infant supplies to families in rural ${cleanCounty}. No paperwork or income verification required at pick-up.`,
      eligibility: 'All households in ${countyName} needing nutritional assistance.',
      phone: '211',
      actionText: 'Connect to Food Pantry',
      isDirectReferral: true,
      coverageArea: `${cleanCounty} & regional township corridors`,
    },
    {
      id: `energy-housing-${state}-${cleanCounty.toLowerCase()}`,
      category: 'utilities_housing',
      name: `${state} Rural Energy & Heating Assistance (LIHEAP)`,
      serviceType: 'Utility Bill Discount & Winter Heating Safety',
      description: `Emergency funds to prevent electrical or heating shutoffs during cold snaps and summer heatwaves. Also offers winterization assistance for rural homes.`,
      eligibility: 'Household income under 200% of Federal Poverty Level or experiencing sudden financial crisis.',
      phone: '1-800-382-9895',
      actionText: 'Check Utility Relief',
      isDirectReferral: false,
      coverageArea: `Statewide program for ${state}`,
    },
    {
      id: `care-navigator-${state}-${cleanCounty.toLowerCase()}`,
      category: 'navigator',
      name: `${cleanCounty} Community Health Worker (CHW) Care Network`,
      serviceType: '1-on-1 Patient Health Navigation & System Guidance',
      description: `Dedicated rural care navigators who meet by phone, video, or in clinic to help complete financial assistance forms, coordinate specialty referrals, and organize prescription drop-offs.`,
      eligibility: 'Free service for any patient seeking primary care or rural clinic appointments.',
      phone: '1-888-787-2522',
      actionText: 'Request Care Navigator Call',
      isDirectReferral: true,
      coverageArea: `${countyName} Community Health Partnership`,
    },
  ];
}
