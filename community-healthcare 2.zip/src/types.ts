export type StateCode = 'IN' | 'KY' | 'OH' | 'IL';

export type LanguageCode = 'en' | 'es' | 'de' | 'my' | 'fr' | 'zh' | 'ar' | 'vi';

export interface LanguageInfo {
  code: LanguageCode;
  label: string;
  englishLabel: string;
  flagOrTag?: string;
  notes?: string;
  dir?: 'ltr' | 'rtl';
}

export interface CountyOption {
  code: string;
  name: string;
  state: StateCode;
}

export interface DoctorAvailability {
  specialty: string;
  nextOpenSlot: string; // e.g., "TODO" or specific placeholder
  telehealthAvailable: boolean;
  notes: string;
}

export interface Hospital {
  id: string;
  name: string;
  state: StateCode;
  countyCode: string;
  countyName: string;
  address: string;
  websiteUrl: string; // Spot to send to the hospital's main page website
  phone?: string;
  distanceMiles?: string;
  hasEmergencyRoom: boolean;
  doctors: DoctorAvailability[];
}

export interface DailyHours {
  open: string;
  close: string;
  openMinutes: number;
  closeMinutes: number;
  isClosed?: boolean;
}

export interface PharmacyOperatingHours {
  mondayFriday: string;
  saturday: string;
  sunday: string;
  schedule: {
    [dayOfWeek: number]: DailyHours;
  };
}

export interface Pharmacy {
  id: string;
  name: string;
  state: StateCode;
  countyCode: string;
  address: string;
  phone?: string;
  distanceMiles?: string;
  offersDelivery: boolean;
  hours?: PharmacyOperatingHours;
}

export interface SymptomOption {
  id: string;
  labelEn: string;
  labelEs: string;
  descriptionEn: string;
  descriptionEs: string;
  localizedLabels?: Partial<Record<LanguageCode, string>>;
  localizedDescriptions?: Partial<Record<LanguageCode, string>>;
  isUrgentCareNotice?: boolean;
}

export interface InsuranceOption {
  id: string;
  titleEn: string;
  titleEs: string;
  descriptionEn: string;
  descriptionEs: string;
  name?: string;
  description?: string;
  localizedTitles?: Partial<Record<LanguageCode, string>>;
  localizedDescriptions?: Partial<Record<LanguageCode, string>>;
}

export interface HospitalMessage {
  id: string;
  sender: 'user' | 'hospital';
  text: string;
  timestamp: string;
  category?: string;
}

export interface InterpreterRequest {
  needed: boolean;
  language: string;
  format: 'video_or_phone' | 'in_person' | 'any';
  customLanguage?: string;
  notes?: string;
}

export type CommunityCategory =
  | 'transportation'
  | 'food'
  | 'utilities_housing'
  | 'navigator';

export interface CommunityResource {
  id: string;
  category: CommunityCategory;
  name: string;
  serviceType: string;
  description: string;
  eligibility: string;
  phone?: string;
  address?: string;
  actionText: string;
  isDirectReferral: boolean; // Direct vs indirect referral support (Ruiz Escobar et al., 2021)
  coverageArea: string;
}

export interface PatientSharingPreferences {
  shareAssistanceNeeds: boolean;
  shareInsuranceStatus: boolean;
  shareTransportationNeeds: boolean;
  shareFoodAssistanceNeeds: boolean;
  shareClinicalNotes: boolean;
}

export interface CareNavigatorRequest {
  requested: boolean;
  topic: 'transportation' | 'financial_sliding_scale' | 'appointment_scheduling' | 'language_support' | 'general';
  preferredContact: 'phone' | 'video' | 'in_person';
  phoneNumber?: string;
  patientNote?: string;
}

export interface HomeHealthAide {
  id: string;
  name: string;
  credentials: string; // e.g., 'Certified HHA', 'State Certified Aide', 'CNA'
  experienceYears: number;
  rating: number;
  reviewsCount: number;
  state: StateCode;
  countiesServed: string[];
  bio: string;
  services: string[];
  languages: string[];
  acceptsMedicaid: boolean;
  phone: string;
  availability: string;
  photoUrl?: string;
}

export interface MedicaidFamilyCaregiverApplication {
  id: string;
  applicantName: string;
  relationship: string;
  phone: string;
  email: string;
  county: string;
  state: StateCode;
  patientMedicaidId?: string;
  hoursNeededPerWeek: string;
  careNeeded: string[];
  notes?: string;
  submittedAt: string;
}

export interface CommunityVolunteer {
  id: string;
  name: string;
  roleOrStudy: string; // e.g. 'Nursing Student (BSN)', 'Pre-Med Student', 'Retired EMT', 'Community Caregiver'
  schoolOrOrg?: string;
  county: string;
  state: StateCode;
  hoursVolunteered: number;
  verifiedHours: boolean;
  servicesOffered: string[];
  contactPhone: string;
  availability: string;
  bio: string;
}

export interface CommunityHelpRequest {
  id: string;
  title: string;
  category: 'vitals_check' | 'companion_care' | 'medication_errand' | 'food_delivery' | 'respite';
  county: string;
  state: StateCode;
  description: string;
  urgency: 'flexible' | 'this_week' | 'immediate';
  volunteersAssigned: number;
  postedDate: string;
  clientInitials?: string;
  clientFullName?: string;
  clientPhone?: string;
}

export type UserAppSectionRole =
  | 'in_need_of_help'
  | 'case_manager'
  | 'wanting_employment'
  | 'wanting_help';

export interface ClientCaseRecord {
  id: string;
  clientName: string;
  age: number;
  county: string;
  state: StateCode;
  phone: string;
  address: string;
  insuranceId: string;
  insuranceName: string;
  caseManagerCovered: boolean;
  assignedCaseManager: string;
  urgentNeeds: string[];
  carePlanStatus: 'Active' | 'Intake' | 'Pending Review';
  notes: string;
  assignedVolunteerName?: string;
  assignedVolunteerPhone?: string;
  lastContactDate: string;
}

export interface EmploymentOpportunity {
  id: string;
  title: string;
  category: 'family_caregiver' | 'hha_cna' | 'clinic_support' | 'rural_transit';
  wageRange: string;
  employmentType: 'Full-Time' | 'Part-Time' | 'Flexible' | 'Family Attendant';
  county: string;
  state: StateCode;
  organization: string;
  description: string;
  qualifications: string[];
  howToApply: string;
  phone?: string;
  directContact?: string;
}
