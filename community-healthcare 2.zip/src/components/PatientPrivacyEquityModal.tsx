import React from 'react';
import {
  ShieldCheck,
  X,
  Lock,
  Globe2,
  Trash2,
  CheckCircle,
  EyeOff,
  Sparkles,
  Users,
  HeartHandshake,
} from 'lucide-react';

interface PatientPrivacyEquityModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClearAllData: () => void;
}

export const PatientPrivacyEquityModal: React.FC<PatientPrivacyEquityModalProps> = ({
  isOpen,
  onClose,
  onClearAllData,
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="privacy-equity-modal-title"
      className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fadeIn"
    >
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-pale-sky/80 dark:border-slate-800 relative space-y-5 max-h-[90vh] overflow-y-auto">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-coffee-bean-muted dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          aria-label="Close privacy and health equity dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-seaweed-light text-seaweed border border-seaweed/30 flex items-center justify-center shrink-0 shadow-2xs">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 id="privacy-equity-modal-title" className="text-xl font-bold text-coffee-bean dark:text-slate-100">
              Patient Privacy, Autonomy & Health Equity
            </h3>
            <p className="text-xs text-coffee-bean-muted dark:text-slate-400">
              Upholding UN Sustainable Development Goal 3.8 & Digital Privacy Rights
            </p>
          </div>
        </div>

        {/* 1. Client-Side Only Data Protection (Alhammad et al., 2024) */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
          <div className="flex items-center gap-2 text-coffee-bean dark:text-slate-100 font-bold text-sm">
            <Lock className="w-4 h-4 text-seaweed" />
            <span>100% Local Device Storage — No Telemetry or Selling of Data</span>
          </div>
          <p className="text-xs text-coffee-bean-muted dark:text-slate-300 leading-relaxed">
            Your assistance requests and personal notes stay strictly inside your browser. No personal health information (PHI) or social determinants are uploaded to advertising databases or third parties.
          </p>
        </div>

        {/* 2. Patient Voice & Autonomy (Hartzler et al., 2023) */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
          <div className="flex items-center gap-2 text-coffee-bean dark:text-slate-100 font-bold text-sm">
            <EyeOff className="w-4 h-4 text-purple-600" />
            <span>Patient Autonomy & Granular Sharing Controls</span>
          </div>
          <p className="text-xs text-coffee-bean-muted dark:text-slate-300 leading-relaxed">
            Automated algorithms should never make decisions about your social needs without you. You retain 100% control over which items appear on your clinic message. Uncheck any category at any time.
          </p>
        </div>

        {/* 3. Universal Health Coverage & SDG 3.8 Alignment (Antonio et al., 2019) */}
        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
          <div className="flex items-center gap-2 text-coffee-bean dark:text-slate-100 font-bold text-sm">
            <Globe2 className="w-4 h-4 text-sky-600" />
            <span>Health Equity & United Nations SDG 3.8 Commitment</span>
          </div>
          <p className="text-xs text-coffee-bean-muted dark:text-slate-300 leading-relaxed">
            <strong>UN SDG Target 3.8:</strong> <em>&quot;Achieve universal health coverage, including financial risk protection, access to quality essential health-care services and access to safe, effective, quality and affordable essential medicines.&quot;</em>
          </p>
          <ul className="text-xs text-coffee-bean-muted dark:text-slate-400 space-y-1 list-disc list-inside">
            <li><strong>No Account Required:</strong> No login passwords or credit cards required to access life-saving healthcare, food, and community resources.</li>
            <li><strong>Low-Bandwidth & Arm&apos;s-Length Design:</strong> Functions reliably on slow rural cell networks with high-contrast text enlarged for phone screens.</li>
            <li><strong>Multilingual Equity:</strong> Native translations for 8 regional spoken languages plus free live interpreter requests.</li>
          </ul>
        </div>

        {/* One-Click Data Reset */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={() => {
              if (window.confirm('Are you sure you want to clear all your entered assistance selections, notes, and local data?')) {
                onClearAllData();
                onClose();
              }
            }}
            className="w-full sm:w-auto px-4 py-2 rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-bold border border-rose-200 dark:border-rose-900/60 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Reset All Local Health Data</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-seaweed hover:bg-seaweed-hover text-white text-xs sm:text-sm font-bold shadow-xs cursor-pointer transition-all"
          >
            Done & Return to App
          </button>
        </div>
      </div>
    </div>
  );
};
