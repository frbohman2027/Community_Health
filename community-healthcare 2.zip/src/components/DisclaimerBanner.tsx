import React from 'react';
import { AlertTriangle, Phone, HeartHandshake, ShieldAlert } from 'lucide-react';
import { LanguageCode } from '../types';
import { TRANSLATIONS } from '../utils/translations';

interface DisclaimerBannerProps {
  lang: LanguageCode;
}

export const DisclaimerBanner: React.FC<DisclaimerBannerProps> = ({ lang }) => {
  const t = TRANSLATIONS[lang];

  return (
    <div
      id="disclaimer-banner"
      className="bg-amber-50/70 border-b border-amber-200/60 text-amber-950 px-4 py-3 sm:py-3.5 transition-colors"
    >
      <div className="max-w-5xl mx-auto flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 sm:gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-amber-100/80 text-amber-800 rounded-xl shrink-0 mt-0.5 border border-amber-200/50 shadow-2xs">
            <AlertTriangle className="w-5 h-5" aria-hidden="true" />
          </div>
          <div>
            <h2 className="font-bold text-sm sm:text-base text-amber-950 flex items-center gap-2">
              <span>{t.disclaimerTitle}</span>
            </h2>
            <p className="text-xs sm:text-sm text-amber-900/90 mt-0.5 leading-relaxed max-w-2xl">
              {t.disclaimerText}
            </p>
          </div>
        </div>

        {/* Top Bar Quick Emergency & Support Numbers */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:flex lg:flex-nowrap items-center gap-2 w-full lg:w-auto shrink-0 pt-1 lg:pt-0 max-w-full">
          <a
            id="emergency-call-911-btn"
            href="tel:911"
            className="w-full sm:w-auto min-w-0 inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-cherry-rose hover:bg-cherry-rose-hover text-white font-bold text-xs sm:text-sm rounded-xl shadow-2xs transition-all active:scale-95 focus:ring-2 focus:ring-cherry-rose/40"
          >
            <Phone className="w-3.5 h-3.5 fill-current shrink-0" />
            <span className="truncate">{t.call911}</span>
          </a>
          <a
            id="mental-wellness-btn"
            href="tel:988"
            title="988 Suicide & Crisis Lifeline - Free, confidential 24/7 call or text"
            className="w-full sm:w-auto min-w-0 inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-seaweed-dark hover:bg-seaweed text-white font-medium text-xs sm:text-sm rounded-xl shadow-2xs transition-all active:scale-95 focus:ring-2 focus:ring-neon-ice"
          >
            <HeartHandshake className="w-3.5 h-3.5 text-neon-ice shrink-0" />
            <span className="truncate">{t.callMentalWellness || 'Mental Wellness: 988'}</span>
          </a>
        </div>
      </div>
    </div>
  );
};
