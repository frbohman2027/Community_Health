import React, { useState } from 'react';
import {
  Bus,
  Apple,
  Droplet,
  Home,
  UserCheck,
  Phone,
  CheckCircle2,
  ExternalLink,
  ShieldAlert,
  Info,
  ChevronRight,
  HandHeart,
  Sparkles,
} from 'lucide-react';
import { CommunityCategory, CommunityResource, LanguageCode, StateCode } from '../types';
import { TRANSLATIONS } from '../utils/translations';

interface CommunitySupportSectionProps {
  lang: LanguageCode;
  countyName: string;
  state: StateCode;
  resources: CommunityResource[];
  selectedResourceIds: string[];
  onToggleResource: (id: string) => void;
}

export const CommunitySupportSection: React.FC<CommunitySupportSectionProps> = ({
  lang,
  countyName,
  state,
  resources,
  selectedResourceIds,
  onToggleResource,
}) => {
  const t = TRANSLATIONS[lang];
  const [activeFilter, setActiveFilter] = useState<'all' | CommunityCategory>('all');
  const [callAlertMsg, setCallAlertMsg] = useState<string | null>(null);

  const filterOptions: { id: 'all' | CommunityCategory; label: string; icon: React.ReactNode }[] = [
    { id: 'all', label: 'All Community Resources', icon: <HandHeart className="w-3.5 h-3.5" /> },
    { id: 'transportation', label: 'Medical Rides & Transit', icon: <Bus className="w-3.5 h-3.5" /> },
    { id: 'food', label: 'Food & Nutrition', icon: <Apple className="w-3.5 h-3.5" /> },
    { id: 'utilities_housing', label: 'Heating & Housing', icon: <Home className="w-3.5 h-3.5" /> },
    { id: 'navigator', label: 'Care Navigator (CHW)', icon: <UserCheck className="w-3.5 h-3.5" /> },
  ];

  const filteredResources = resources.filter((res) => {
    if (activeFilter === 'all') return true;
    return res.category === activeFilter;
  });

  const getCategoryIcon = (category: CommunityCategory) => {
    switch (category) {
      case 'transportation':
        return <Bus className="w-5 h-5 text-seaweed" />;
      case 'food':
        return <Apple className="w-5 h-5 text-emerald-600" />;
      case 'utilities_housing':
        return <Home className="w-5 h-5 text-amber-600" />;
      case 'navigator':
        return <UserCheck className="w-5 h-5 text-purple-600" />;
    }
  };

  const handleAction = (res: CommunityResource) => {
    if (res.phone) {
      setCallAlertMsg(
        `Direct Connection: Connecting you with ${res.name} at ${res.phone}. For immediate ride dispatch, food, or community health worker assistance, keep your county address ready.`
      );
      setTimeout(() => setCallAlertMsg(null), 6000);
    }
  };


  return (
    <div
      id="community-support-section"
      className="bg-white dark:bg-slate-900 rounded-3xl border border-pale-sky/80 dark:border-slate-800 shadow-2xs p-5 sm:p-7 transition-colors"
    >
      {/* Header */}
      <div className="flex items-center gap-3.5 mb-5 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="w-10 h-10 rounded-2xl bg-seaweed-light text-seaweed border border-seaweed/30 flex items-center justify-center font-bold text-base shrink-0 shadow-2xs">
          6
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-xl sm:text-2xl font-bold text-coffee-bean dark:text-slate-100 tracking-tight">
              CommunityRx: Local Health & Social Support
            </h2>
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-seaweed-light text-seaweed-dark dark:bg-seaweed-dark/40 dark:text-seaweed-light border border-seaweed/30">
              Direct Referral Network
            </span>
          </div>
          <p className="text-coffee-bean-muted dark:text-slate-400 text-xs sm:text-sm mt-0.5">
            Connecting medical appointments with free rides, emergency groceries, energy relief, and 1-on-1 care navigators in {countyName}, {state}.
          </p>
        </div>
      </div>

      {/* Reassuring Evidence-Based Notice (Grounded in Drewry, Steeves-Reece, Teggart) */}
      <div className="mb-5 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-pale-sky/80 dark:border-slate-700 text-xs sm:text-sm text-coffee-bean dark:text-slate-300 flex items-start gap-3">
        <Sparkles className="w-5 h-5 text-seaweed shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <span className="font-bold text-coffee-bean dark:text-slate-100">
            Care Beyond the Exam Room:{' '}
          </span>
          Getting to appointments in rural communities requires more than just a hospital list. Select the resources you need below to attach them to your patient visit summary or connect directly with local drivers and food distribution teams.
        </div>
      </div>

      {/* Category Pills Filter */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-4 scrollbar-none">
        {filterOptions.map((opt) => (
          <button
            key={opt.id}
            type="button"
            onClick={() => setActiveFilter(opt.id)}
            className={`shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeFilter === opt.id
                ? 'bg-seaweed text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 hover:bg-pale-sky-light dark:hover:bg-slate-700 text-coffee-bean dark:text-slate-300 border border-pale-sky/60 dark:border-slate-700'
            }`}
          >
            {opt.icon}
            <span>{opt.label}</span>
          </button>
        ))}
      </div>

      {/* Notification Toast Alert */}
      {callAlertMsg && (
        <div className="mb-4 p-3.5 rounded-2xl bg-seaweed-light text-coffee-bean dark:text-slate-200 border border-seaweed/30 text-xs sm:text-sm flex items-start gap-2.5 animate-fadeIn">
          <Info className="w-4 h-4 text-seaweed shrink-0 mt-0.5" />
          <div className="flex-1">{callAlertMsg}</div>
          <button
            type="button"
            onClick={() => setCallAlertMsg(null)}
            className="text-xs font-bold text-seaweed hover:underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Resources Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredResources.map((res) => {
          const isSelected = selectedResourceIds.includes(res.id);
          return (
            <div
              key={res.id}
              className={`rounded-2xl border p-4 transition-all flex flex-col justify-between ${
                isSelected
                  ? 'border-seaweed bg-seaweed-light/20 dark:bg-seaweed-dark/15 shadow-sm ring-1 ring-seaweed/30'
                  : 'border-pale-sky/80 dark:border-slate-800 bg-white dark:bg-slate-800/40 hover:border-seaweed/50'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center shrink-0 shadow-2xs">
                      {getCategoryIcon(res.category)}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm sm:text-base text-coffee-bean dark:text-slate-100 leading-snug">
                        {res.name}
                      </h3>
                      <span className="text-[11px] font-semibold text-seaweed block">
                        {res.serviceType}
                      </span>
                    </div>
                  </div>

                  {/* Add to care plan checkbox */}
                  <label
                    className="flex items-center gap-1.5 cursor-pointer shrink-0"
                    title="Include this resource in my patient intake slip"
                  >
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => onToggleResource(res.id)}
                      className="w-4 h-4 rounded text-seaweed focus:ring-seaweed border-slate-300 dark:border-slate-700"
                    />
                    <span className="text-[11px] font-medium text-coffee-bean-muted dark:text-slate-400 hidden sm:inline">
                      {isSelected ? 'Saved' : 'Add to Plan'}
                    </span>
                  </label>
                </div>

                <p className="text-xs text-coffee-bean dark:text-slate-300 leading-relaxed mb-3">
                  {res.description}
                </p>

                <div className="space-y-1.5 text-[11px] text-coffee-bean-muted dark:text-slate-400 bg-slate-50 dark:bg-slate-900/50 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800 mb-3">
                  <div>
                    <span className="font-bold text-coffee-bean dark:text-slate-200">Who qualifies: </span>
                    {res.eligibility}
                  </div>
                  <div>
                    <span className="font-bold text-coffee-bean dark:text-slate-200">Coverage: </span>
                    {res.coverageArea}
                  </div>
                  {res.phone && (
                    <div className="flex items-center gap-1 text-seaweed font-semibold">
                      <Phone className="w-3 h-3" />
                      <span>{res.phone}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Direct Action Link & Phone Dispatch */}
              <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                {res.phone ? (
                  <a
                    href={`tel:${res.phone.replace(/[^0-9]/g, '')}`}
                    onClick={() => handleAction(res)}
                    className="flex-1 px-3 py-2 rounded-xl bg-seaweed hover:bg-seaweed-hover text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-2xs"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>{res.actionText}</span>
                  </a>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleAction(res)}
                    className="flex-1 px-3 py-2 rounded-xl bg-seaweed hover:bg-seaweed-hover text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
                  >
                    <span>{res.actionText}</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => onToggleResource(res.id)}
                  className={`px-3 py-2 rounded-xl border text-xs font-semibold transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-seaweed-light text-seaweed-dark border-seaweed'
                      : 'bg-white dark:bg-slate-800 hover:bg-slate-100 text-coffee-bean dark:text-slate-200 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {isSelected ? '✓ In My Summary' : '+ Save to Slip'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Direct Care Coordination Note */}
      <div className="mt-5 p-4 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-seaweed-light text-seaweed flex items-center justify-center shrink-0 shadow-2xs">
          <UserCheck className="w-4 h-4" />
        </div>
        <div className="text-xs text-coffee-bean-muted dark:text-slate-400">
          <strong className="text-coffee-bean dark:text-slate-200 block font-semibold">Community Resource Coordination</strong>
          All community food, transit, and shelter services above are verified for rural residents in {countyName}, {state}. Case managers can link clients directly with local dispatch.
        </div>
      </div>
    </div>
  );
};
