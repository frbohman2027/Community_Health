import React, { useState, useRef, useEffect } from 'react';
import {
  Globe,
  Check,
  ChevronDown,
  Sparkles,
  Headphones,
  ShieldCheck,
  Languages,
  Video,
  Phone,
  UserCheck,
  HelpCircle,
} from 'lucide-react';
import { LanguageCode, InterpreterRequest } from '../types';
import { SUPPORTED_LANGUAGES, TRANSLATIONS } from '../utils/translations';

interface LanguageSelectorProps {
  currentLang: LanguageCode;
  onSelectLang: (lang: LanguageCode) => void;
  variant?: 'header' | 'banner' | 'modal';
  interpreterRequest?: InterpreterRequest;
  onInterpreterChange?: (req: InterpreterRequest) => void;
}

const COMMON_INTERPRETER_LANGUAGES = [
  { id: 'Spanish', label: 'Spanish / Español' },
  { id: 'Burmese', label: 'Burmese / မြန်မာ' },
  { id: 'Karen', label: 'Karen / ကညီ' },
  { id: 'Arabic', label: 'Arabic / العربية' },
  { id: 'Vietnamese', label: 'Vietnamese / Tiếng Việt' },
  { id: 'Mandarin', label: 'Mandarin Chinese / 普通话' },
  { id: 'Cantonese', label: 'Cantonese / 广东话' },
  { id: 'German', label: 'German / Deutsch' },
  { id: 'French', label: 'French / Français' },
  { id: 'Somali', label: 'Somali / Soomaali' },
  { id: 'Haitian Creole', label: 'Haitian Creole / Kreyòl Ayisyen' },
  { id: 'ASL', label: 'American Sign Language (ASL)' },
  { id: 'Other', label: 'Other language (type below)' },
];

const DEFAULT_INTERPRETER_REQUEST: InterpreterRequest = {
  needed: false,
  language: 'Spanish',
  format: 'video_or_phone',
};

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({
  currentLang,
  onSelectLang,
  variant = 'header',
  interpreterRequest = DEFAULT_INTERPRETER_REQUEST,
  onInterpreterChange,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [showCustomInput, setShowCustomInput] = useState(
    interpreterRequest.language === 'Other' || Boolean(interpreterRequest.customLanguage)
  );
  const dropdownRef = useRef<HTMLDivElement>(null);
  const activeLangObj =
    SUPPORTED_LANGUAGES.find((l) => l.code === currentLang) || SUPPORTED_LANGUAGES[0];
  const t = TRANSLATIONS[currentLang];

  // Close dropdown if clicked outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleToggleNeedInterpreter = (needed: boolean) => {
    if (!onInterpreterChange) return;
    onInterpreterChange({
      ...interpreterRequest,
      needed,
    });
  };

  const handleLanguageChange = (langChoice: string) => {
    if (!onInterpreterChange) return;
    const isOther = langChoice === 'Other';
    setShowCustomInput(isOther);
    onInterpreterChange({
      ...interpreterRequest,
      language: langChoice,
    });
  };

  const handleFormatChange = (format: 'video_or_phone' | 'in_person' | 'any') => {
    if (!onInterpreterChange) return;
    onInterpreterChange({
      ...interpreterRequest,
      format,
    });
  };

  const handleCustomLangInput = (val: string) => {
    if (!onInterpreterChange) return;
    onInterpreterChange({
      ...interpreterRequest,
      customLanguage: val,
    });
  };

  if (variant === 'banner') {
    return (
      <div
        id="language-choice-section"
        className="bg-white rounded-3xl border border-pale-sky/80 shadow-2xs p-5 sm:p-7 space-y-6"
      >
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-seaweed-light text-seaweed border border-seaweed/30 flex items-center justify-center font-bold text-sm shrink-0 shadow-2xs">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-coffee-bean tracking-tight">
                {t.languageSelect}
              </h2>
              <p className="text-xs sm:text-sm text-coffee-bean-muted mt-0.5">
                Select your preferred language / Elija su idioma preferido / Wählen Sie Ihre Sprache
              </p>
            </div>
          </div>
          <span className="self-start sm:self-auto inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-seaweed-light text-seaweed-dark text-xs font-semibold border border-seaweed/30">
            <Sparkles className="w-3.5 h-3.5 text-seaweed" />
            8 Regional Languages
          </span>
        </div>

        {/* 8-Language Grid with soft, arm's-length touch targets */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {SUPPORTED_LANGUAGES.map((item) => {
            const isSelected = item.code === currentLang;
            return (
              <button
                key={item.code}
                type="button"
                id={`lang-choice-card-${item.code}`}
                onClick={() => onSelectLang(item.code)}
                className={`relative flex flex-col items-start p-3.5 sm:p-4 rounded-2xl border text-left transition-all min-h-[76px] justify-center cursor-pointer ${
                  isSelected
                    ? 'border-seaweed bg-seaweed-light/70 text-coffee-bean shadow-2xs ring-2 ring-seaweed/20'
                    : 'border-pale-sky/80 bg-pale-sky-light/20 hover:bg-seaweed-light/30 hover:border-seaweed text-coffee-bean'
                }`}
              >
                <div className="w-full flex items-center justify-between gap-1">
                  <span className="font-bold text-sm sm:text-base leading-tight">
                    {item.label}
                  </span>
                  {isSelected && (
                    <span className="w-5 h-5 rounded-full bg-seaweed text-white flex items-center justify-center shrink-0 shadow-2xs">
                      <Check className="w-3.5 h-3.5" />
                    </span>
                  )}
                </div>
                <span className="text-xs text-coffee-bean-muted font-medium mt-1">
                  {item.englishLabel}
                </span>
                {item.notes && (
                  <span className="text-[11px] text-seaweed font-medium line-clamp-1 mt-0.5">
                    {item.notes}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* ========================================================================= */}
        {/* NEED AN INTERPRETER SECTION (User Request) */}
        {/* ========================================================================= */}
        <div
          id="need-an-interpreter-card"
          className={`rounded-2xl border transition-all p-4 sm:p-5 ${
            interpreterRequest.needed
              ? 'bg-gradient-to-br from-seaweed-light/70 via-neon-ice/30 to-pale-sky-light/40 border-seaweed shadow-2xs'
              : 'bg-pale-sky-light/20 hover:bg-pale-sky-light/30 border-pale-sky/80'
          }`}
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <div
                className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 transition-colors ${
                  interpreterRequest.needed
                    ? 'bg-seaweed text-white shadow-2xs'
                    : 'bg-seaweed-light text-seaweed-dark'
                }`}
              >
                <Headphones className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-bold text-base sm:text-lg text-coffee-bean">
                    {t.needAnInterpreterTitle || 'Need an interpreter?'}
                  </h3>
                  {interpreterRequest.needed ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-seaweed text-white text-xs font-bold shadow-2xs">
                      <Check className="w-3 h-3" />
                      {t.interpreterRequestedBadge || 'Medical Interpreter Requested'}
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-100 text-coffee-bean text-xs font-semibold">
                      Free Service
                    </span>
                  )}
                </div>
                <p className="text-xs sm:text-sm text-coffee-bean-muted mt-1 leading-relaxed max-w-2xl">
                  {t.needAnInterpreterSubtitle ||
                    'Free certified medical interpreter service for your clinic visits, video telehealth appointments, and phone calls.'}
                </p>
              </div>
            </div>

            {/* Checkbox / Toggle Button */}
            <label
              htmlFor="need-interpreter-checkbox"
              className={`flex items-center gap-2.5 px-4 py-3 rounded-xl border-2 font-bold text-sm cursor-pointer transition-all select-none self-start md:self-auto shrink-0 ${
                interpreterRequest.needed
                  ? 'bg-seaweed border-seaweed text-white shadow-2xs'
                  : 'bg-white border-pale-sky hover:border-seaweed text-coffee-bean shadow-2xs'
              }`}
            >
              <input
                type="checkbox"
                id="need-interpreter-checkbox"
                checked={interpreterRequest.needed}
                onChange={(e) => handleToggleNeedInterpreter(e.target.checked)}
                className="w-4 h-4 rounded text-seaweed focus:ring-seaweed border-slate-300"
              />
              <span>{t.iNeedAnInterpreterCheckbox || 'I need a free medical interpreter'}</span>
            </label>
          </div>

          {/* Expanded Configuration when interpreter is requested */}
          {interpreterRequest.needed && (
            <div
              id="interpreter-details-panel"
              className="mt-4 pt-4 border-t border-seaweed/30 space-y-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Language Choice */}
                <div>
                  <label
                    htmlFor="interpreter-language-select"
                    className="block text-xs sm:text-sm font-bold text-coffee-bean mb-1.5"
                  >
                    {t.interpreterLanguagePrompt || 'Choose your language for the interpreter:'}
                  </label>
                  <select
                    id="interpreter-language-select"
                    value={interpreterRequest.language}
                    onChange={(e) => handleLanguageChange(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-seaweed/40 bg-white text-coffee-bean font-medium text-sm focus:outline-none focus:ring-2 focus:ring-seaweed shadow-2xs"
                  >
                    {COMMON_INTERPRETER_LANGUAGES.map((langOpt) => (
                      <option key={langOpt.id} value={langOpt.id}>
                        {langOpt.label}
                      </option>
                    ))}
                  </select>

                  {showCustomInput && (
                    <div className="mt-2">
                      <input
                        type="text"
                        id="custom-interpreter-lang-input"
                        placeholder="Type your spoken language here (e.g. Swahili, Karenni, Mixtec)..."
                        value={interpreterRequest.customLanguage || ''}
                        onChange={(e) => handleCustomLangInput(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl border border-seaweed/40 bg-white text-coffee-bean text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-seaweed"
                      />
                    </div>
                  )}
                </div>

                {/* Preferred Format */}
                <div>
                  <label className="block text-xs sm:text-sm font-bold text-coffee-bean mb-1.5">
                    {t.interpreterTypeLabel || 'Preferred interpreter format:'}
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <button
                      type="button"
                      id="interpreter-format-video-phone"
                      onClick={() => handleFormatChange('video_or_phone')}
                      className={`px-3 py-2 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        interpreterRequest.format === 'video_or_phone'
                          ? 'bg-seaweed text-white border-seaweed shadow-2xs'
                          : 'bg-white hover:bg-pale-sky-light/40 text-coffee-bean border-pale-sky'
                      }`}
                    >
                      <Video className="w-3.5 h-3.5" />
                      <span>Video / Phone</span>
                    </button>

                    <button
                      type="button"
                      id="interpreter-format-in-person"
                      onClick={() => handleFormatChange('in_person')}
                      className={`px-3 py-2 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        interpreterRequest.format === 'in_person'
                          ? 'bg-seaweed text-white border-seaweed shadow-2xs'
                          : 'bg-white hover:bg-pale-sky-light/40 text-coffee-bean border-pale-sky'
                      }`}
                    >
                      <UserCheck className="w-3.5 h-3.5" />
                      <span>In-Person</span>
                    </button>

                    <button
                      type="button"
                      id="interpreter-format-any"
                      onClick={() => handleFormatChange('any')}
                      className={`px-3 py-2 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                        interpreterRequest.format === 'any'
                          ? 'bg-seaweed text-white border-seaweed shadow-2xs'
                          : 'bg-white hover:bg-pale-sky-light/40 text-coffee-bean border-pale-sky'
                      }`}
                    >
                      <Languages className="w-3.5 h-3.5" />
                      <span>Any Format</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Legal & Patient Rights Notice */}
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-seaweed-light/40 border border-seaweed/30 text-coffee-bean text-xs sm:text-sm">
                <ShieldCheck className="w-4 h-4 text-seaweed shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  {t.interpreterFreeLegalNotice ||
                    'By federal law (Title VI & ACA Section 1557), qualified medical interpreters are provided at NO COST to patients. Hospital & clinic staff will arrange an interpreter for your appointment.'}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Header Dropdown Variant
  return (
    <div className="relative" ref={dropdownRef}>
      <button
        type="button"
        id="header-language-dropdown-btn"
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
        aria-haspopup="true"
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-pale-sky/80 bg-white hover:bg-pale-sky-light/40 text-coffee-bean text-xs sm:text-sm font-semibold transition-colors shadow-2xs cursor-pointer"
        title="Change language / Cambiar idioma"
      >
        <Globe className="w-4 h-4 text-seaweed shrink-0" />
        <span className="max-w-[120px] sm:max-w-none truncate font-bold text-coffee-bean">
          {activeLangObj.label}
        </span>
        {interpreterRequest.needed && (
          <span
            className="w-2 h-2 rounded-full bg-seaweed animate-pulse"
            title="Interpreter Requested"
          />
        )}
        <ChevronDown
          className={`w-3.5 h-3.5 text-coffee-bean-muted transition-transform ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>

      {isOpen && (
        <>
          <div
            className="fixed inset-0 z-50 bg-black/20 backdrop-blur-xs cursor-pointer"
            onClick={() => setIsOpen(false)}
          />
          <div
            id="header-language-menu"
            className="fixed top-24 right-3 sm:right-6 w-[calc(100vw-1.5rem)] max-w-xs sm:w-80 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-pale-sky/80 dark:border-slate-800 p-2 z-50 divide-y divide-slate-100 dark:divide-slate-800 max-h-[80vh] overflow-y-auto"
          >
          <div className="px-3 py-2">
            <span className="text-xs font-bold uppercase tracking-wider text-coffee-bean-muted block">
              Choose Language / Elegir idioma
            </span>
            <span className="text-xs text-coffee-bean block mt-0.5">
              Available in 8 languages for Indiana & regional families
            </span>
          </div>

          <div className="py-1 space-y-1">
            {SUPPORTED_LANGUAGES.map((item) => {
              const isSelected = item.code === currentLang;
              return (
                <button
                  key={item.code}
                  type="button"
                  id={`header-lang-item-${item.code}`}
                  onClick={() => {
                    onSelectLang(item.code);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-seaweed-light text-coffee-bean font-bold'
                      : 'hover:bg-pale-sky-light/30 text-coffee-bean'
                  }`}
                >
                  <div className="flex flex-col">
                    <span className="text-sm font-bold flex items-center gap-2">{item.label}</span>
                    <span className="text-xs text-coffee-bean-muted font-medium">
                      {item.englishLabel} {item.notes ? `• ${item.notes}` : ''}
                    </span>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-seaweed shrink-0" />}
                </button>
              );
            })}
          </div>

          {/* Need an interpreter shortcut in header dropdown */}
          <div className="p-2.5 bg-seaweed-light/40 border border-seaweed/20 rounded-xl mt-1">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Headphones className="w-4 h-4 text-seaweed shrink-0" />
                <span className="text-xs font-bold text-coffee-bean">
                  {t.needAnInterpreterTitle || 'Need an interpreter?'}
                </span>
              </div>
              <input
                type="checkbox"
                id="header-interpreter-toggle"
                checked={interpreterRequest.needed}
                onChange={(e) => handleToggleNeedInterpreter(e.target.checked)}
                className="w-4 h-4 rounded text-seaweed focus:ring-seaweed border-slate-300"
              />
            </div>
            <p className="text-[11px] text-coffee-bean-muted mt-1 leading-snug">
              Free certified medical interpreter available for video and in-clinic visits.
            </p>
          </div>
        </div>
        </>
      )}
    </div>
  );
};
