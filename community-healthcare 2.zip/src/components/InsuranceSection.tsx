import React from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  HeartHandshake,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Building2,
  Phone,
  FileText,
  UserCheck,
} from 'lucide-react';
import { LanguageCode } from '../types';
import { INSURANCE_OPTIONS } from '../data/placeholderData';
import { TRANSLATIONS } from '../utils/translations';

interface InsuranceSectionProps {
  lang: LanguageCode;
  selectedInsuranceId: string;
  onInsuranceChange: (id: string) => void;
}

export const InsuranceSection: React.FC<InsuranceSectionProps> = ({
  lang,
  selectedInsuranceId,
  onInsuranceChange,
}) => {
  const t = TRANSLATIONS[lang];

  // Helper function to check if Case Manager is covered
  const isCaseManagerCovered = (id: string) => {
    return id === 'medicaid-hip' || id === 'medicare' || id === 'veterans-va';
  };

  return (
    <div
      id="insurance-section"
      className="bg-white dark:bg-slate-900 rounded-3xl border border-pale-sky/80 dark:border-slate-800 shadow-2xs p-5 sm:p-7 space-y-5"
    >
      <div className="flex items-center gap-3.5 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="w-10 h-10 rounded-2xl bg-seaweed-light text-seaweed border border-seaweed/30 flex items-center justify-center font-bold text-base shrink-0 shadow-2xs">
          3
        </div>
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-coffee-bean dark:text-slate-100 tracking-tight">
            {t.step3Title || 'Choice of Insurance / Community Health Coverage'}
          </h2>
          <p className="text-coffee-bean-muted dark:text-slate-400 text-xs sm:text-sm mt-0.5">
            {t.step3Subtitle || 'Select your coverage or choose free community care if you do not have insurance.'}
          </p>
        </div>
      </div>

      {/* Insurance Plan Radio Choices */}
      <div className="space-y-3">
        {INSURANCE_OPTIONS.map((ins) => {
          const isSelected = selectedInsuranceId === ins.id;
          const title = ins.localizedTitles?.[lang] || (lang === 'es' ? ins.titleEs : ins.titleEn);
          const desc =
            ins.localizedDescriptions?.[lang] ||
            (lang === 'es' ? ins.descriptionEs : ins.descriptionEn);
          const covered = isCaseManagerCovered(ins.id);

          return (
            <label
              key={ins.id}
              id={`insurance-option-${ins.id}`}
              className={`flex items-start gap-3.5 p-3.5 sm:p-4 rounded-2xl border transition-all cursor-pointer ${
                isSelected
                  ? 'border-seaweed bg-seaweed-light/40 dark:bg-seaweed-dark/30 text-coffee-bean dark:text-slate-100 ring-2 ring-seaweed/20 shadow-2xs'
                  : 'border-pale-sky/80 dark:border-slate-800 bg-pale-sky-light/10 dark:bg-slate-800/40 hover:bg-pale-sky-light/30 hover:border-pale-sky text-coffee-bean dark:text-slate-200'
              }`}
            >
              <div className="pt-0.5 shrink-0">
                <input
                  type="radio"
                  name="insurance"
                  checked={isSelected}
                  onChange={() => onInsuranceChange(ins.id)}
                  className="w-5 h-5 text-seaweed focus:ring-seaweed border-slate-300"
                />
              </div>

              <div className="flex-1">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="font-bold text-sm sm:text-base text-coffee-bean dark:text-slate-100">
                    {title}
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                      covered
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800'
                        : ins.id === 'private-insurance'
                        ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-300 dark:border-amber-800'
                        : 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-300 dark:border-rose-800'
                    }`}
                  >
                    {covered
                      ? '✓ Case Manager Covered'
                      : ins.id === 'private-insurance'
                      ? '⚠️ CM Varies by Rider'
                      : '✕ CM Not Covered'}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-coffee-bean-muted dark:text-slate-400 mt-1 leading-relaxed">
                  {desc}
                </p>
              </div>
            </label>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* CASE MANAGER COVERAGE STATUS BANNER & UNCOVERED OPTIONS                  */}
      {/* ========================================================================= */}
      <div className="pt-2">
        {selectedInsuranceId === 'medicaid-hip' && (
          <div className="p-4 sm:p-5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border-2 border-emerald-300 dark:border-emerald-800 space-y-2">
            <div className="flex items-center gap-2 text-emerald-900 dark:text-emerald-200 font-bold text-sm sm:text-base">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>Case Managers Are 100% Covered by Your Insurance Plan!</span>
            </div>
            <p className="text-xs sm:text-sm text-emerald-950 dark:text-emerald-100 leading-relaxed">
              Your Medicaid / Healthy Indiana Plan (HIP) 100% covers a dedicated Case Manager / Care Coordinator at <strong>$0 copay</strong>. A case manager will help you organize doctor appointments, file for in-home family caregiver pay ($15–$22/hr), coordinate free medical transportation vans, and arrange doorstep meal deliveries.
            </p>
            <div className="text-[11px] text-emerald-800 dark:text-emerald-300 font-semibold flex items-center gap-1.5 pt-1">
              <span>Benefit Type: Medicaid Waiver & MCO Care Management Benefit ($0 Cost)</span>
            </div>
          </div>
        )}

        {selectedInsuranceId === 'medicare' && (
          <div className="p-4 sm:p-5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border-2 border-emerald-300 dark:border-emerald-800 space-y-2">
            <div className="flex items-center gap-2 text-emerald-900 dark:text-emerald-200 font-bold text-sm sm:text-base">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>Case Managers Are Covered by Medicare!</span>
            </div>
            <p className="text-xs sm:text-sm text-emerald-950 dark:text-emerald-100 leading-relaxed">
              Medicare Part B and Medicare Advantage plans cover Chronic Care Management (CCM) and Dedicated Care Coordination with <strong>$0 out-of-pocket copay</strong> for individuals with one or more qualifying ongoing health conditions. Your coordinator helps schedule specialist visits, follow-up tests, in-home safety checks, and prescription drop-offs.
            </p>
            <div className="text-[11px] text-emerald-800 dark:text-emerald-300 font-semibold flex items-center gap-1.5 pt-1">
              <span>Benefit Type: Medicare Part B Chronic Care Management (CCM)</span>
            </div>
          </div>
        )}

        {selectedInsuranceId === 'veterans-va' && (
          <div className="p-4 sm:p-5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border-2 border-emerald-300 dark:border-emerald-800 space-y-2">
            <div className="flex items-center gap-2 text-emerald-900 dark:text-emerald-200 font-bold text-sm sm:text-base">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>Case Managers Are 100% Covered by VA Healthcare!</span>
            </div>
            <p className="text-xs sm:text-sm text-emerald-950 dark:text-emerald-100 leading-relaxed">
              Veterans receiving VA Healthcare have full access to dedicated VA Social Workers and Clinical Case Managers at <strong>$0 cost</strong>. They coordinate community care networks, VA caregiver stipends, and medical travel reimbursements.
            </p>
          </div>
        )}

        {selectedInsuranceId === 'private-insurance' && (
          <div className="p-4 sm:p-5 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border-2 border-amber-300 dark:border-amber-800 space-y-3">
            <div className="flex items-center gap-2 text-amber-950 dark:text-amber-200 font-bold text-sm sm:text-base">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
              <span>Case Manager Coverage Varies by Commercial Policy</span>
            </div>
            <p className="text-xs sm:text-sm text-amber-950 dark:text-amber-100 leading-relaxed">
              Private commercial plans (Anthem, United, Aetna, Cigna, etc.) frequently require special insurance riders or prior hospitalization before paying for private case management.
            </p>
            <div className="bg-white/80 dark:bg-slate-900/80 p-3.5 rounded-xl border border-amber-200 dark:border-amber-800/60 space-y-2 text-xs">
              <strong className="block font-bold text-coffee-bean dark:text-slate-200">
                If your commercial plan does not cover a case manager, use these free options:
              </strong>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-coffee-bean-muted dark:text-slate-300">
                <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <span className="font-bold text-coffee-bean dark:text-slate-100 block">Option 1: FQHC Health Centers</span>
                  Community health centers provide free case navigation with sliding fee clinic care.
                </div>
                <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                  <span className="font-bold text-coffee-bean dark:text-slate-100 block">Option 2: Area Agency on Aging (211)</span>
                  State and county-funded care coordinators who help at $0 regardless of insurance.
                </div>
              </div>
            </div>
          </div>
        )}

        {selectedInsuranceId === 'uninsured' && (
          <div className="p-5 sm:p-6 rounded-3xl bg-rose-50/70 dark:bg-rose-950/30 border-2 border-rose-300 dark:border-rose-800 space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-2xs font-bold text-sm">
                <XCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-rose-950 dark:text-rose-200">
                  Case Manager is Not Covered Under This Option
                </h3>
                <p className="text-xs text-rose-900 dark:text-rose-300 mt-0.5 leading-relaxed">
                  Without insurance coverage, private hospital case management is not automatically billed. However, you do not have to navigate alone.
                </p>
              </div>
            </div>

            {/* A Few Options Supplied to Get a Case Manager at Zero Cost */}
            <div className="space-y-2 pt-1">
              <span className="text-xs font-extrabold uppercase tracking-wider text-rose-950 dark:text-rose-200 block">
                Here are a few options to get a Case Manager at zero cost:
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {/* Option 1 */}
                <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900 shadow-2xs space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-coffee-bean dark:text-slate-100">
                    <Building2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Option 1: Community Health Center (FQHC)</span>
                  </div>
                  <p className="text-coffee-bean-muted dark:text-slate-400 text-[11px] leading-relaxed">
                    Local Federally Qualified Health Centers have grant-funded Case Managers on staff who assist uninsured residents for <strong>$0</strong> with doctors, medications, and food assistance.
                  </p>
                </div>

                {/* Option 2 */}
                <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900 shadow-2xs space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-coffee-bean dark:text-slate-100">
                    <UserCheck className="w-4 h-4 text-purple-600 shrink-0" />
                    <span>Option 2: Area Agency on Aging & 211</span>
                  </div>
                  <p className="text-coffee-bean-muted dark:text-slate-400 text-[11px] leading-relaxed">
                    Public state and county navigators provide free case management and resource linkage for seniors, rural families, and disabled adults. Dial <strong>211</strong> for immediate free connection.
                  </p>
                </div>

                {/* Option 3 */}
                <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900 shadow-2xs space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-coffee-bean dark:text-slate-100">
                    <FileText className="w-4 h-4 text-sky-600 shrink-0" />
                    <span>Option 3: Hospital Charity Care Advocates</span>
                  </div>
                  <p className="text-coffee-bean-muted dark:text-slate-400 text-[11px] leading-relaxed">
                    Regional hospital patient financial counselors will assign an advocate to help you apply for retroactive Medicaid coverage or complete 100% charity care debt forgiveness.
                  </p>
                </div>

                {/* Option 4 */}
                {/* Option 4 */}
                <div className="p-3.5 rounded-2xl bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900 shadow-2xs space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-coffee-bean dark:text-slate-100">
                    <HeartHandshake className="w-4 h-4 text-seaweed shrink-0" />
                    <span>Option 4: Free & Charitable Clinics Network</span>
                  </div>
                  <p className="text-coffee-bean-muted dark:text-slate-400 text-[11px] leading-relaxed">
                    Regional volunteer healthcare providers and faith-based community clinics offer walk-in appointments, free lab tests, and care navigation at zero cost.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
