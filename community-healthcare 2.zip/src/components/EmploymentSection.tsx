import React, { useState } from 'react';
import {
  Briefcase,
  DollarSign,
  Heart,
  Clock,
  MapPin,
  CheckCircle2,
  FileText,
  UserCheck,
  Send,
  Building2,
  Car,
  Award,
  Sparkles,
  Phone,
} from 'lucide-react';
import { EmploymentOpportunity, LanguageCode, StateCode } from '../types';

interface EmploymentSectionProps {
  lang: LanguageCode;
  countyName: string;
  state: StateCode;
}

const OPPORTUNITIES_DATA: EmploymentOpportunity[] = [
  {
    id: 'job-1',
    title: 'Medicaid Paid Family Caregiver Attendant',
    category: 'family_caregiver',
    wageRange: '$15.00 – $22.50 / hour',
    employmentType: 'Family Attendant',
    county: 'All Regional Counties',
    state: 'IN',
    organization: 'Indiana Medicaid Waiver & Attendant Care Program',
    description:
      'Get hired and paid directly by Medicaid to care for your elderly parent, spouse, disabled adult child, or relative at home. State waiver funds compensate you for assistance with bathing, dressing, meal preparation, medication reminders, and companionship.',
    qualifications: [
      'Must be 18 years or older',
      'Relative or friend of an eligible Medicaid/HIP participant',
      'Pass simple background check',
      'No formal clinical license required (free online orientation provided)',
    ],
    howToApply: 'Enroll with local county fiscal agency. Intake takes 48 hours with direct deposit payroll setup.',
    phone: '(800) 457-4584',
    directContact: 'Medicaid Family Attendant Intake Desk',
  },
  {
    id: 'job-2',
    title: 'Certified Home Health Aide (HHA) - Rural Home Visits',
    category: 'hha_cna',
    wageRange: '$18.00 – $24.00 / hour + Mileage',
    employmentType: 'Flexible',
    county: 'Greene, Sullivan, & Monroe Counties',
    state: 'IN',
    organization: 'Rural Community Care Partners',
    description:
      'Provide essential in-home personal care and vital signs monitoring for rural homebound residents. Flexible shifts available with travel reimbursement for country routes.',
    qualifications: [
      'Current State Certified Home Health Aide (HHA) or CNA',
      'Valid driver license and reliable transportation',
      'Compassionate, dependable bedside manner',
    ],
    howToApply: 'Immediate interview slots available this week. Sign-on bonuses offered for rural coverage.',
    phone: '(812) 555-0210',
    directContact: 'Clinical Hiring Coordinator',
  },
  {
    id: 'job-3',
    title: 'Non-Emergency Medical Transit Driver (NEMT)',
    category: 'rural_transit',
    wageRange: '$18.50 – $21.00 / hour',
    employmentType: 'Full-Time',
    county: 'Clay, Parke, & Owen Counties',
    state: 'IN',
    organization: 'Community Mobility & Health Transport',
    description:
      'Drive county-provided wheelchair-accessible vans to transport neighbors to local clinics, dialysis appointments, physical therapy, and pharmacies.',
    qualifications: [
      'Clean driving record (3+ years)',
      'Patient and courteous customer service',
      'CPR/First Aid certification (employer will sponsor if needed)',
    ],
    howToApply: 'Apply online or call dispatch office for on-the-spot screening.',
    phone: '(812) 555-0450',
    directContact: 'Fleet Operations Manager',
  },
  {
    id: 'job-4',
    title: 'Community Health Worker (CHW) / Clinic Patient Navigator',
    category: 'clinic_support',
    wageRange: '$20.00 – $25.00 / hour',
    employmentType: 'Full-Time',
    county: 'Monroe, Lawrence, & Martin Counties',
    state: 'IN',
    organization: 'Federally Qualified Community Health Center',
    description:
      'Assist local patients in navigating free clinics, sliding scale pharmacy benefits, food stamps (SNAP), and housing vouchers. Work directly with case managers and physicians.',
    qualifications: [
      'High school diploma or GED (CHW certification preferred or sponsored)',
      'Familiarity with local county resources and social services',
      'Bilingual skills (Spanish or Burmese) are a strong plus',
    ],
    howToApply: 'Submit resume or complete instant interest form below for clinic team review.',
    phone: '(812) 555-0890',
    directContact: 'Community Outreach Director',
  },
];

export const EmploymentSection: React.FC<EmploymentSectionProps> = ({
  countyName,
  state,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'family_caregiver' | 'hha_cna' | 'clinic_support' | 'rural_transit'>('all');
  const [applicantName, setApplicantName] = useState('');
  const [applicantPhone, setApplicantPhone] = useState('');
  const [applicantEmail, setApplicantEmail] = useState('');
  const [applicantInterest, setApplicantInterest] = useState('family_caregiver');
  const [applicantNotes, setApplicantNotes] = useState('');
  const [applicationSubmitted, setApplicationSubmitted] = useState(false);

  const filteredJobs = OPPORTUNITIES_DATA.filter((job) => {
    if (selectedCategory === 'all') return true;
    return job.category === selectedCategory;
  });

  const handleApplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!applicantName.trim() || !applicantPhone.trim()) return;

    setApplicationSubmitted(true);
    setTimeout(() => {
      setApplicantName('');
      setApplicantPhone('');
      setApplicantEmail('');
      setApplicantNotes('');
    }, 1000);
  };

  return (
    <div id="employment-opportunities-section" className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-800 via-seaweed to-teal-900 text-white rounded-3xl p-6 sm:p-8 shadow-md border border-emerald-700">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-white/20 text-white flex items-center justify-center shrink-0 shadow-sm backdrop-blur-xs">
              <Briefcase className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-400/30 text-emerald-100 font-extrabold text-[11px] uppercase tracking-wider border border-emerald-300/40 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  Employment & Paid Caregiver Portal
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-white font-semibold text-[11px] border border-white/30">
                  Competitive Rural Wages ($15 – $25/hr)
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                Healthcare Jobs & Paid Family Attendant Programs
              </h2>
              <p className="text-emerald-100 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
                Connect with local healthcare organizations, in-home care agencies, or learn how you can get paid by Medicaid ($15–$22/hr) to take care of your own loved ones in {countyName}, {state}.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Highlight Box: Paid Family Caregiver Highlight */}
      <div className="bg-gradient-to-br from-purple-50 via-white to-seaweed-light/30 dark:from-purple-950/40 dark:via-slate-900 dark:to-slate-900 rounded-3xl border-2 border-purple-300 dark:border-purple-800 p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <span className="px-2.5 py-0.5 rounded-full bg-purple-200 dark:bg-purple-900 text-purple-900 dark:text-purple-200 font-extrabold text-[11px] uppercase tracking-wider inline-block">
              State Medicaid Paid Family Care
            </span>
            <h3 className="text-lg sm:text-xl font-bold text-coffee-bean dark:text-slate-100">
              Get Paid $15 to $22/Hour to Care for a Family Member
            </h3>
            <p className="text-xs sm:text-sm text-coffee-bean-muted dark:text-slate-300 leading-relaxed">
              If your parent, spouse, grandparent, or disabled relative receives Medicaid / Healthy Indiana Plan (HIP), state waiver programs permit them to designate you as their official paid attendant. You receive regular weekly direct-deposit wages for everyday assistance.
            </p>
          </div>

          <a
            href="#apply-form"
            className="px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs sm:text-sm font-bold flex items-center gap-2 transition-all shadow-sm active:scale-95 shrink-0"
          >
            <span>Apply for Family Pay</span>
            <DollarSign className="w-4 h-4 text-emerald-300" />
          </a>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <button
          type="button"
          onClick={() => setSelectedCategory('all')}
          className={`px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer whitespace-nowrap ${
            selectedCategory === 'all'
              ? 'bg-seaweed text-white'
              : 'bg-white dark:bg-slate-800 text-coffee-bean-muted dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
          }`}
        >
          All Opportunities ({OPPORTUNITIES_DATA.length})
        </button>
        <button
          type="button"
          onClick={() => setSelectedCategory('family_caregiver')}
          className={`px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer whitespace-nowrap ${
            selectedCategory === 'family_caregiver'
              ? 'bg-purple-700 text-white'
              : 'bg-white dark:bg-slate-800 text-coffee-bean-muted dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
          }`}
        >
          Paid Family Caregiver ($15–$22/hr)
        </button>
        <button
          type="button"
          onClick={() => setSelectedCategory('hha_cna')}
          className={`px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer whitespace-nowrap ${
            selectedCategory === 'hha_cna'
              ? 'bg-seaweed text-white'
              : 'bg-white dark:bg-slate-800 text-coffee-bean-muted dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
          }`}
        >
          Home Health Aide (HHA / CNA)
        </button>
        <button
          type="button"
          onClick={() => setSelectedCategory('rural_transit')}
          className={`px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer whitespace-nowrap ${
            selectedCategory === 'rural_transit'
              ? 'bg-seaweed text-white'
              : 'bg-white dark:bg-slate-800 text-coffee-bean-muted dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
          }`}
        >
          Medical Van Drivers
        </button>
        <button
          type="button"
          onClick={() => setSelectedCategory('clinic_support')}
          className={`px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer whitespace-nowrap ${
            selectedCategory === 'clinic_support'
              ? 'bg-seaweed text-white'
              : 'bg-white dark:bg-slate-800 text-coffee-bean-muted dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
          }`}
        >
          Clinic Navigators & Assistants
        </button>
      </div>

      {/* Job Opportunity Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredJobs.map((job) => (
          <div
            key={job.id}
            className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-3 flex flex-col justify-between"
          >
            <div className="space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h4 className="font-bold text-base text-coffee-bean dark:text-slate-100">
                    {job.title}
                  </h4>
                  <p className="text-xs text-coffee-bean-muted dark:text-slate-400 mt-0.5">
                    {job.organization}
                  </p>
                </div>
                <span className="text-xs font-extrabold px-2.5 py-1 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 whitespace-nowrap">
                  {job.wageRange}
                </span>
              </div>

              <div className="flex items-center gap-3 text-xs text-coffee-bean-muted dark:text-slate-400">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-seaweed" />
                  <span>{job.county}</span>
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-seaweed" />
                  <span>{job.employmentType}</span>
                </span>
              </div>

              <p className="text-xs text-coffee-bean dark:text-slate-300 leading-relaxed pt-1">
                {job.description}
              </p>

              <div className="space-y-1 pt-1">
                <span className="text-[11px] font-bold text-coffee-bean dark:text-slate-200 uppercase tracking-wider block">
                  Qualifications & Details:
                </span>
                <ul className="text-xs text-coffee-bean-muted dark:text-slate-400 space-y-0.5">
                  {job.qualifications.map((q, idx) => (
                    <li key={idx} className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{q}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
              {job.phone && (
                <a
                  href={`tel:${job.phone}`}
                  className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-coffee-bean dark:text-slate-200 text-xs font-semibold flex items-center gap-1"
                >
                  <Phone className="w-3 h-3 text-seaweed" />
                  <span>Call {job.phone}</span>
                </a>
              )}
              <a
                href="#apply-form"
                onClick={() => setApplicantInterest(job.category)}
                className="px-3 py-1.5 rounded-xl bg-seaweed hover:bg-seaweed-hover text-white text-xs font-bold transition-colors"
              >
                Apply / Inquire
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Application & In-County Job Inquiry Form */}
      <div
        id="apply-form"
        className="bg-white dark:bg-slate-900 rounded-3xl border border-pale-sky/80 dark:border-slate-800 p-5 sm:p-7 shadow-sm space-y-4"
      >
        <div className="flex items-center gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="w-10 h-10 rounded-2xl bg-seaweed-light text-seaweed flex items-center justify-center font-bold">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-coffee-bean dark:text-slate-100">
              Healthcare Employment & Family Attendant Sign-Up
            </h3>
            <p className="text-xs text-coffee-bean-muted dark:text-slate-400">
              Submit your information to connect directly with local care agencies and Medicaid fiscal coordinators in {countyName}, {state}.
            </p>
          </div>
        </div>

        {applicationSubmitted ? (
          <div className="p-6 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
            <h4 className="font-bold text-base text-emerald-950 dark:text-emerald-100">
              Application & Inquiry Received!
            </h4>
            <p className="text-xs text-emerald-800 dark:text-emerald-300 max-w-md mx-auto">
              A local care agency coordinator for {countyName} will contact you by phone shortly with enrollment steps and next paperwork details.
            </p>
            <button
              type="button"
              onClick={() => setApplicationSubmitted(false)}
              className="mt-2 text-xs font-bold text-emerald-700 dark:text-emerald-300 underline cursor-pointer"
            >
              Submit another inquiry
            </button>
          </div>
        ) : (
          <form onSubmit={handleApplySubmit} className="space-y-3 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-coffee-bean dark:text-slate-200 mb-1">
                  Your Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={applicantName}
                  onChange={(e) => setApplicantName(e.target.value)}
                  placeholder="e.g. Maria Gonzalez"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-coffee-bean dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-semibold text-coffee-bean dark:text-slate-200 mb-1">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  required
                  value={applicantPhone}
                  onChange={(e) => setApplicantPhone(e.target.value)}
                  placeholder="(812) 555-0199"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-coffee-bean dark:text-slate-100"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-coffee-bean dark:text-slate-200 mb-1">
                  Email Address (Optional)
                </label>
                <input
                  type="email"
                  value={applicantEmail}
                  onChange={(e) => setApplicantEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-coffee-bean dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block font-semibold text-coffee-bean dark:text-slate-200 mb-1">
                  Position / Opportunity of Interest *
                </label>
                <select
                  value={applicantInterest}
                  onChange={(e) => setApplicantInterest(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-coffee-bean dark:text-slate-100"
                >
                  <option value="family_caregiver">Medicaid Paid Family Attendant ($15–$22/hr)</option>
                  <option value="hha_cna">Certified Home Health Aide (HHA) / CNA ($18–$24/hr)</option>
                  <option value="rural_transit">Non-Emergency Medical Driver ($18.50–$21/hr)</option>
                  <option value="clinic_support">Community Clinic Navigator ($20–$25/hr)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-coffee-bean dark:text-slate-200 mb-1">
                Tell us about your experience or the family member you wish to care for
              </label>
              <textarea
                rows={3}
                value={applicantNotes}
                onChange={(e) => setApplicantNotes(e.target.value)}
                placeholder="Mention if you have prior caregiver experience, or describe who you are looking to support..."
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-coffee-bean dark:text-slate-100"
              />
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-seaweed hover:bg-seaweed-hover text-white text-xs sm:text-sm font-bold flex items-center gap-2 transition-all shadow-sm active:scale-95 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Submit Employment / Caregiver Inquiry</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
