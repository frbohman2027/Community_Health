import React, { useState, useMemo } from 'react';
import {
  Building2,
  Stethoscope,
  UserCheck,
  MapPin,
  AlertCircle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Globe,
  ExternalLink,
  PhoneCall,
  Search,
  Check,
} from 'lucide-react';
import { Hospital, LanguageCode, StateCode } from '../types';
import { PLACEHOLDER_HOSPITALS, PLACEHOLDER_COUNTIES } from '../data/placeholderData';
import { TRANSLATIONS } from '../utils/translations';
import { get15ClosestHospitals, HospitalWithDistance } from '../utils/hospitalProximity';

interface HospitalsSectionProps {
  lang: LanguageCode;
  selectedCountyCode: string;
  selectedState: StateCode | 'ALL';
  selectedHospitalId: string;
  onSelectHospital: (id: string) => void;
  onCallAndTalk?: (hospital?: Hospital) => void;
}

export const HospitalsSection: React.FC<HospitalsSectionProps> = ({
  lang,
  selectedCountyCode,
  selectedState,
  selectedHospitalId,
  onSelectHospital,
  onCallAndTalk,
}) => {
  const t = TRANSLATIONS[lang];
  const [searchTerm, setSearchTerm] = useState('');
  const [showAll15, setShowAll15] = useState(false);
  const [showAllRegional, setShowAllRegional] = useState(false);

  // Look up county name
  const currentCounty = PLACEHOLDER_COUNTIES.find((c) => c.code === selectedCountyCode);
  const countyName = currentCounty?.name || 'Selected County';

  // 15 closest hospitals sorted by distance from the chosen county
  const closest15Hospitals = useMemo(
    () => get15ClosestHospitals(selectedCountyCode),
    [selectedCountyCode]
  );

  // 5 closest hospitals automatic default
  const automatic5Closest = useMemo(
    () => closest15Hospitals.slice(0, 5),
    [closest15Hospitals]
  );

  // Active selected hospital object
  const currentSelectedHospital =
    closest15Hospitals.find((h) => h.id === selectedHospitalId) ||
    closest15Hospitals[0] ||
    PLACEHOLDER_HOSPITALS[0];

  // Base list of hospital cards to display:
  // Default is the 5 closest hospitals (automatic).
  // If the user selects a hospital from the 15-closest dropdown that is outside the top 5, include it as well.
  const baseCardHospitals = useMemo(() => {
    if (showAll15) {
      return closest15Hospitals;
    }
    const list = [...automatic5Closest];
    if (selectedHospitalId && !list.some((h) => h.id === selectedHospitalId)) {
      const selectedHosp = closest15Hospitals.find((h) => h.id === selectedHospitalId);
      if (selectedHosp) {
        list.push(selectedHosp);
      }
    }
    return list;
  }, [showAll15, closest15Hospitals, automatic5Closest, selectedHospitalId]);

  // Search filter applied to hospital boxes
  const normalizedSearch = searchTerm.trim().toLowerCase();
  const filteredBoxes = baseCardHospitals.filter((h) => {
    if (!normalizedSearch) return true;
    return (
      h.name.toLowerCase().includes(normalizedSearch) ||
      h.countyName.toLowerCase().includes(normalizedSearch) ||
      h.address.toLowerCase().includes(normalizedSearch) ||
      h.state.toLowerCase().includes(normalizedSearch)
    );
  });

  const countyHasDirectHospital = closest15Hospitals.some(
    (h) => h.countyCode === selectedCountyCode
  );

  return (
    <div
      id="hospitals-section"
      className="bg-white rounded-3xl border border-pale-sky/80 shadow-[0_2px_14px_-4px_rgba(25,21,22,0.04)] p-5 sm:p-7"
    >
      <div className="flex items-center gap-3.5 mb-5 pb-3 border-b border-pale-sky/60">
        <div className="w-10 h-10 rounded-2xl bg-seaweed-light text-seaweed border border-seaweed/30 flex items-center justify-center font-bold text-base shrink-0 shadow-2xs">
          4
        </div>
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-coffee-bean tracking-tight">
            {t.step4Title}
          </h2>
          <p className="text-coffee-bean-muted text-xs sm:text-sm mt-0.5">{t.step4Subtitle}</p>
        </div>
      </div>

      {!countyHasDirectHospital && !normalizedSearch && (
        <div className="mb-5 p-3.5 rounded-2xl bg-pale-sky-light border border-pale-sky text-coffee-bean text-xs sm:text-sm flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-seaweed shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-coffee-bean">Note for {countyName}: </span>
            Showing regional healthcare centers and closest available hospitals sorted by drive distance.
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* HOSPITAL CHOICE BOXES: 5 closest automatic + 15 closest drop down menu    */}
      {/* ========================================================================= */}
      <div
        id="hospital-boxes-container"
        className="mb-8 p-4 sm:p-5 rounded-2xl bg-pale-sky-light/40 border border-pale-sky shadow-2xs"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
          <div>
            <h3 className="font-bold text-coffee-bean text-sm sm:text-base flex items-center gap-2">
              <Building2 className="w-4 h-4 text-seaweed shrink-0" />
              <span>{t.chooseHospitalBoxTitle || 'Choose Your Hospital / Clinic:'}</span>
            </h3>
            <p className="text-xs text-coffee-bean-muted mt-0.5">
              {showAll15
                ? 'Showing all 15 closest facilities'
                : '5 closest hospitals automatically shown below • Select any of the 15 closest in the drop-down menu'}
            </p>
          </div>
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="text-xs font-bold text-coffee-bean bg-white px-3 py-1 rounded-full border border-pale-sky shadow-2xs">
              {showAll15 ? 'Showing 15 Closest' : '5 Closest (Automatic)'}
            </span>
            <button
              type="button"
              id="toggle-15-hospitals-btn"
              onClick={() => setShowAll15(!showAll15)}
              className="text-xs text-seaweed hover:text-seaweed-hover font-bold underline cursor-pointer"
            >
              {showAll15 ? 'Show 5 Closest' : 'View All 15'}
            </button>
          </div>
        </div>

        {/* Hospital Dropdown Menu (With 15 Closest Hospitals) */}
        <div className="mb-3.5">
          <div className="flex items-center justify-between mb-1.5">
            <label
              htmlFor="hospital-dropdown"
              className="block font-bold text-coffee-bean text-xs sm:text-sm"
            >
              Select Hospital from Drop Down Menu (15 Closest Hospitals):
            </label>
            <span className="text-[11px] font-semibold text-seaweed-dark bg-seaweed-light/70 px-2.5 py-0.5 rounded-full border border-seaweed/30">
              15 Closest
            </span>
          </div>
          <select
            id="hospital-dropdown"
            value={currentSelectedHospital?.id || ''}
            onChange={(e) => onSelectHospital(e.target.value)}
            className="w-full text-sm sm:text-base p-3.5 rounded-2xl border border-pale-sky bg-white text-coffee-bean font-semibold focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20 shadow-2xs cursor-pointer"
          >
            {closest15Hospitals.map((h, idx) => (
              <option key={h.id} value={h.id}>
                #{idx + 1} {h.name} ({h.countyName}, {h.state}) • {h.distanceMiles} {h.hasEmergencyRoom ? '• 24/7 ER' : ''}
              </option>
            ))}
          </select>
        </div>

        {/* Quick search input to filter the hospital boxes */}
        <div className="relative mb-3.5">
          <Search className="w-4 h-4 text-coffee-bean-muted absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            id="hospital-search-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Type to filter hospital boxes by name, town, or county..."
            className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm rounded-xl border border-pale-sky bg-white text-coffee-bean placeholder:text-coffee-bean-muted focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-neon-ice/40 transition-all shadow-2xs"
          />
        </div>

        {/* Grid of Hospital Boxes (Automatic 5 Closest) */}
        <div
          id="hospital-boxes-grid"
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3"
        >
          {filteredBoxes.map((hospital) => {
            const isSelected = selectedHospitalId === hospital.id;
            const rank = closest15Hospitals.findIndex((h) => h.id === hospital.id) + 1;

            return (
              <button
                type="button"
                key={hospital.id}
                id={`hospital-choice-box-${hospital.id}`}
                onClick={() => onSelectHospital(hospital.id)}
                aria-pressed={isSelected}
                className={`group text-left p-4 rounded-2xl border transition-all flex flex-col justify-between relative cursor-pointer ${
                  isSelected
                    ? 'border-seaweed bg-seaweed-light ring-2 ring-neon-ice/40 shadow-xs'
                    : 'border-pale-sky/80 bg-white hover:border-seaweed hover:bg-pale-sky-light/40 shadow-2xs'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-coffee-bean">
                        #{rank} Closest
                      </span>
                      <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-pale-sky-light text-coffee-bean border border-pale-sky">
                        {hospital.distanceMiles}
                      </span>
                      {hospital.countyCode === selectedCountyCode && (
                        <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-seaweed-light text-seaweed-dark border border-seaweed/30">
                          Local County
                        </span>
                      )}
                    </div>

                    {isSelected ? (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-seaweed text-white shadow-2xs shrink-0">
                        <Check className="w-3 h-3" />
                        <span>Selected</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-coffee-bean-muted group-hover:text-seaweed-dark bg-slate-50 group-hover:bg-seaweed-light px-2.5 py-0.5 rounded-full border border-slate-200/80 group-hover:border-seaweed/30 transition-colors shrink-0">
                        {t.clickToChooseHospital || 'Click to choose'}
                      </span>
                    )}
                  </div>

                  <h4 className="font-bold text-sm sm:text-base text-coffee-bean leading-snug group-hover:text-seaweed-dark transition-colors">
                    {hospital.name}
                  </h4>

                  <p className="text-xs text-coffee-bean-muted flex items-center gap-1 mt-1.5">
                    <MapPin className="w-3.5 h-3.5 text-coffee-bean-muted shrink-0" />
                    <span className="truncate">{hospital.address}</span>
                  </p>
                </div>

                <div className="mt-3.5 pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
                  {hospital.hasEmergencyRoom ? (
                    <span className="inline-flex items-center gap-1.5 text-[11px] font-bold px-2 py-0.5 rounded-md bg-cherry-rose-light text-cherry-rose border border-cherry-rose/20">
                      <span className="w-1.5 h-1.5 rounded-full bg-cherry-rose animate-pulse"></span>
                      24/7 ER
                    </span>
                  ) : (
                    <span className="text-[11px] text-coffee-bean-muted font-medium">Clinic Care</span>
                  )}

                  <span
                    className={`text-xs font-semibold transition-colors ${
                      isSelected ? 'text-seaweed-dark font-bold' : 'text-coffee-bean-muted group-hover:text-seaweed-dark'
                    }`}
                  >
                    {isSelected ? '✓ Chosen' : 'Choose Hospital →'}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* ACTIVE SELECTED HOSPITAL DETAILS & DOCTOR SCHEDULES                       */}
      {/* ========================================================================= */}
      {currentSelectedHospital && (
        <div
          id={`hospital-card-${currentSelectedHospital.id}`}
          className="mb-8 rounded-3xl border border-pale-sky bg-gradient-to-br from-white via-pale-sky-light/30 to-seaweed-light/40 p-5 sm:p-6 shadow-2xs"
        >
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-4 border-b border-pale-sky/60">
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-1.5">
                <span className="text-xs font-bold uppercase tracking-wider text-white bg-seaweed px-2.5 py-0.5 rounded-full border border-seaweed-dark flex items-center gap-1 shadow-2xs">
                  <Check className="w-3 h-3" />
                  Currently Chosen Hospital
                </span>
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-white text-coffee-bean border border-pale-sky">
                  {currentSelectedHospital.state} • {currentSelectedHospital.countyName}
                </span>
                {currentSelectedHospital.hasEmergencyRoom && (
                  <span className="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full bg-cherry-rose-light text-cherry-rose border border-cherry-rose/20">
                    <span className="w-1.5 h-1.5 rounded-full bg-cherry-rose animate-pulse"></span>
                    {t.emergencyRoomAvailable}
                  </span>
                )}
              </div>

              <h3 className="text-xl sm:text-2xl font-bold text-coffee-bean">
                {currentSelectedHospital.name}
              </h3>
              <div className="flex items-center gap-1.5 text-xs sm:text-sm text-coffee-bean-muted mt-1">
                <MapPin className="w-3.5 h-3.5 text-coffee-bean-muted shrink-0" />
                <span>{currentSelectedHospital.address}</span>
              </div>

              {/* Direct Hospital Actions */}
              <div className="mt-3.5 flex flex-wrap items-center gap-2">
                {currentSelectedHospital.websiteUrl && (
                  <a
                    href={currentSelectedHospital.websiteUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    id={`hospital-main-website-${currentSelectedHospital.id}`}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-pale-sky-light text-coffee-bean font-semibold text-xs sm:text-sm border border-pale-sky transition-colors shadow-2xs"
                    title={`Open ${currentSelectedHospital.name} Official Website`}
                  >
                    <Globe className="w-3.5 h-3.5 text-seaweed shrink-0" />
                    <span>{t.visitHospitalWebsite || 'Visit Hospital Website'}</span>
                    <ExternalLink className="w-3 h-3 text-coffee-bean-muted shrink-0" />
                  </a>
                )}

                <button
                  type="button"
                  onClick={() => onCallAndTalk?.(currentSelectedHospital)}
                  id={`hospital-call-talk-${currentSelectedHospital.id}`}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-seaweed-light text-seaweed-dark font-semibold text-xs sm:text-sm border border-seaweed/40 transition-colors shadow-2xs cursor-pointer"
                  title="Speak directly with clinic care team via voice"
                >
                  <PhoneCall className="w-3.5 h-3.5 text-seaweed shrink-0" />
                  <span>{t.callAndTalk || 'Call & Talk'}</span>
                </button>

              </div>
            </div>
          </div>

          {/* Doctors Availability for chosen hospital */}
          <div className="mt-4">
            <h4 className="text-xs font-bold text-coffee-bean-muted flex items-center gap-1.5 mb-2.5 uppercase tracking-wide">
              <Stethoscope className="w-3.5 h-3.5 text-seaweed" />
              <span>
                {t.doctorsAvailableTitle} ({currentSelectedHospital.doctors.length} Doctors on Schedule)
              </span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {currentSelectedHospital.doctors.map((doc, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-2xl bg-white border border-pale-sky text-sm flex flex-col justify-between shadow-2xs"
                >
                  <div>
                    <div className="font-bold text-coffee-bean text-sm mb-1">
                      {doc.specialty}
                    </div>
                    <p className="text-coffee-bean-muted text-xs leading-relaxed mb-2">
                      {doc.notes}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-1.5 pt-2 border-t border-slate-100">
                    <span className="text-xs text-coffee-bean-muted">
                      Next open slot: <strong className="text-seaweed-dark">{doc.nextOpenSlot}</strong>
                    </span>
                    {doc.telehealthAvailable ? (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-lg bg-seaweed-light text-seaweed-dark border border-seaweed/30">
                        <PhoneCall className="w-3.5 h-3.5 text-seaweed" />
                        <span>{t.telehealthBadge}</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-md bg-slate-100 text-coffee-bean">
                        <UserCheck className="w-3 h-3" />
                        {t.inPersonBadge}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Option to toggle viewing all hospital cards */}
      <div className="text-center pt-1">
        <button
          type="button"
          onClick={() => setShowAllRegional(!showAllRegional)}
          className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-seaweed-dark hover:text-coffee-bean underline p-2 cursor-pointer"
        >
          {showAllRegional ? (
            <>
              <ChevronUp className="w-4 h-4" />
              <span>Hide additional regional schedules</span>
            </>
          ) : (
            <>
              <ChevronDown className="w-4 h-4" />
              <span>Compare doctor schedules across all regional centers</span>
            </>
          )}
        </button>
      </div>

      {/* Expanded list of other hospital cards when user chooses to compare */}
      {showAllRegional && (
        <div className="mt-5 space-y-4 pt-4 border-t border-pale-sky/60">
          <h3 className="text-xs font-bold uppercase tracking-wider text-coffee-bean-muted">
            All Regional Hospital Schedules
          </h3>

          {closest15Hospitals.filter((h) => h.id !== selectedHospitalId).map((hospital) => (
            <div
              key={hospital.id}
              id={`hospital-card-${hospital.id}`}
              className="rounded-2xl border border-pale-sky/80 bg-white hover:border-seaweed transition-all p-4 sm:p-5 shadow-2xs"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-3 border-b border-slate-100">
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 text-coffee-bean">
                      #{closest15Hospitals.findIndex((h) => h.id === hospital.id) + 1} Closest
                    </span>
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-pale-sky-light text-coffee-bean border border-pale-sky">
                      {hospital.distanceMiles}
                    </span>
                    <h3 className="text-base sm:text-lg font-bold text-coffee-bean">{hospital.name}</h3>
                    <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-slate-100 text-coffee-bean">
                      {hospital.state} • {hospital.countyName}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-coffee-bean-muted">
                    <MapPin className="w-3.5 h-3.5 text-coffee-bean-muted shrink-0" />
                    <span>{hospital.address}</span>
                  </div>

                  <div className="mt-2.5 flex flex-wrap items-center gap-2">
                    {hospital.websiteUrl && (
                      <a
                        href={hospital.websiteUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-white hover:bg-pale-sky-light text-coffee-bean font-semibold text-xs border border-pale-sky transition-colors shadow-2xs"
                      >
                        <Globe className="w-3.5 h-3.5 text-seaweed shrink-0" />
                        <span>{t.visitHospitalWebsite || 'Visit Website'}</span>
                        <ExternalLink className="w-3 h-3 text-coffee-bean-muted shrink-0" />
                      </a>
                    )}

                    <button
                      type="button"
                      onClick={() => onCallAndTalk?.(hospital)}
                      className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-white hover:bg-seaweed-light text-seaweed-dark font-semibold text-xs border border-seaweed/40 transition-colors shadow-2xs cursor-pointer"
                    >
                      <PhoneCall className="w-3.5 h-3.5 text-seaweed shrink-0" />
                      <span>{t.callAndTalk || 'Call & Talk'}</span>
                    </button>
                  </div>
                </div>

                <div className="shrink-0 flex sm:flex-col items-center sm:items-end gap-2">
                  {hospital.hasEmergencyRoom && (
                    <span className="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full bg-cherry-rose-light text-cherry-rose border border-cherry-rose/20">
                      <span className="w-1.5 h-1.5 rounded-full bg-cherry-rose animate-pulse"></span>
                      {t.emergencyRoomAvailable}
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={() => onSelectHospital(hospital.id)}
                    className="text-xs sm:text-sm px-3.5 py-1.5 rounded-xl font-bold bg-slate-100 hover:bg-seaweed-light text-coffee-bean hover:text-seaweed-dark border border-pale-sky transition-colors cursor-pointer"
                  >
                    Select this hospital
                  </button>
                </div>
              </div>

              {/* Doctors Availability */}
              <div className="mt-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {hospital.doctors.map((doc, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-50/70 border border-slate-200/70 text-xs flex flex-col justify-between"
                    >
                      <div>
                        <div className="font-bold text-slate-900 text-xs sm:text-sm mb-0.5">
                          {doc.specialty}
                        </div>
                        <p className="text-slate-600 leading-relaxed mb-2">
                          {doc.notes}
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center justify-between gap-1.5 pt-1.5 border-t border-slate-200/60">
                        <span className="text-slate-700">
                          Next slot: <strong className="text-slate-900">{doc.nextOpenSlot}</strong>
                        </span>
                        {doc.telehealthAvailable ? (
                          <span className="inline-flex items-center gap-1 font-semibold px-2 py-0.5 rounded bg-teal-50 text-teal-800 border border-teal-200">
                            <PhoneCall className="w-3 h-3 text-teal-700" />
                            <span>{t.telehealthBadge}</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 font-medium px-2 py-0.5 rounded bg-slate-200/80 text-slate-700">
                            <UserCheck className="w-3 h-3" />
                            {t.inPersonBadge}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
