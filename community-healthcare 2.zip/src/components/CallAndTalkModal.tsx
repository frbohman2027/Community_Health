import React, { useState, useEffect, useRef } from 'react';
import {
  Phone,
  PhoneOff,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  User,
  ShieldCheck,
  Sparkles,
  HelpCircle,
  Truck,
  DollarSign,
  Clock,
  Send,
  Radio,
  Headphones,
} from 'lucide-react';
import { Hospital, LanguageCode, InterpreterRequest } from '../types';
import { TRANSLATIONS } from '../utils/translations';

interface CallAndTalkModalProps {
  isOpen: boolean;
  onClose: () => void;
  hospital?: Hospital | null;
  lang: LanguageCode;
  interpreterRequest?: InterpreterRequest;
}

interface DialogueTurn {
  speaker: 'nurse' | 'user';
  text: string;
  time: string;
}

export const CallAndTalkModal: React.FC<CallAndTalkModalProps> = ({
  isOpen,
  onClose,
  hospital,
  lang,
  interpreterRequest,
}) => {
  const t = TRANSLATIONS[lang];
  const [callStatus, setCallStatus] = useState<'connecting' | 'connected' | 'ended'>('connecting');
  const [callDuration, setCallDuration] = useState(0);
  const [isMicMuted, setIsMicMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [isSpeakingNow, setIsSpeakingNow] = useState(false);
  const [customQuestion, setCustomQuestion] = useState('');
  const [dialogue, setDialogue] = useState<DialogueTurn[]>([]);
  const transcriptEndRef = useRef<HTMLDivElement | null>(null);

  const clinicName = hospital ? hospital.name : 'Rural Community Health Care Desk';

  // Speak aloud helper
  const speakText = (textToSpeak: string) => {
    if (!isSpeakerOn) return;
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel(); // Stop any pending speech
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.rate = 0.95; // Slightly slower for easy 8th-grade listening
      utterance.pitch = 1.0;
      utterance.onstart = () => setIsSpeakingNow(true);
      utterance.onend = () => setIsSpeakingNow(false);
      utterance.onerror = () => setIsSpeakingNow(false);
      window.speechSynthesis.speak(utterance);
    }
  };

  // Initialize call
  useEffect(() => {
    if (!isOpen) {
      setCallStatus('connecting');
      setCallDuration(0);
      setDialogue([]);
      setIsSpeakingNow(false);
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      return;
    }

    // Connecting sound / delay
    setCallStatus('connecting');
    const connectTimer = setTimeout(() => {
      setCallStatus('connected');
      const initialGreeting = `Hello, thank you for calling ${clinicName}. My name is Brenda, your nurse on duty. How may we help you or your family today?`;
      const initialTurn: DialogueTurn = {
        speaker: 'nurse',
        text: initialGreeting,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setDialogue([initialTurn]);
      speakText(initialGreeting);
    }, 1500);

    return () => {
      clearTimeout(connectTimer);
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [isOpen, clinicName]);

  // Duration timer
  useEffect(() => {
    if (callStatus !== 'connected') return;

    const interval = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [callStatus]);

  // Auto-scroll transcript
  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [dialogue]);

  const handleSelectTopic = (userQuery: string, nurseAnswer: string) => {
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Add user message
    const userTurn: DialogueTurn = {
      speaker: 'user',
      text: userQuery,
      time: timeStr,
    };

    setDialogue((prev) => [...prev, userTurn]);

    // Nurse replies after short pause
    setTimeout(() => {
      const nurseTurn: DialogueTurn = {
        speaker: 'nurse',
        text: nurseAnswer,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setDialogue((prev) => [...prev, nurseTurn]);
      speakText(nurseAnswer);
    }, 700);
  };

  const handleCustomQuestionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customQuestion.trim()) return;

    const query = customQuestion.trim();
    setCustomQuestion('');

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setDialogue((prev) => [
      ...prev,
      {
        speaker: 'user',
        text: query,
        time: timeStr,
      },
    ]);

    setTimeout(() => {
      const answer = `Thank you for asking about that. Our clinic staff can assist you with that today. If you need immediate care, our urgent care is open, or we can connect you directly with a provider or arrange delivery.`;
      setDialogue((prev) => [
        ...prev,
        {
          speaker: 'nurse',
          text: answer,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      speakText(answer);
    }, 900);
  };

  const handleHangUp = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setCallStatus('ended');
    setTimeout(() => {
      onClose();
    }, 400);
  };

  if (!isOpen) return null;

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainder = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainder.toString().padStart(2, '0')}`;
  };

  const quickOptions = [
    {
      label: 'Can I schedule a doctor visit today?',
      query: 'I would like to know if a doctor or nurse practitioner is available for a visit today.',
      response:
        'Yes! We have walk-in clinic slots and same-day family care appointments open. You can come directly to the clinic or do a video call right here.',
      icon: Clock,
    },
    {
      label: 'Can prescriptions be dropped off to my house?',
      query: 'I live out in the country and cannot easily pick up my medicine. Can you deliver it?',
      response:
        'Absolutely. Our partnered rural pharmacy provides doorstep drop-off to county roads, mailbox locations, or porch coolers for rural families.',
      icon: Truck,
    },
    {
      label: 'I do not have health insurance. What does it cost?',
      query: 'I do not have health insurance right now. How much will a clinic visit cost?',
      response:
        'You are always welcome. We provide a sliding-scale fee discount based on your household income, and our financial counselors help with charity care applications so cost is never a barrier.',
      icon: DollarSign,
    },
    {
      label: 'What should I do for stomach pain or fever?',
      query: 'I am experiencing stomach cramps and a mild fever. Should I come in?',
      response:
        'Please stay hydrated with clean drinking water or electrolyte fluids. If symptoms worsen, cause persistent vomiting, or last more than 24 hours, come to our clinic or start a telehealth video visit immediately.',
      icon: Sparkles,
    },
  ];

  return (
    <div
      id="call-and-talk-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-sm p-2 sm:p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="call-and-talk-heading"
    >
      <div className="bg-white border border-slate-200 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Call Banner Header */}
        <div className="bg-gradient-to-r from-coffee-bean via-seaweed-dark to-coffee-bean text-white p-5 sm:p-6 text-center relative">
          <div className="flex flex-wrap items-center justify-center gap-2 mb-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-black/30 border border-white/20 text-xs font-semibold">
              <Radio className="w-3.5 h-3.5 text-neon-ice animate-pulse" />
              <span>
                {callStatus === 'connecting'
                  ? 'Connecting to Clinic Desk...'
                  : `Active Call • ${formatTime(callDuration)}`}
              </span>
            </div>

            {interpreterRequest?.needed && (
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-seaweed/90 border border-neon-ice/40 text-white text-xs font-semibold">
                <Headphones className="w-3 h-3 text-neon-ice" />
                <span>
                  Interpreter: {interpreterRequest.language === 'Other' ? (interpreterRequest.customLanguage || 'Requested') : interpreterRequest.language}
                </span>
              </div>
            )}
          </div>

          <h2 id="call-and-talk-heading" className="text-xl sm:text-2xl font-bold tracking-tight">
            {clinicName}
          </h2>
          <p className="text-neon-ice text-xs sm:text-sm mt-0.5">
            Nurse Care Team • Direct Voice Line
          </p>

          {/* Sound Wave Animation when speaking */}
          <div className="mt-3 flex items-center justify-center gap-1.5 h-7">
            {isSpeakingNow ? (
              <>
                <span className="w-1 bg-neon-ice rounded-full animate-[bounce_0.6s_infinite_100ms] h-4"></span>
                <span className="w-1 bg-pale-sky rounded-full animate-[bounce_0.6s_infinite_200ms] h-6"></span>
                <span className="w-1 bg-white rounded-full animate-[bounce_0.6s_infinite_300ms] h-7"></span>
                <span className="w-1 bg-pale-sky rounded-full animate-[bounce_0.6s_infinite_400ms] h-5"></span>
                <span className="w-1 bg-neon-ice rounded-full animate-[bounce_0.6s_infinite_500ms] h-3"></span>
                <span className="text-xs text-neon-ice font-semibold ml-2">Nurse is speaking...</span>
              </>
            ) : (
              <span className="text-xs text-pale-sky">Audio listening • Tap any topic below or ask anything</span>
            )}
          </div>
        </div>

        {/* Live Conversation Transcript */}
        <div className="flex-1 p-4 sm:p-5 overflow-y-auto bg-slate-50/50 space-y-3 min-h-[220px] max-h-[320px]">
          {dialogue.map((turn, index) => {
            const isNurse = turn.speaker === 'nurse';
            return (
              <div
                key={index}
                className={`flex gap-2.5 ${isNurse ? 'justify-start' : 'justify-end'}`}
              >
                {isNurse && (
                  <div className="w-8 h-8 rounded-full bg-pale-sky-light text-coffee-bean flex items-center justify-center shrink-0 mt-0.5 font-bold text-xs border border-pale-sky">
                    RN
                  </div>
                )}
                <div
                  className={`rounded-2xl p-3.5 max-w-[85%] text-sm sm:text-base leading-relaxed ${
                    isNurse
                      ? 'bg-white text-coffee-bean border border-pale-sky shadow-2xs'
                      : 'bg-seaweed text-white shadow-2xs'
                  }`}
                >
                  <div
                    className={`text-[11px] font-semibold mb-1 flex items-center justify-between gap-2 ${
                      isNurse ? 'text-coffee-bean-muted' : 'text-neon-ice'
                    }`}
                  >
                    <span>{isNurse ? 'Nurse Brenda (Clinic Staff)' : 'You'}</span>
                    <span>{turn.time}</span>
                  </div>
                  <p>{turn.text}</p>
                </div>
              </div>
            );
          })}
          <div ref={transcriptEndRef} />
        </div>

        {/* Quick Voice Topics (Tap to ask) */}
        <div className="p-3 sm:p-4 bg-white border-t border-pale-sky/60">
          <div className="text-xs font-bold text-coffee-bean uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 text-seaweed" />
            <span>Tap to Ask the Nurse:</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {quickOptions.map((opt, i) => {
              const Icon = opt.icon;
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleSelectTopic(opt.query, opt.response)}
                  className="text-left p-2.5 rounded-xl border border-pale-sky/80 hover:border-seaweed bg-pale-sky-light/30 hover:bg-pale-sky text-coffee-bean text-xs sm:text-sm font-medium transition-colors flex items-start gap-2 active:scale-98 cursor-pointer"
                >
                  <Icon className="w-4 h-4 text-seaweed shrink-0 mt-0.5" />
                  <span>{opt.label}</span>
                </button>
              );
            })}
          </div>

          {/* Custom Question input */}
          <form onSubmit={handleCustomQuestionSubmit} className="mt-3 flex gap-2">
            <input
              type="text"
              value={customQuestion}
              onChange={(e) => setCustomQuestion(e.target.value)}
              placeholder="Ask anything else to clinic staff..."
              className="flex-1 bg-pale-sky-light/20 border border-pale-sky rounded-xl px-3.5 py-2 text-sm text-coffee-bean placeholder:text-coffee-bean-muted/70 focus:outline-none focus:ring-2 focus:ring-seaweed"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-seaweed hover:bg-seaweed-dark text-white font-bold text-sm flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Ask</span>
            </button>
          </form>
        </div>

        {/* Bottom Audio & Hang Up Bar */}
        <div className="bg-pale-sky-light/40 px-4 py-3.5 border-t border-pale-sky/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {/* Speaker toggle */}
            <button
              type="button"
              id="call-speaker-toggle"
              onClick={() => {
                const next = !isSpeakerOn;
                setIsSpeakerOn(next);
                if (!next && 'speechSynthesis' in window) {
                  window.speechSynthesis.cancel();
                  setIsSpeakingNow(false);
                }
              }}
              className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                isSpeakerOn
                  ? 'bg-pale-sky-light text-coffee-bean border-pale-sky'
                  : 'bg-white text-coffee-bean-muted border-slate-300'
              }`}
              title={isSpeakerOn ? 'Turn voice speaker off' : 'Turn voice speaker on'}
            >
              {isSpeakerOn ? <Volume2 className="w-4 h-4 text-seaweed" /> : <VolumeX className="w-4 h-4" />}
              <span>{isSpeakerOn ? 'Speaker On' : 'Muted'}</span>
            </button>

            {/* Mic toggle */}
            <button
              type="button"
              id="call-mic-toggle"
              onClick={() => setIsMicMuted(!isMicMuted)}
              className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                isMicMuted
                  ? 'bg-cherry-rose-light text-cherry-rose border-cherry-rose/30'
                  : 'bg-white text-coffee-bean border-slate-300'
              }`}
            >
              {isMicMuted ? <MicOff className="w-4 h-4 text-cherry-rose" /> : <Mic className="w-4 h-4 text-seaweed" />}
              <span>{isMicMuted ? 'Mic Muted' : 'Mic Active'}</span>
            </button>
          </div>

          {/* End Call Button */}
          <button
            type="button"
            id="end-call-btn"
            onClick={handleHangUp}
            className="px-5 py-2.5 rounded-full bg-cherry-rose hover:bg-cherry-rose-dark text-white font-bold text-sm sm:text-base flex items-center gap-2 shadow transition-transform active:scale-95 cursor-pointer"
          >
            <PhoneOff className="w-4 h-4 sm:w-5 sm:h-5" />
            <span>End Call</span>
          </button>
        </div>
      </div>
    </div>
  );
};
