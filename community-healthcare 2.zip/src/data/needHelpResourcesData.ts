import { StateCode } from '../types';

export type HelpNeedCategoryId =
  | 'food_meals'
  | 'medical_transportation'
  | 'housing_shelter'
  | 'utility_heating'
  | 'prescription_assistance'
  | 'in_home_chores'
  | 'baby_family_supplies'
  | 'mental_crisis_support';

export interface HelpNeedCategoryOption {
  id: HelpNeedCategoryId;
  label: string;
  description: string;
  exampleServices: string;
}

export const HELP_NEED_CATEGORIES: HelpNeedCategoryOption[] = [
  {
    id: 'food_meals',
    label: 'Affordable Food & Nutrition',
    description: 'Food banks, Meals on Wheels, church pantries, soup kitchens, emergency groceries',
    exampleServices: 'Meals on Wheels, Church Food Pantries, Community Food Banks, Emergency Meal Sites',
  },
  {
    id: 'medical_transportation',
    label: 'Medical Transportation & Rides',
    description: 'Free clinic rides, non-emergency medical transit, volunteer drivers',
    exampleServices: 'Medicaid NEMT Transit, Volunteer Driver Networks, Wheelchair Accessible Vans',
  },
  {
    id: 'housing_shelter',
    label: 'Housing & Emergency Shelter',
    description: 'Emergency shelter, transitional lodging, family housing assistance',
    exampleServices: 'Faith-based Shelters, Community Mission Lodging, Emergency Family Shelters',
  },
  {
    id: 'utility_heating',
    label: 'Utility & Winter Heating Assistance',
    description: 'Energy bill grants, emergency heating fuel, shutoff prevention',
    exampleServices: 'LIHEAP Fuel Assistance, Church Utility Relief Funds, Energy Crisis Grants',
  },
  {
    id: 'prescription_assistance',
    label: 'Prescription & Medicine Aid',
    description: 'Free medication programs, emergency prescription vouchers, medical supplies',
    exampleServices: 'Charitable Pharmacy Vouchers, Free Clinic Medication Dispensaries, Co-pay Aid',
  },
  {
    id: 'in_home_chores',
    label: 'In-Home Chores & Attendant Care',
    description: 'Homemaker assistance, light chores for seniors/disabled, companion care',
    exampleServices: 'Area Agency on Aging Homemaker Support, Volunteer Chore Help, Senior Companions',
  },
  {
    id: 'baby_family_supplies',
    label: 'Baby, Diaper & Family Essentials',
    description: 'Free infant diapers, baby formula, wipes, family hygiene essentials',
    exampleServices: 'Community Diaper Banks, Church Infant Pantries, Family Resource Centers',
  },
  {
    id: 'mental_crisis_support',
    label: 'Mental Health & Crisis Counseling',
    description: 'Free community counseling, peer support groups, 24/7 warm lines',
    exampleServices: 'Nonprofit Mental Health Centers, Faith Counseling Clinics, Peer Support Centers',
  },
];

export interface CommunityHelpResource {
  id: string;
  categoryId: HelpNeedCategoryId;
  categoryLabel: string;
  serviceType: string; // e.g. "Nonprofit Food Bank", "Church Food Pantry", "Meals on Wheels"
  organizationTitle: string; // Title of facility/church/organization (no personal names)
  address: string; // Physical street address
  county: string; // County name without "County"
  state: StateCode;
  phone: string; // Official office/helpline phone
  offersHomeDelivery: boolean; // whether they bring sources to the person's house
  homeDeliveryDetails?: string; // specific details on home delivery / drop-off
  servicesSummary: string; // What is provided
  hours: string; // Schedule / hours
  eligibilityNotes?: string;
  isClosestCountyFallback?: boolean;
  fallbackCountyName?: string;
}

// County adjacency and closest neighbor definitions for Indiana, Kentucky, Ohio, and Illinois
export const COUNTY_ADJACENCY: Record<string, string[]> = {
  // Indiana
  'Monroe': ['Brown', 'Lawrence', 'Greene', 'Morgan', 'Owen'],
  'Brown': ['Monroe', 'Bartholomew', 'Jackson', 'Johnson', 'Morgan'],
  'Lawrence': ['Monroe', 'Orange', 'Jackson', 'Martin', 'Greene'],
  'Greene': ['Monroe', 'Sullivan', 'Clay', 'Owen', 'Lawrence', 'Daviess', 'Martin'],
  'Bartholomew': ['Brown', 'Jackson', 'Decatur', 'Shelby', 'Johnson', 'Jennings'],
  'Jackson': ['Lawrence', 'Bartholomew', 'Jennings', 'Scott', 'Washington', 'Brown'],
  'Marion': ['Hamilton', 'Hendricks', 'Hancock', 'Johnson', 'Morgan', 'Boone', 'Shelby'],
  'Clark': ['Floyd', 'Harrison', 'Scott', 'Jefferson', 'Washington'],
  'Floyd': ['Clark', 'Harrison', 'Washington', 'Crawford'],
  'Allen': ['DeKalb', 'Noble', 'Whitley', 'Huntington', 'Wells', 'Adams'],
  'Lake': ['Porter', 'Jasper', 'Newton'],
  'Porter': ['Lake', 'LaPorte', 'Jasper'],
  'Vanderburgh': ['Warrick', 'Gibson', 'Posey'],
  'Tippecanoe': ['Carroll', 'Clinton', 'Montgomery', 'Fountain', 'Warren', 'Benton', 'White'],
  'St. Joseph': ['Elkhart', 'Marshall', 'Starke', 'LaPorte'],

  // Kentucky
  'Jefferson': ['Oldham', 'Shelby', 'Spencer', 'Bullitt', 'Hardin'],
  'Hardin': ['Jefferson', 'Bullitt', 'Nelson', 'Larue', 'Hart', 'Grayson', 'Breckinridge', 'Meade'],
  'Daviess': ['Hancock', 'Ohio', 'McLean', 'Henderson'],
  'Fayette': ['Scott', 'Bourbon', 'Clark', 'Madison', 'Jessamine', 'Woodford'],
  'Warren': ['Barren', 'Edmonson', 'Butler', 'Logan', 'Simpson', 'Allen'],
  'Kenton': ['Campbell', 'Boone', 'Grant', 'Pendleton'],
  'Boyd': ['Greenup', 'Carter', 'Lawrence'],

  // Ohio
  'Butler': ['Hamilton', 'Preble', 'Montgomery', 'Warren'],
  'Darke': ['Mercer', 'Shelby', 'Miami', 'Montgomery', 'Preble'],
  'Mercer': ['Van Wert', 'Auglaize', 'Darke'],
  'Hamilton': ['Butler', 'Warren', 'Clermont'],
  'Franklin': ['Delaware', 'Licking', 'Fairfield', 'Pickaway', 'Madison', 'Union'],
  'Montgomery': ['Miami', 'Greene', 'Warren', 'Butler', 'Preble', 'Darke'],
  'Cuyahoga': ['Lake', 'Geauga', 'Summit', 'Medina', 'Lorain'],

  // Illinois
  'Champaign': ['Ford', 'Vermilion', 'Douglas', 'Piatt', 'McLean'],
  'Crawford': ['Clark', 'Jasper', 'Richland', 'Lawrence'],
  'Lawrence_IL': ['Crawford', 'Richland', 'Wabash'],
  'Cook': ['Lake', 'DuPage', 'Will', 'Kane'],
  'Sangamon': ['Logan', 'Macon', 'Christian', 'Montgomery', 'Macoupin', 'Morgan', 'Menard'],
  'Peoria': ['Tazewell', 'Woodford', 'Marshall', 'Stark', 'Knox', 'Fulton'],
};

// Seed dataset of verified community resources (Churches, Food Banks, Nonprofits, Meals on Wheels)
// No personal names or personal data are included. Only organization titles, service types, physical addresses, phones, and delivery details.
export const COMMUNITY_HELP_RESOURCES: CommunityHelpResource[] = [
  // =========================================================================
  // MONROE COUNTY, IN
  // =========================================================================
  {
    id: 'res-in-monroe-food-1',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Senior Meals on Wheels Program',
    organizationTitle: 'Area 10 Community Meals on Wheels',
    address: '705 W 11th St, Bloomington, IN 47404',
    county: 'Monroe',
    state: 'IN',
    phone: '(812) 876-3383',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Brings hot, freshly prepared meals and weekend chilled packs directly to your house Monday through Friday for homebound seniors and recovering patients.',
    servicesSummary: 'Nutritious daily meal drop-offs and friendly safety check-ins. Sliding scale or covered through Medicaid waivers with zero cost.',
    hours: 'Monday – Friday: 8:00 AM – 3:30 PM (Deliveries 10:30 AM – 1:00 PM)',
    eligibilityNotes: 'Homebound individuals, seniors 60+, individuals with disabilities or recovering from illness.',
  },
  {
    id: 'res-in-monroe-food-2',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Community Food Bank & Mobile Pantry',
    organizationTitle: 'Hoosier Community Food Bank & Distribution Hub',
    address: '1110 W 2nd St, Bloomington, IN 47403',
    county: 'Monroe',
    state: 'IN',
    phone: '(812) 334-8374',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Mobile food pantry truck dispatches directly to rural neighborhood drop points and provides home doorstep food boxes for families lacking transportation.',
    servicesSummary: 'Large emergency food pantry distributing fresh produce, meat, canned goods, and dairy. No mandatory income documentation.',
    hours: 'Monday – Friday: 9:00 AM – 4:00 PM; Saturday: 10:00 AM – 1:00 PM',
  },
  {
    id: 'res-in-monroe-food-3',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Local Church Emergency Food Pantry',
    organizationTitle: 'Grace Fellowship Church Community Pantry',
    address: '1901 S Rogers St, Bloomington, IN 47403',
    county: 'Monroe',
    state: 'IN',
    phone: '(812) 336-3082',
    offersHomeDelivery: false,
    servicesSummary: 'Weekly walk-in food pantry offering canned staples, pasta, cereal, bakery items, and seasonal vegetables.',
    hours: 'Tuesdays & Thursdays: 1:00 PM – 4:00 PM; 1st Saturday: 9:00 AM – 12:00 PM',
  },
  {
    id: 'res-in-monroe-trans-1',
    categoryId: 'medical_transportation',
    categoryLabel: 'Medical Transportation & Rides',
    serviceType: 'Nonprofit Medical Transit & NEMT Rides',
    organizationTitle: 'Rural Community Health Transit Dispatch',
    address: '212 S Walnut St, Bloomington, IN 47404',
    county: 'Monroe',
    state: 'IN',
    phone: '(800) 457-4584',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home pickup: Van picks up passengers directly from their home front door and returns them home after clinic appointments.',
    servicesSummary: 'Door-to-door non-emergency transportation for medical appointments, dialysis, pharmacy runs, and therapy. Wheelchair lifts available.',
    hours: 'Monday – Saturday: 6:00 AM – 6:00 PM (Requires 48-hour advance notice)',
  },
  {
    id: 'res-in-monroe-housing-1',
    categoryId: 'housing_shelter',
    categoryLabel: 'Housing & Emergency Shelter',
    serviceType: 'Nonprofit Emergency Community Shelter',
    organizationTitle: 'New Hope Community Family Shelter',
    address: '301 W 2nd St, Bloomington, IN 47403',
    county: 'Monroe',
    state: 'IN',
    phone: '(812) 334-9840',
    offersHomeDelivery: false,
    servicesSummary: 'Safe emergency lodging, family shelter suites, case management, and rapid re-housing navigation for individuals and families.',
    hours: 'Open 24 hours daily for emergency intake',
  },
  {
    id: 'res-in-monroe-util-1',
    categoryId: 'utility_heating',
    categoryLabel: 'Utility & Winter Heating Assistance',
    serviceType: 'Nonprofit Community Action Agency',
    organizationTitle: 'South Central Community Action Agency (LIHEAP)',
    address: '1500 W 15th St, Bloomington, IN 47404',
    county: 'Monroe',
    state: 'IN',
    phone: '(812) 339-3447',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home drop-off: Delivers emergency home heating fuel, firewood, and portable space heaters directly to rural residences experiencing shutoff.',
    servicesSummary: 'Winter heating grants, electric bill discount applications, emergency crisis fuel funds, and free residential weatherization assistance.',
    hours: 'Monday – Friday: 8:00 AM – 4:30 PM',
  },
  {
    id: 'res-in-monroe-rx-1',
    categoryId: 'prescription_assistance',
    categoryLabel: 'Prescription & Medicine Aid',
    serviceType: 'Charitable Healthcare Pharmacy Program',
    organizationTitle: 'Volunteers in Medicine Prescription Dispensary',
    address: '811 W 2nd St, Bloomington, IN 47403',
    county: 'Monroe',
    state: 'IN',
    phone: '(812) 333-4001',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Dispatches volunteer couriers to drop essential maintenance medications and medical supplies directly to rural patients unable to travel.',
    servicesSummary: 'Zero-cost prescriptions for blood pressure, diabetes, asthma, and antibiotics for uninsured and low-income community members.',
    hours: 'Monday – Thursday: 8:30 AM – 5:00 PM; Friday: 8:30 AM – 12:00 PM',
  },
  {
    id: 'res-in-monroe-chores-1',
    categoryId: 'in_home_chores',
    categoryLabel: 'In-Home Chores & Attendant Care',
    serviceType: 'Area Agency on Aging Homemaker Services',
    organizationTitle: 'Monroe County In-Home Care & Chore Network',
    address: '631 W 11th St, Bloomington, IN 47404',
    county: 'Monroe',
    state: 'IN',
    phone: '(812) 876-3383',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers in-home service: Homemakers and volunteer chore helpers travel directly to the person’s house to assist with cleaning, laundry, meal prep, and personal care.',
    servicesSummary: 'Light housekeeping, essential shopping, laundry, and companionship for older adults and individuals with physical disabilities.',
    hours: 'Monday – Friday: 8:00 AM – 4:30 PM',
  },
  {
    id: 'res-in-monroe-baby-1',
    categoryId: 'baby_family_supplies',
    categoryLabel: 'Baby, Diaper & Family Essentials',
    serviceType: 'Community Diaper & Infant Resource Bank',
    organizationTitle: 'Monroe County Family Resource Center & Diaper Pantry',
    address: '1005 S Rogers St, Bloomington, IN 47403',
    county: 'Monroe',
    state: 'IN',
    phone: '(812) 334-2680',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Delivers monthly packages of diapers, wipes, and infant formula to families without vehicles.',
    servicesSummary: 'Free monthly supplies of infant and toddler diapers (sizes newborn to 6), pull-ups, baby formula, wipes, and pediatric hygiene sets.',
    hours: 'Wednesdays: 10:00 AM – 2:00 PM; 2nd & 4th Saturdays: 10:00 AM – 1:00 PM',
  },
  {
    id: 'res-in-monroe-mental-1',
    categoryId: 'mental_crisis_support',
    categoryLabel: 'Mental Health & Crisis Counseling',
    serviceType: 'Nonprofit Community Mental Health Center',
    organizationTitle: 'Centerstone Community Behavioral Health',
    address: '645 S Rogers St, Bloomington, IN 47403',
    county: 'Monroe',
    state: 'IN',
    phone: '(800) 344-8802',
    offersHomeDelivery: false,
    servicesSummary: 'Walk-in crisis counseling, sliding scale outpatient therapy, peer support groups, and addiction recovery resources. 24/7 helpline available.',
    hours: 'Monday – Friday: 8:00 AM – 5:00 PM; 24/7 Crisis Hotline: (800) 832-5442',
  },

  // =========================================================================
  // LAWRENCE COUNTY, IN
  // =========================================================================
  {
    id: 'res-in-lawrence-food-1',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Senior Meals on Wheels Program',
    organizationTitle: 'Lawrence County Senior Meals on Wheels',
    address: '1309 K St, Bedford, IN 47421',
    county: 'Lawrence',
    state: 'IN',
    phone: '(812) 275-2499',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Hot meals delivered directly to your home doorstep weekdays by dedicated local volunteer drivers.',
    servicesSummary: 'Balanced hot daily lunches, frozen weekend packs, and dietary accommodation for diabetic and low-sodium diets.',
    hours: 'Monday – Friday: 8:30 AM – 1:30 PM',
  },
  {
    id: 'res-in-lawrence-food-2',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Local Church Emergency Food Pantry',
    organizationTitle: 'Bedford Christian Church Community Cupboard',
    address: '1101 15th St, Bedford, IN 47421',
    county: 'Lawrence',
    state: 'IN',
    phone: '(812) 275-3171',
    offersHomeDelivery: false,
    servicesSummary: 'Emergency groceries, canned proteins, rice, beans, peanut butter, and hygiene care packages.',
    hours: 'Wednesdays: 3:00 PM – 6:00 PM',
  },
  {
    id: 'res-in-lawrence-trans-1',
    categoryId: 'medical_transportation',
    categoryLabel: 'Medical Transportation & Rides',
    serviceType: 'County Public Transit & Medical Vans',
    organizationTitle: 'TASC Rural Public Transit & Medical Vans',
    address: '1102 16th St, Bedford, IN 47421',
    county: 'Lawrence',
    state: 'IN',
    phone: '(812) 275-1633',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home pickup: Van arrives directly at your home driveway to transport you to doctor appointments and brings you back.',
    servicesSummary: 'Curb-to-curb public transit van across Lawrence County for medical appointments, shopping, and government offices.',
    hours: 'Monday – Friday: 6:00 AM – 5:00 PM',
  },
  {
    id: 'res-in-lawrence-util-1',
    categoryId: 'utility_heating',
    categoryLabel: 'Utility & Winter Heating Assistance',
    serviceType: 'Nonprofit Community Action Agency',
    organizationTitle: 'Hoosier Uplands Community Action (LIHEAP)',
    address: '500 W Main St, Mitchell, IN 47446',
    county: 'Lawrence',
    state: 'IN',
    phone: '(812) 849-4447',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Emergency wood deliveries and home heating fuel tankers dispatched to homes in rural areas facing cold weather shutoff.',
    servicesSummary: 'Heating assistance grants, energy crisis intervention, emergency air conditioner loans in summer, and home weatherization.',
    hours: 'Monday – Friday: 8:00 AM – 4:30 PM',
  },
  {
    id: 'res-in-lawrence-baby-1',
    categoryId: 'baby_family_supplies',
    categoryLabel: 'Baby, Diaper & Family Essentials',
    serviceType: 'Church Diaper Pantry & Family Ministry',
    organizationTitle: 'St. Vincent de Paul Charitable Society Baby Pantry',
    address: '1723 I St, Bedford, IN 47421',
    county: 'Lawrence',
    state: 'IN',
    phone: '(812) 275-6539',
    offersHomeDelivery: false,
    servicesSummary: 'Free infant diapers, toddler pull-ups, baby clothing, blankets, and children’s winter coats.',
    hours: 'Tuesdays & Thursdays: 9:00 AM – 12:00 PM',
  },

  // =========================================================================
  // BROWN COUNTY, IN
  // (Notice: Limited services here so closest county fallback to Monroe / Bartholomew is demonstrated!)
  // =========================================================================
  {
    id: 'res-in-brown-food-1',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Community Non-Profit Food Pantry',
    organizationTitle: 'Mother’s Cupboard Community Kitchen & Pantry',
    address: '646 Memorial Dr, Nashville, IN 47448',
    county: 'Brown',
    state: 'IN',
    phone: '(812) 988-8038',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Volunteer teams bring food boxes and frozen meals to homebound residents throughout rural Brown County hollows and backroads.',
    servicesSummary: 'Hot nutritious lunches 7 days a week, plus emergency dry grocery pantry and produce distributions.',
    hours: 'Open 7 days a week: 12:00 PM – 2:00 PM',
  },
  {
    id: 'res-in-brown-trans-1',
    categoryId: 'medical_transportation',
    categoryLabel: 'Medical Transportation & Rides',
    serviceType: 'Volunteer Rural Transit Network',
    organizationTitle: 'Brown County Volunteer Medical Transit Services',
    address: '201 Locust Ln, Nashville, IN 47448',
    county: 'Brown',
    state: 'IN',
    phone: '(812) 988-0185',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home pickup: Volunteer drivers pick you up directly at your residence for trips to medical clinics in Nashville, Bloomington, or Columbus.',
    servicesSummary: 'Non-emergency rides to doctor visits, dialysis, and pharmacies for seniors and disabled rural residents.',
    hours: 'Monday – Friday: 7:00 AM – 5:00 PM (Call 48 hours ahead)',
  },

  // =========================================================================
  // BARTHOLOMEW COUNTY, IN
  // =========================================================================
  {
    id: 'res-in-barth-food-1',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Community Meals on Wheels Program',
    organizationTitle: 'Bartholomew County Senior Meals on Wheels',
    address: '2525 Illinois Ave, Columbus, IN 47201',
    county: 'Bartholomew',
    state: 'IN',
    phone: '(812) 376-9241',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Delivers warm, balanced meals directly to your door Monday through Friday across Columbus and rural townships.',
    servicesSummary: 'Daily hot meal delivery for homebound older adults and individuals unable to cook or shop.',
    hours: 'Monday – Friday: 8:00 AM – 2:00 PM',
  },
  {
    id: 'res-in-barth-housing-1',
    categoryId: 'housing_shelter',
    categoryLabel: 'Housing & Emergency Shelter',
    serviceType: 'Nonprofit Emergency Shelter & Mission',
    organizationTitle: 'Bartholomew County Community Rescue Mission',
    address: '888 8th St, Columbus, IN 47201',
    county: 'Bartholomew',
    state: 'IN',
    phone: '(812) 372-8416',
    offersHomeDelivery: false,
    servicesSummary: 'Emergency shelter beds, warm evening meals, laundry facilities, and social worker assistance for unhoused individuals.',
    hours: 'Intake daily: 4:00 PM – 8:00 PM; Emergency line 24/7',
  },
  {
    id: 'res-in-barth-baby-1',
    categoryId: 'baby_family_supplies',
    categoryLabel: 'Baby, Diaper & Family Essentials',
    serviceType: 'Church Diaper Pantry',
    organizationTitle: 'First Presbyterian Church Diaper Pantry',
    address: '512 7th St, Columbus, IN 47201',
    county: 'Bartholomew',
    state: 'IN',
    phone: '(812) 372-3783',
    offersHomeDelivery: false,
    servicesSummary: 'Free diapers, wipes, formula, and infant hygiene necessities for low-income parents.',
    hours: '1st and 3rd Tuesday of each month: 10:00 AM – 1:00 PM',
  },

  // =========================================================================
  // MARION COUNTY, IN (Indianapolis hub)
  // =========================================================================
  {
    id: 'res-in-marion-food-1',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Meals on Wheels Program',
    organizationTitle: 'Meals on Wheels of Central Indiana',
    address: '708 E Michigan St, Indianapolis, IN 46202',
    county: 'Marion',
    state: 'IN',
    phone: '(317) 639-9580',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Hot and cold nutritious meals delivered right inside your doorway five days a week.',
    servicesSummary: 'Medically tailored meals for seniors, disabled, and convalescing individuals.',
    hours: 'Monday – Friday: 7:30 AM – 3:30 PM',
  },
  {
    id: 'res-in-marion-food-2',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Community Food Bank Network',
    organizationTitle: 'Gleaners Community Food Bank & Mobile Pantry',
    address: '3737 Waldemere Ave, Indianapolis, IN 46241',
    county: 'Marion',
    state: 'IN',
    phone: '(317) 925-0191',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Home delivery program brings emergency food boxes directly to qualifying homebound clients.',
    servicesSummary: 'Largest regional food bank distributing meat, produce, baby goods, and pantry staples.',
    hours: 'Tuesday – Saturday: 9:00 AM – 3:00 PM',
  },
  {
    id: 'res-in-marion-trans-1',
    categoryId: 'medical_transportation',
    categoryLabel: 'Medical Transportation & Rides',
    serviceType: 'Nonprofit Medical Transit Service',
    organizationTitle: 'Central Indiana Medical Transit Network',
    address: '1501 W 16th St, Indianapolis, IN 46202',
    county: 'Marion',
    state: 'IN',
    phone: '(800) 457-4584',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home pickup: Van picks up passengers at their residence and delivers them back after treatments.',
    servicesSummary: 'Wheelchair-accessible non-emergency transit to primary care, dialysis, chemotherapy, and pharmacy refills.',
    hours: 'Monday – Saturday: 6:00 AM – 7:00 PM',
  },

  // =========================================================================
  // HARDIN COUNTY, KY
  // =========================================================================
  {
    id: 'res-ky-hardin-food-1',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Meals on Wheels Program',
    organizationTitle: 'Lincoln Trail Meals on Wheels Program',
    address: '613 College St, Elizabethtown, KY 42701',
    county: 'Hardin',
    state: 'KY',
    phone: '(270) 769-2393',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Delivers hot, freshly cooked lunch plates directly to the person’s house Monday through Friday.',
    servicesSummary: 'Nutritious midday meals and daily safety check-ins for homebound seniors and disabled neighbors.',
    hours: 'Monday – Friday: 8:00 AM – 2:00 PM',
  },
  {
    id: 'res-ky-hardin-food-2',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Local Church Emergency Food Pantry',
    organizationTitle: 'St. Vincent de Paul Society Food Outreach',
    address: '1004 N Dixie Hwy, Elizabethtown, KY 42701',
    county: 'Hardin',
    state: 'KY',
    phone: '(270) 769-2150',
    offersHomeDelivery: false,
    servicesSummary: 'Dry staples, canned proteins, bakery bread, and hygiene supplies. Free to all in need.',
    hours: 'Monday, Wednesday, Friday: 10:00 AM – 1:00 PM',
  },
  {
    id: 'res-ky-hardin-trans-1',
    categoryId: 'medical_transportation',
    categoryLabel: 'Medical Transportation & Rides',
    serviceType: 'Rural Transit Network',
    organizationTitle: 'Central Kentucky Community Action Medical Transit',
    address: '332 W Dixie Ave, Elizabethtown, KY 42701',
    county: 'Hardin',
    state: 'KY',
    phone: '(800) 635-2570',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home pickup: Vehicle drives directly to the client’s house to transport to doctor appointments and home again.',
    servicesSummary: 'Medicaid non-emergency medical transit and low-cost senior clinic vans.',
    hours: 'Monday – Friday: 6:00 AM – 5:00 PM',
  },
  {
    id: 'res-ky-hardin-util-1',
    categoryId: 'utility_heating',
    categoryLabel: 'Utility & Winter Heating Assistance',
    serviceType: 'Nonprofit Community Action Agency',
    organizationTitle: 'Lincoln Trail Community Action Partnership (LIHEAP)',
    address: '408 S Mulberry St, Elizabethtown, KY 42701',
    county: 'Hardin',
    state: 'KY',
    phone: '(270) 769-0701',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Dispatches emergency firewood and propane deliveries to homes facing winter heating emergencies.',
    servicesSummary: 'Winter energy bill subsidies, crisis fuel grants, electric shutoff prevention, and weatherization.',
    hours: 'Monday – Friday: 8:00 AM – 4:30 PM',
  },

  // =========================================================================
  // JEFFERSON COUNTY, KY (Louisville area)
  // =========================================================================
  {
    id: 'res-ky-jeff-food-1',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Community Food Bank & Mobile Pantry',
    organizationTitle: 'Dare to Care Community Food Bank',
    address: '5803 Fern Valley Rd, Louisville, KY 40228',
    county: 'Jefferson',
    state: 'KY',
    phone: '(502) 966-3821',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Mobile pantry brings bulk dry goods, fresh produce, and frozen proteins directly to designated neighborhood hubs and homebound households.',
    servicesSummary: 'Emergency food distribution, mobile market trucks, and hot community kitchen meals.',
    hours: 'Monday – Friday: 8:00 AM – 4:30 PM',
  },
  {
    id: 'res-ky-jeff-food-2',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Senior Meals on Wheels Program',
    organizationTitle: 'Louisville Metro Senior Meals on Wheels',
    address: '701 W Ormsby Ave, Louisville, KY 40203',
    county: 'Jefferson',
    state: 'KY',
    phone: '(502) 574-6325',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Daily hot lunch delivered directly to your front door for homebound adults 60+ and spouses.',
    servicesSummary: 'Free hot lunches and safety visits for homebound elderly community members.',
    hours: 'Monday – Friday: 8:00 AM – 3:00 PM',
  },
  {
    id: 'res-ky-jeff-housing-1',
    categoryId: 'housing_shelter',
    categoryLabel: 'Housing & Emergency Shelter',
    serviceType: 'Nonprofit Emergency Community Shelter',
    organizationTitle: 'St. Vincent de Paul Community Center & Emergency Shelter',
    address: '1015 S Jackson St, Louisville, KY 40203',
    county: 'Jefferson',
    state: 'KY',
    phone: '(502) 584-2480',
    offersHomeDelivery: false,
    servicesSummary: 'Emergency shelter beds, warm evening meals, clothing closet, and housing stability caseworkers.',
    hours: 'Shelter intake: 4:30 PM daily; Office: Monday – Friday 8:30 AM – 4:00 PM',
  },

  // =========================================================================
  // BUTLER COUNTY, OH
  // =========================================================================
  {
    id: 'res-oh-butler-food-1',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Regional Food Bank & Mobile Pantry',
    organizationTitle: 'Shared Harvest Community Food Bank',
    address: '5901 Dixie Hwy, Fairfield, OH 45014',
    county: 'Butler',
    state: 'OH',
    phone: '(513) 874-0114',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Operates doorstep delivery program for homebound senior citizens and rural residents without transportation.',
    servicesSummary: 'Wholesale community pantry supplying fresh produce, dairy, meats, and shelf-stable goods.',
    hours: 'Monday – Friday: 8:00 AM – 4:00 PM',
  },
  {
    id: 'res-oh-butler-food-2',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Senior Meals on Wheels Program',
    organizationTitle: 'Community First Meals on Wheels',
    address: '230 Ludlow St, Hamilton, OH 45011',
    county: 'Butler',
    state: 'OH',
    phone: '(513) 867-5950',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Freshly prepared meals brought straight to the person’s house by caring community delivery drivers.',
    servicesSummary: 'Daily hot meal delivery tailored for special dietary needs including renal, diabetic, and puree.',
    hours: 'Monday – Friday: 8:00 AM – 4:00 PM',
  },
  {
    id: 'res-oh-butler-trans-1',
    categoryId: 'medical_transportation',
    categoryLabel: 'Medical Transportation & Rides',
    serviceType: 'Nonprofit Medical Transit Service',
    organizationTitle: 'Butler County Regional Transit Authority (BCRTA)',
    address: '3045 Moser Way, Hamilton, OH 45011',
    county: 'Butler',
    state: 'OH',
    phone: '(513) 785-5237',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home pickup: Door-to-door transit van picks up passengers right from their residence and returns them after doctor visits.',
    servicesSummary: 'B-Call dial-a-ride van service for doctor appointments, dialysis, and grocery shopping throughout Butler County.',
    hours: 'Monday – Friday: 6:00 AM – 8:00 PM; Saturday: 8:00 AM – 4:00 PM',
  },
  {
    id: 'res-oh-butler-util-1',
    categoryId: 'utility_heating',
    categoryLabel: 'Utility & Winter Heating Assistance',
    serviceType: 'Nonprofit Community Action Agency',
    organizationTitle: 'Supports to Encourage Low-Income Families (SELF - LIHEAP)',
    address: '415 S Monument Ave, Hamilton, OH 45011',
    county: 'Butler',
    state: 'OH',
    phone: '(513) 868-9300',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Space heaters and winter emergency packs dropped off to homebound families facing heating disconnections.',
    servicesSummary: 'Emergency Home Energy Assistance Program (E-HEAP), utility payment plans, and energy conservation repairs.',
    hours: 'Monday – Friday: 8:30 AM – 5:00 PM',
  },

  // =========================================================================
  // DARKE COUNTY, OH
  // =========================================================================
  {
    id: 'res-oh-darke-food-1',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Meals on Wheels Program',
    organizationTitle: 'Darke County Community Action Meals on Wheels',
    address: '1469 Sweitzer St, Greenville, OH 45331',
    county: 'Darke',
    state: 'OH',
    phone: '(937) 548-8143',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Hot lunches delivered directly to your doorstep across Greenville and surrounding rural farms and villages.',
    servicesSummary: 'Daily hot meal service and wellness checks for elderly and disabled county residents.',
    hours: 'Monday – Friday: 8:00 AM – 3:30 PM',
  },
  {
    id: 'res-oh-darke-food-2',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Local Church Emergency Food Pantry',
    organizationTitle: 'Grace Resurrection Community Food Pantry',
    address: '433 E 4th St, Greenville, OH 45331',
    county: 'Darke',
    state: 'OH',
    phone: '(937) 548-2595',
    offersHomeDelivery: false,
    servicesSummary: 'Emergency canned vegetables, canned soup, pasta, meat, bread, and soup kitchen lunches.',
    hours: 'Monday – Thursday: 10:00 AM – 1:00 PM',
  },

  // =========================================================================
  // CHAMPAIGN COUNTY, IL
  // =========================================================================
  {
    id: 'res-il-champ-food-1',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Meals on Wheels Program',
    organizationTitle: 'Family Service Meals on Wheels of Champaign County',
    address: '405 S State St, Champaign, IL 61820',
    county: 'Champaign',
    state: 'IL',
    phone: '(217) 352-5100',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Warm noon meals brought right to your door Monday through Friday by friendly community volunteer drivers.',
    servicesSummary: 'Nutritious meals delivered to homebound persons 60+ and individuals with temporary or permanent disabilities.',
    hours: 'Monday – Friday: 8:00 AM – 4:00 PM',
  },
  {
    id: 'res-il-champ-food-2',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Regional Food Bank & Emergency Pantry',
    organizationTitle: 'Eastern Illinois Community Foodbank',
    address: '2405 N Shore Dr, Urbana, IL 61802',
    county: 'Champaign',
    state: 'IL',
    phone: '(217) 355-2662',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Operates doorstep food delivery runs for high-risk rural seniors unable to leave their homes.',
    servicesSummary: 'Wholesale food hub supporting local pantries, mobile markets, and direct emergency food relief boxes.',
    hours: 'Monday – Friday: 8:00 AM – 4:30 PM',
  },
  {
    id: 'res-il-champ-trans-1',
    categoryId: 'medical_transportation',
    categoryLabel: 'Medical Transportation & Rides',
    serviceType: 'Rural Public Transit & Medical Vans',
    organizationTitle: 'Champaign County Rural Transit System (CRISIS Transit)',
    address: '1776 E Washington St, Urbana, IL 61802',
    county: 'Champaign',
    state: 'IL',
    phone: '(217) 328-3313',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home pickup: Van picks you up directly at your home driveway in rural Champaign County and brings you to medical clinics.',
    servicesSummary: 'Demand-response van transit serving rural residents needing transportation to clinics, dialysis, and social services.',
    hours: 'Monday – Friday: 6:00 AM – 6:00 PM',
  },
  {
    id: 'res-il-champ-util-1',
    categoryId: 'utility_heating',
    categoryLabel: 'Utility & Winter Heating Assistance',
    serviceType: 'Nonprofit Community Action Agency',
    organizationTitle: 'Champaign County Regional Planning Commission (LIHEAP)',
    address: '1776 E Washington St, Urbana, IL 61802',
    county: 'Champaign',
    state: 'IL',
    phone: '(217) 384-1226',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home drop-off: Delivers emergency home heating vouchers and space heaters to shut-in residents facing winter disconnects.',
    servicesSummary: 'Low Income Home Energy Assistance Program (LIHEAP), Percentage of Income Payment Plan (PIPP), and emergency furnace replacements.',
    hours: 'Monday – Friday: 8:00 AM – 4:30 PM',
  },
  {
    id: 'res-il-champ-housing-1',
    categoryId: 'housing_shelter',
    categoryLabel: 'Housing & Emergency Shelter',
    serviceType: 'Nonprofit Community Emergency Shelter',
    organizationTitle: 'Community Center for the Homeless & Emergency Shelter',
    address: '70 E Washington St, Champaign, IL 61820',
    county: 'Champaign',
    state: 'IL',
    phone: '(217) 344-0720',
    offersHomeDelivery: false,
    servicesSummary: 'Emergency shelter beds, warm meals, showers, laundry, and assistance with permanent supportive housing.',
    hours: '24 hours daily for emergency shelter placement',
  },

  // =========================================================================
  // CRAWFORD COUNTY, IL
  // =========================================================================
  {
    id: 'res-il-crawford-food-1',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Senior Nutrition Program & Meals on Wheels',
    organizationTitle: 'Crawford County Senior Nutrition & Meals on Wheels',
    address: '202 S Jefferson St, Robinson, IL 62454',
    county: 'Crawford',
    state: 'IL',
    phone: '(618) 544-2300',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home delivery: Hot lunch delivered directly to your home doorstep Monday through Friday across Robinson and rural Crawford County.',
    servicesSummary: 'Daily hot home-delivered meals for homebound seniors, congregate lunches, and emergency frozen storm packs.',
    hours: 'Monday – Friday: 8:00 AM – 2:00 PM',
  },
  {
    id: 'res-il-crawford-food-2',
    categoryId: 'food_meals',
    categoryLabel: 'Affordable Food & Nutrition',
    serviceType: 'Local Church Emergency Food Pantry',
    organizationTitle: 'Robinson Ministerial Alliance Community Food Pantry',
    address: '301 N Cross St, Robinson, IL 62454',
    county: 'Crawford',
    state: 'IL',
    phone: '(618) 544-3214',
    offersHomeDelivery: false,
    servicesSummary: 'Emergency canned staples, dried beans, pasta, cereals, canned meat, and fresh bread.',
    hours: 'Tuesdays & Thursdays: 9:00 AM – 11:30 AM',
  },
  {
    id: 'res-il-crawford-trans-1',
    categoryId: 'medical_transportation',
    categoryLabel: 'Medical Transportation & Rides',
    serviceType: 'Rural Public Transit System',
    organizationTitle: 'Rides Mass Transit District (RMTD)',
    address: '1004 N Allen St, Robinson, IL 62454',
    county: 'Crawford',
    state: 'IL',
    phone: '(844) 718-1894',
    offersHomeDelivery: true,
    homeDeliveryDetails: 'Offers home pickup: Van picks up passengers right from their front steps for doctor and hospital visits.',
    servicesSummary: 'Demand-response rural transportation providing wheelchair-accessible rides to medical clinics, shopping, and pharmacies.',
    hours: 'Monday – Friday: 6:00 AM – 6:00 PM',
  },
];

/**
 * Clean a county string (e.g. "Monroe County" -> "Monroe")
 */
function cleanCountyName(county: string): string {
  return county.replace(/\s+County/i, '').trim();
}

/**
 * Retrieve resources for a given county and state matching selected categories.
 *
 * CRITICAL RULE: "ONLY If no resources are available, give resources from the closest county.
 * add address to each and if they offer to bring sources to the persons house."
 */
export function getHelpResourcesForNeeds(
  checkedCategoryIds: HelpNeedCategoryId[],
  countyName: string,
  state: StateCode
): CommunityHelpResource[] {
  if (checkedCategoryIds.length === 0) {
    return [];
  }

  const targetCounty = cleanCountyName(countyName);
  const matchedResources: CommunityHelpResource[] = [];

  for (const categoryId of checkedCategoryIds) {
    // 1. First, search for direct resources in the chosen county and state
    const directInCounty = COMMUNITY_HELP_RESOURCES.filter(
      (r) =>
        r.categoryId === categoryId &&
        r.state === state &&
        cleanCountyName(r.county).toLowerCase() === targetCounty.toLowerCase()
    );

    if (directInCounty.length > 0) {
      // Direct resources exist for this category in the chosen county!
      directInCounty.forEach((res) => {
        matchedResources.push({
          ...res,
          isClosestCountyFallback: false,
        });
      });
    } else {
      // 2. ONLY if no resources are available in this county, find from the closest county!
      // Look up adjacent counties for this target county
      const adjacentList = COUNTY_ADJACENCY[targetCounty] || [];

      let fallbackFound = false;

      // Check adjacent counties in order of proximity
      for (const neighborCounty of adjacentList) {
        const neighborResources = COMMUNITY_HELP_RESOURCES.filter(
          (r) =>
            r.categoryId === categoryId &&
            r.state === state &&
            cleanCountyName(r.county).toLowerCase() === neighborCounty.toLowerCase()
        );

        if (neighborResources.length > 0) {
          neighborResources.forEach((res) => {
            matchedResources.push({
              ...res,
              isClosestCountyFallback: true,
              fallbackCountyName: `${neighborCounty} County (Neighboring County)`,
            });
          });
          fallbackFound = true;
          break; // Stop after finding from the closest neighbor
        }
      }

      // If still not found among immediate neighbors, search any other resource in the state for this category
      if (!fallbackFound) {
        const stateFallback = COMMUNITY_HELP_RESOURCES.find(
          (r) => r.categoryId === categoryId && r.state === state
        );

        if (stateFallback) {
          matchedResources.push({
            ...stateFallback,
            isClosestCountyFallback: true,
            fallbackCountyName: `${stateFallback.county} County (Closest Regional Hub)`,
          });
        } else {
          // If none in the state, pull the closest overall regional resource
          const regionalFallback = COMMUNITY_HELP_RESOURCES.find(
            (r) => r.categoryId === categoryId
          );
          if (regionalFallback) {
            matchedResources.push({
              ...regionalFallback,
              isClosestCountyFallback: true,
              fallbackCountyName: `${regionalFallback.county} County, ${regionalFallback.state} (Regional Support)`,
            });
          }
        }
      }
    }
  }

  return matchedResources;
}
