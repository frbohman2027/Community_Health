import { Hospital } from '../types';
import { PLACEHOLDER_HOSPITALS } from '../data/placeholderData';

export interface HospitalWithDistance extends Hospital {
  estimatedMiles: number;
}

// Coordinates for the 15 hospitals
const HOSPITAL_COORDINATES: Record<string, { lat: number; lng: number }> = {
  'hosp-in-1': { lat: 39.166, lng: -86.533 }, // Monroe Co, IN (Bloomington)
  'hosp-in-2': { lat: 38.861, lng: -86.487 }, // Lawrence Co, IN (Bedford)
  'hosp-in-3': { lat: 39.039, lng: -87.166 }, // Greene Co, IN (Linton)
  'hosp-in-4': { lat: 39.209, lng: -85.921 }, // Bartholomew Co, IN (Columbus)
  'hosp-in-5': { lat: 38.959, lng: -85.890 }, // Jackson Co, IN (Seymour)
  'hosp-in-6': { lat: 39.779, lng: -86.182 }, // Marion Co, IN (Indianapolis)
  'hosp-ky-1': { lat: 38.252, lng: -85.742 }, // Jefferson Co, KY (Louisville)
  'hosp-ky-2': { lat: 37.693, lng: -85.864 }, // Hardin Co, KY (Elizabethtown)
  'hosp-ky-3': { lat: 37.771, lng: -87.113 }, // Daviess Co, KY (Owensboro)
  'hosp-oh-1': { lat: 39.332, lng: -84.404 }, // Butler Co, OH (West Chester)
  'hosp-oh-2': { lat: 40.103, lng: -84.633 }, // Darke Co, OH (Greenville)
  'hosp-oh-3': { lat: 40.481, lng: -84.634 }, // Mercer Co, OH (Coldwater)
  'hosp-il-1': { lat: 39.004, lng: -87.739 }, // Crawford Co, IL (Robinson)
  'hosp-il-2': { lat: 38.728, lng: -87.683 }, // Lawrence Co, IL (Lawrenceville)
  'hosp-il-3': { lat: 40.116, lng: -88.214 }, // Champaign Co, IL (Urbana)
};

// Base coordinates for the 4 regional states
const STATE_DEFAULT_COORDS: Record<string, { lat: number; lng: number }> = {
  IN: { lat: 39.76, lng: -86.15 },
  KY: { lat: 37.83, lng: -85.76 },
  OH: { lat: 39.96, lng: -84.19 },
  IL: { lat: 39.78, lng: -88.00 },
};

/**
 * Calculates Haversine great-circle distance between two points in miles
 */
function calculateDistanceMiles(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959; // Earth radius in miles
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Returns estimated coordinates for any given county code
 */
function getCountyCoordinates(countyCode: string): { lat: number; lng: number } {
  // 1. Direct match with a county having a hospital
  const hospitalInCounty = PLACEHOLDER_HOSPITALS.find((h) => h.countyCode === countyCode);
  if (hospitalInCounty && HOSPITAL_COORDINATES[hospitalInCounty.id]) {
    return HOSPITAL_COORDINATES[hospitalInCounty.id];
  }

  // 2. Parse state code
  const state = countyCode.split('-')[0] || 'IN';
  const base = STATE_DEFAULT_COORDS[state] || STATE_DEFAULT_COORDS.IN;

  // Simple deterministic offset per county name hash so each county has a distinct geographic anchor
  let hash = 0;
  for (let i = 0; i < countyCode.length; i++) {
    hash = (hash << 5) - hash + countyCode.charCodeAt(i);
    hash |= 0;
  }
  const latOffset = ((Math.abs(hash) % 120) - 60) / 100; // ±0.6 degrees
  const lngOffset = ((Math.abs(hash >> 3) % 120) - 60) / 100;

  return {
    lat: base.lat + latOffset,
    lng: base.lng + lngOffset,
  };
}

/**
 * Resolves all 15 closest hospitals sorted by calculated proximity to the given county
 */
export function get15ClosestHospitals(countyCode: string): HospitalWithDistance[] {
  const origin = getCountyCoordinates(countyCode);

  const list: HospitalWithDistance[] = PLACEHOLDER_HOSPITALS.map((hospital) => {
    const coords = HOSPITAL_COORDINATES[hospital.id];
    let miles: number;

    if (hospital.countyCode === countyCode) {
      // Local county hospital is immediately close
      miles = 4.2;
    } else if (coords) {
      const dist = calculateDistanceMiles(origin.lat, origin.lng, coords.lat, coords.lng);
      // Ensure realistic road driving distance buffer (+15% winding roads)
      miles = Math.max(7.5, Math.round(dist * 1.15 * 10) / 10);
    } else {
      miles = 45;
    }

    return {
      ...hospital,
      distanceMiles: `~${miles.toFixed(1)} miles`,
      estimatedMiles: miles,
    };
  });

  // Sort ascending by estimated miles
  return list.sort((a, b) => a.estimatedMiles - b.estimatedMiles);
}
