import React, { useState, useMemo } from 'react';
import {
  UserCheck,
  Heart,
  Phone,
  CheckCircle2,
  DollarSign,
  Users,
  ShieldCheck,
  Star,
  Info,
  Calendar,
  Sparkles,
  Award,
  ChevronRight,
  HandHeart,
  FileCheck,
  Clock,
  Send,
  AlertCircle,
} from 'lucide-react';
import { LanguageCode, StateCode, HomeHealthAide, MedicaidFamilyCaregiverApplication } from '../types';
import { MEDICAID_PROGRAM_DETAILS, getHomeHealthAidesForCounty } from '../data/hhaData';

interface MedicaidHHASectionProps {
  lang: LanguageCode;
  selectedState: StateCode;
  countyName: string;
  onSelectAide?: (aide: HomeHealthAide) => void;
  onFamilyCaregiverSubmit?: (app: MedicaidFamilyCaregiverApplication) => void;
}

export const MedicaidHHASection: React.FC<MedicaidHHASectionProps> = ({
  selectedState,
  countyName,
  onSelectAide,
  onFamilyCaregiverSubmit,
}) => {
  // Active Tab: 'hha_directory' or 'family_sign_up'
  const [activeTab, setActiveTab] = useState<'hha_directory' | 'family_sign_up'>('hha_directory');

  // Filtered HHAs for this county and state
  const availableAides = useMemo(
    () => getHomeHealthAidesForCounty(countyName, selectedState),
    [countyName, selectedState]
  );

  // State-specific Medicaid Program info
  const programInfo = MEDICAID_PROGRAM_DETAILS[selectedState] || MEDICAID_PROGRAM_DETAILS.IN;

  // Selected Aide for Quick Contact Modal / Confirmation
  const [requestedAide, setRequestedAide] = useState<HomeHealthAide | null>(null);
  const [aideRequestSuccess, setAideRequestSuccess] = useState<string | null>(null);
  const [aideContactPhone, setAideContactPhone] = useState('');
  const [aidePreferredTime, setAidePreferredTime] = useState('Morning (8am - 12pm)');

  // Family Caregiver Sign-Up Form State
  const [familyName, setFamilyName] = useState('');
  const [relationship, setRelationship] = useState('Adult Child (Son / Daughter)');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [hoursNeeded, setHoursNeeded] = useState('20-30 hours per week');
  const [selectedCareTypes, setSelectedCareTypes] = useState<string[]>([
    'Bathing & Personal Care',
    'Meal Preparation & Nutrition',
    'Medication Reminders',
  ]);
  const [applicationSuccess, setApplicationSuccess] = useState<MedicaidFamilyCaregiverApplication | null>(null);

  const toggleCareType = (type: string) => {
    setSelectedCareTypes((prev) =>
      prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]
    );
  };

  const handleRequestAideSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!requestedAide) return;

    setAideRequestSuccess(requestedAide.name);
    if (onSelectAide) {
      onSelectAide(requestedAide);
    }
  };

  const handleFamilyFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!familyName.trim() || !phone.trim()) return;

    const newApp: MedicaidFamilyCaregiverApplication = {
      id: `mca-${Date.now()}`,
      applicantName: familyName.trim(),
      relationship,
      phone: phone.trim(),
      email: email.trim() || 'Not provided',
      county: countyName,
      state: selectedState,
      hoursNeededPerWeek: hoursNeeded,
      careNeeded: selectedCareTypes,
      submittedAt: new Date().toLocaleDateString(),
    };

    setApplicationSuccess(newApp);
    if (onFamilyCaregiverSubmit) {
      onFamilyCaregiverSubmit(newApp);
    }
  };

  return (
    <div
      id="medicaid-hha-section"
      className="bg-white rounded-3xl border-2 border-seaweed/40 shadow-sm p-5 sm:p-7 transition-all scroll-mt-20"
    >
      {/* Top Section Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-100">
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-2xl bg-seaweed text-white flex items-center justify-center font-bold text-base shrink-0 shadow-2xs">
            4
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <span className="px-2.5 py-0.5 rounded-full bg-seaweed-light text-seaweed-dark font-extrabold text-[11px] uppercase tracking-wider border border-seaweed/30 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-seaweed" />
                Medicaid In-Home Benefit
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-pale-sky-light text-coffee-bean font-bold text-[11px] border border-pale-sky">
                $0 Out-of-Pocket Cost to You
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-coffee-bean tracking-tight">
              Medicaid In-Home Care & Family Attendant Support
            </h2>
            <p className="text-coffee-bean-muted text-xs sm:text-sm mt-0.5 max-w-2xl">
              Because you have Medicaid, you are eligible for in-home care services. Choose between
              connecting with a certified Home Health Aide (HHA) in {countyName} or enrolling a family
              member to get paid as your caregiver.
            </p>
          </div>
        </div>

        {/* State Program Badge */}
        <div className="bg-pale-sky-light/50 border border-pale-sky rounded-2xl p-3 text-xs text-coffee-bean shrink-0 max-w-xs">
          <div className="font-bold flex items-center gap-1.5 text-seaweed-dark">
            <ShieldCheck className="w-4 h-4 text-seaweed" />
            <span>{selectedState} State Waiver Program</span>
          </div>
          <div className="text-[11px] text-coffee-bean-muted mt-0.5 font-medium">
            {programInfo.programName}
          </div>
          <div className="mt-1 font-bold text-seaweed text-xs flex items-center gap-1">
            <DollarSign className="w-3.5 h-3.5" />
            <span>Medicaid Pay Rate: {programInfo.payRateRange}</span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 p-1.5 bg-slate-100 rounded-2xl mb-6">
        <button
          type="button"
          onClick={() => setActiveTab('hha_directory')}
          className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'hha_directory'
              ? 'bg-white text-seaweed shadow-xs ring-1 ring-slate-200'
              : 'text-coffee-bean-muted hover:text-coffee-bean'
          }`}
        >
          <UserCheck className="w-4 h-4 text-seaweed" />
          <span>Local Home Health Aides ({availableAides.length} in area)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('family_sign_up')}
          className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeTab === 'family_sign_up'
              ? 'bg-white text-seaweed shadow-xs ring-1 ring-slate-200'
              : 'text-coffee-bean-muted hover:text-coffee-bean'
          }`}
        >
          <HandHeart className="w-4 h-4 text-seaweed" />
          <span>Sign Up Family Member to Get Paid ({programInfo.payRateRange})</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: LOCAL HOME HEALTH AIDES DIRECTORY                                   */}
      {/* ========================================================================= */}
      {activeTab === 'hha_directory' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-seaweed-light/40 border border-seaweed/30 text-xs sm:text-sm text-coffee-bean flex items-start gap-3">
            <Info className="w-5 h-5 text-seaweed shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong className="block font-bold text-coffee-bean mb-0.5">
                100% Medicaid Covered In-Home Aides for {countyName}
              </strong>
              These community home health aides assist with bathing, dressing, meal prep, mobility,
              and medication reminders. Medicaid covers their visits in full.
            </div>
          </div>

          {/* Success banner if aide was requested */}
          {aideRequestSuccess && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs sm:text-sm flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <strong className="block font-bold mb-0.5">
                  Care Request Sent for {aideRequestSuccess}!
                </strong>
                The aide’s Medicaid care coordinator will call you back within 1 business day to confirm
                your preferred schedule and finalize in-home intake paperwork.
              </div>
            </div>
          )}

          {/* Grid of Home Health Aides */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {availableAides.map((aide) => {
              const isBeingRequested = requestedAide?.id === aide.id;

              return (
                <div
                  key={aide.id}
                  className="p-5 rounded-2xl border border-pale-sky/80 bg-white hover:border-seaweed/60 transition-all shadow-2xs flex flex-col justify-between"
                >
                  <div>
                    {/* Header with name and rating */}
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h3 className="font-bold text-base text-coffee-bean">{aide.name}</h3>
                          <span className="px-2 py-0.5 rounded-md bg-seaweed-light text-seaweed-dark text-[10px] font-extrabold border border-seaweed/20">
                            Medicaid Certified
                          </span>
                        </div>
                        <p className="text-xs text-seaweed font-semibold mt-0.5">
                          {aide.credentials}
                        </p>
                      </div>

                      <div className="flex items-center gap-1 bg-amber-50 border border-amber-200 px-2 py-1 rounded-xl text-xs font-bold text-amber-800 shrink-0">
                        <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                        <span>{aide.rating}</span>
                        <span className="text-[10px] text-amber-700 font-normal">
                          ({aide.reviewsCount})
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-coffee-bean-muted leading-relaxed mb-3">
                      {aide.bio}
                    </p>

                    {/* Services Offered */}
                    <div className="mb-3">
                      <span className="text-[11px] font-bold text-coffee-bean uppercase tracking-wider block mb-1">
                        Services Provided:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {aide.services.map((svc, idx) => (
                          <span
                            key={idx}
                            className="text-[11px] px-2 py-0.5 rounded-lg bg-slate-100 text-coffee-bean font-medium border border-slate-200"
                          >
                            ✓ {svc}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Availability and phone */}
                    <div className="text-xs text-coffee-bean space-y-1 mb-4 pt-2 border-t border-slate-100">
                      <div className="flex items-center gap-1.5 text-coffee-bean-muted">
                        <Clock className="w-3.5 h-3.5 text-seaweed" />
                        <span>{aide.availability}</span>
                      </div>
                      <div className="flex items-center gap-1.5 font-semibold text-coffee-bean">
                        <Phone className="w-3.5 h-3.5 text-seaweed" />
                        <a href={`tel:${aide.phone}`} className="hover:underline">
                          Direct Line: {aide.phone}
                        </a>
                      </div>
                    </div>
                  </div>

                  {/* Action Button */}
                  <div>
                    {isBeingRequested ? (
                      <form
                        onSubmit={handleRequestAideSubmit}
                        className="p-3 bg-pale-sky-light/40 border border-pale-sky rounded-xl space-y-2 mt-2"
                      >
                        <span className="text-xs font-bold text-coffee-bean block">
                          Request In-Home Intake Visit with {aide.name}:
                        </span>
                        <div>
                          <label className="text-[11px] text-coffee-bean-muted block mb-0.5 font-medium">
                            Your Contact Phone:
                          </label>
                          <input
                            type="tel"
                            required
                            placeholder="(e.g. 812-555-0100)"
                            value={aideContactPhone}
                            onChange={(e) => setAideContactPhone(e.target.value)}
                            className="w-full text-xs p-2 rounded-lg border border-pale-sky bg-white text-coffee-bean focus:border-seaweed focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="text-[11px] text-coffee-bean-muted block mb-0.5 font-medium">
                            Preferred Time of Day:
                          </label>
                          <select
                            value={aidePreferredTime}
                            onChange={(e) => setAidePreferredTime(e.target.value)}
                            className="w-full text-xs p-2 rounded-lg border border-pale-sky bg-white text-coffee-bean focus:border-seaweed focus:outline-none"
                          >
                            <option>Morning (8am - 12pm)</option>
                            <option>Afternoon (12pm - 4pm)</option>
                            <option>Evening (4pm - 7pm)</option>
                            <option>Flexible / Any time</option>
                          </select>
                        </div>
                        <div className="flex items-center gap-2 pt-1">
                          <button
                            type="submit"
                            className="flex-1 py-1.5 bg-seaweed hover:bg-seaweed-hover text-white text-xs font-bold rounded-lg shadow-2xs transition-colors cursor-pointer"
                          >
                            Confirm Visit Request
                          </button>
                          <button
                            type="button"
                            onClick={() => setRequestedAide(null)}
                            className="py-1.5 px-3 bg-slate-200 hover:bg-slate-300 text-coffee-bean text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      </form>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setRequestedAide(aide);
                          setAideRequestSuccess(null);
                        }}
                        className="w-full py-2 px-3 rounded-xl bg-seaweed hover:bg-seaweed-hover text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-all shadow-2xs cursor-pointer active:scale-98"
                      >
                        <UserCheck className="w-4 h-4" />
                        <span>Request Free In-Home Visit</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: SIGN UP A FAMILY MEMBER TO GET PAID BY MEDICAID                     */}
      {/* ========================================================================= */}
      {activeTab === 'family_sign_up' && (
        <div className="space-y-6">
          {/* Explanatory Hero Card */}
          <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-br from-purple-50 via-white to-seaweed-light/40 border border-purple-200 text-coffee-bean shadow-2xs">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-purple-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
                <HandHeart className="w-6 h-6" />
              </div>
              <div className="space-y-2">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-100 text-purple-800 text-xs font-bold border border-purple-300">
                  <DollarSign className="w-3.5 h-3.5 text-purple-700" />
                  <span>State Medicaid Attendant Care Benefit</span>
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-coffee-bean">
                  Get Paid by Medicaid to Care for Your Family Member
                </h3>
                <p className="text-xs sm:text-sm text-coffee-bean-muted leading-relaxed">
                  Under state Medicaid waiver guidelines in {selectedState}, family members who care
                  for loved ones with daily activities (such as cooking, cleaning, bathing, medication
                  reminders, and mobility) can receive competitive hourly compensation ({programInfo.payRateRange})
                  with $0 out-of-pocket costs to the family.
                </p>
              </div>
            </div>

            {/* Quick 3-Step Requirements */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-5 pt-4 border-t border-purple-100 text-xs">
              <div className="bg-white/80 p-3 rounded-xl border border-purple-100">
                <span className="font-bold text-purple-700 block mb-0.5">1. Eligibility</span>
                <span className="text-coffee-bean-muted">
                  Recipient has active Medicaid and requires help with daily activities.
                </span>
              </div>
              <div className="bg-white/80 p-3 rounded-xl border border-purple-100">
                <span className="font-bold text-purple-700 block mb-0.5">2. Who Can Qualify</span>
                <span className="text-coffee-bean-muted">
                  Adult daughters, sons, siblings, grandchildren, relatives, or trusted friends (18+).
                </span>
              </div>
              <div className="bg-white/80 p-3 rounded-xl border border-purple-100">
                <span className="font-bold text-purple-700 block mb-0.5">3. State Payroll</span>
                <span className="text-coffee-bean-muted">
                  Wages are paid via direct deposit every two weeks through the authorized state fiscal agency.
                </span>
              </div>
            </div>
          </div>

          {/* Application Success Banner */}
          {applicationSuccess && (
            <div className="p-5 rounded-2xl bg-emerald-50 border-2 border-emerald-400 text-emerald-950 space-y-2">
              <div className="flex items-center gap-2 font-bold text-base text-emerald-900">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <span>Family Caregiver Application Received!</span>
              </div>
              <p className="text-xs sm:text-sm leading-relaxed">
                Thank you, <strong>{applicationSuccess.applicantName}</strong>. Your enrollment ticket{' '}
                <code className="bg-emerald-100 px-1.5 py-0.5 rounded font-mono font-bold text-emerald-900">
                  {applicationSuccess.id}
                </code>{' '}
                has been routed to the {programInfo.fiscalAgent} for {countyName}.
              </p>
              <div className="text-xs bg-white/80 p-3 rounded-xl border border-emerald-200 mt-2 space-y-1">
                <div>
                  <strong>Next step:</strong> A state Medicaid care coordinator will call{' '}
                  <span className="underline font-bold">{applicationSuccess.phone}</span> within 2
                  business days to verify caregiver credentials and complete the state background check.
                </div>
                <div>
                  <strong>Helpline for questions:</strong> {programInfo.helpline}
                </div>
              </div>
            </div>
          )}

          {/* Interactive Enrollment Form */}
          <form
            onSubmit={handleFamilyFormSubmit}
            className="p-5 sm:p-6 rounded-2xl bg-white border border-pale-sky/90 shadow-2xs space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h4 className="font-bold text-sm sm:text-base text-coffee-bean flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-seaweed" />
                <span>Family Caregiver Sign-Up Application</span>
              </h4>
              <span className="text-[11px] text-coffee-bean-muted">No fee to apply</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-coffee-bean mb-1">
                  Family Caregiver Full Name: *
                </label>
                <input
                  type="text"
                  required
                  value={familyName}
                  onChange={(e) => setFamilyName(e.target.value)}
                  placeholder="e.g. Sarah Miller"
                  className="w-full text-xs sm:text-sm p-3 rounded-xl border border-pale-sky bg-white text-coffee-bean focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-coffee-bean mb-1">
                  Relationship to Loved One: *
                </label>
                <select
                  value={relationship}
                  onChange={(e) => setRelationship(e.target.value)}
                  className="w-full text-xs sm:text-sm p-3 rounded-xl border border-pale-sky bg-white text-coffee-bean focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20"
                >
                  <option>Adult Child (Son / Daughter)</option>
                  <option>Sister / Brother</option>
                  <option>Grandchild</option>
                  <option>Niece / Nephew / Relative</option>
                  <option>Spouse / Domestic Partner (Eligible under certain waivers)</option>
                  <option>Close Family Friend / Trusted Neighbor</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-coffee-bean mb-1">
                  Caregiver Contact Phone Number: *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. 812-555-0199"
                  className="w-full text-xs sm:text-sm p-3 rounded-xl border border-pale-sky bg-white text-coffee-bean focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-coffee-bean mb-1">
                  Caregiver Email Address (Optional):
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. sarah.miller@email.com"
                  className="w-full text-xs sm:text-sm p-3 rounded-xl border border-pale-sky bg-white text-coffee-bean focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-coffee-bean mb-1">
                Estimated Hours of Care Needed Weekly:
              </label>
              <select
                value={hoursNeeded}
                onChange={(e) => setHoursNeeded(e.target.value)}
                className="w-full text-xs sm:text-sm p-3 rounded-xl border border-pale-sky bg-white text-coffee-bean focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20"
              >
                <option>10 – 20 hours per week (Part-Time)</option>
                <option>20 – 30 hours per week (Standard Attendant Care)</option>
                <option>30 – 40 hours per week (Full-Time Daily Care)</option>
                <option>40+ hours per week (High-Intensity Living-In Care)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-coffee-bean mb-1.5">
                Types of Care You Provide to Your Loved One:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {[
                  'Bathing & Personal Care',
                  'Meal Preparation & Nutrition',
                  'Medication Reminders',
                  'Mobility, Walking & Transfer Assistance',
                  'Housekeeping & Laundry',
                  'Appointment & Grocery Escort',
                ].map((item) => (
                  <label
                    key={item}
                    className={`flex items-center gap-2 p-2.5 rounded-xl border transition-all cursor-pointer ${
                      selectedCareTypes.includes(item)
                        ? 'bg-seaweed-light/60 border-seaweed text-seaweed-dark font-semibold'
                        : 'bg-slate-50 border-slate-200 text-coffee-bean hover:bg-slate-100'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={selectedCareTypes.includes(item)}
                      onChange={() => toggleCareType(item)}
                      className="w-4 h-4 text-seaweed rounded focus:ring-seaweed border-slate-300"
                    />
                    <span>{item}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                id="submit-medicaid-family-caregiver-btn"
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer active:scale-98"
              >
                <Send className="w-4 h-4" />
                <span>Submit Family Caregiver Sign-Up ({programInfo.payRateRange})</span>
              </button>
              <p className="text-[11px] text-coffee-bean-muted mt-2">
                By submitting, you initiate a state Medicaid attendant care intake consultation. No cost or obligation.
              </p>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
