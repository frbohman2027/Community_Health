# AI_LOG.md - NASC - NASC 450 Fall 2026
Project: Wellness Online 

## Entry 001
**Date:** 2026-09-08
**Tool/ model:** Google AI Studio (Build) - Gemini
**Goal:** Generate the initial scaffold for the Wellness Online app 

**Prompt (verbatim):** 
>Build a single-page web app called "Wellness Online" for those who struggle getting to appointments in person.
>Build a single-page web app called "Wellness Online" for rural homeowners in Indiana who use private well water. The user enters their county from a dropdown and the date of their last water test. The app returns: (1) choose a county from KY, OH, IN, IL, (2) give a choice of language, (3) closest hospitals nearby, (4) doctors availability, (5) reason for appointment/ symptoms, (6) choice of insurance/ not have any, (7) pharmacies nearby to choose from/ check box if can’t pick up—need dropped off to house/alternative location, and (8) messaging with hospital for questions/ additional information. Requirements: Mobile-first layout; must be readable on a phone held at arm's length. Reading level: 8th grade. No jargon. Use placeholder data for the county list and hospitals; mark every placeholder clearly with a TODO comment so I can replace it with cited data later. Include a visible disclaimer that this tool is educational and is not a substitute for an emergency or all hospitals. Do not invent any statistics. If you need a number I have not supplied, insert TODO instead. 

**What the AI prodruced:**
Single-page app with a county dropdown in different language options,  closest hospitals, list of sympotms to choose from, and a spot to video call hospital staff/doctors
Layout was desktop-first depite my mobile-first instruction.

**What I evaluated and changed, and why:**
-It had many TODO for distance and phone numbers despite having the hospital and location. I removed the both since it wasn't giving the information. Instead I had the AI link the website to bring to the home page. 
-The language only gave English and Spanish, I added more because there are more languages. I have spoken with many different people who speak a variety of languages rather than just English and the basic five languages. 

## Entry 002
**Date:** 2026-09-09
**Goal:** Look over app to check functionability

**What I evaulated and changed, and why:**
-The top menu only had 911 and poison control number, I felt that it should also have a mental wellness box to call in case they feel that might help more than just the normal wellness check from a doctor. 
-There was some weird information about certain symptoms, so I changed to have basic symptoms that are usually on the charts you recieve at the doctors office with an extra box to add additional commments. 
-The AI only likes to add 3-5 counties per state. I asked the AI to add all counties of the state so that the people could get a more accurate represenation of the hospitals closest to them. 
-It wasn't allowing me to chose a different hosptial option once the first one was automatically chosen. I had to add a gox to the hospitals to check which one was being chosen. It didn't work the first time as it just added a check box next to the first hospital and still wouldn't let me chose a different option. I finally figured it out when I asked the AI to add one next to every single option. 

##Entry 003
**Date:** 2026-09-10
**Goal:** Final checks of the app to make sure everything looks good and works 

**What I evaulated and changed, and why:**
-added an interpretor button option to the language section, just in case the language spoken wasn't an option.
-I like the way the format of the set up is. However I feel that the language should be also able to not just be a drop down box. I added it to the main page to see which is chosen in chase the top dropbox isn't easily seen.
-Added the ability to have bigger text option for those who are using a phone or can't see as well. It is a lot of data being added and options to choose from. 

**Time:** ~2 hr

##Entry 004
**Date:** 2026-09-11
**Goal:** Alter Wellness Care from Find Care Parkview

**What I evaluated and changed, and why:**
-Updated State & County Selection, Symptoms, Insurance options, Pharmacy delivery choices, and Hospital messaging to share the warm Coffee Bean typography and Seaweed accents.
-Restyled the Telehealth Video consultation, Call & Talk audio simulator, and printable Patient Summary sheet to match the unified palette
-Added a dedicated "Need a Medical Interpreter? (Free)" section within the language component and header.
-Applied strict overflow constraints across the viewport, document root, and parent layout containers (overflow-x: hidden, width: 100%, max-width: 100vw)
-Included a checkable checklist inside the dropdown panel where users can check and uncheck symptoms directly, with search filtering and live status counts.
-Preserved the free-form doctor notes textarea right beneath the dropdown for additional clinical details.
-Comparing the telehealth apps to 'Wellness Online' the app is failry different as is, the need for more options on the main page is necessary. The other apps have multiple pages, so the one page information was essential. There is a lot more on the app then others in providing information. 

##Entry 005
**Date:** 2026-09-15
**Goal:**Alter formatting and looks of the app

**What I evaluated and changed, and why:** 
-Dark mode added to the options at the toggle bar. Automatically detects the user's OS color scheme preference (prefers-color-scheme: dark) on initial visit. 
-This was to just give more abilities to change the format for the user.
-Applied deep slate canvas backgrounds (#0E1318) and dark surfaces (#162029) across all interactive cards, dropdown menus, and dialogs.
-styled form elements, inputs, selects, and textareas with dark surfaces and light readable text.
-The format and styling is a big part of a successful app in today's society. The looks have to be appealing and still provide the useful content. 

## Entry 009
**Date:** 2026-09-17
**Goal:** Replace custom simulated div components with standard, fully functional HTML select and check-down menus across Location and Symptoms sections.

**What I evaluated and changed, and why:**
- **State & County Selection (`WellWaterIntake.tsx`):**
  - Replaced the button grid and extraneous search input divs with two clean, working `<select>` dropdown menus: `select#state-select` and `select#county-dropdown`.
  - Selecting a state dynamically updates the county options. Selecting a county updates the selected location and active medical facilities immediately.
- **Symptoms Dropdown & Check-Down Menu (`SymptomsSection.tsx`):**
  - Removed the simulated div dropdown component and outside-click listeners that interfered with user interaction in iframe environments.
  - Implemented a standard `<select id="symptoms-dropdown">` dropdown menu where choosing any symptom checks it off.
  - Paired with an accessible check-down menu containing native `<input type="checkbox">` controls for every symptom, allowing users to check and uncheck symptoms directly.
  - Included active counter, "Uncheck all" option, and clear doctor notes textarea.
  -It provided the look I wanted to give and it should be easier to choose and not have so much to click through to see the other data points necessary to fill out. 
- **Hospital Directory Dropdown (`HospitalsSection.tsx`):**
  - Added a `<select id="hospital-dropdown">` dropdown menu enabling immediate facility selection from a dropdown list.
  -This was to change the way so the information wasn't thrown into peoples' faces and become overwhelmed. 

##Entry 010
**Date:** 2026-09-19
**Tool/Model:** ChatGPT
**Goal:** Create 5 verified cititations

**What I evaluated and changed, and why:**
Dawkins, B., Renwick, C., Ensor, T., Shinkins, B., Jayne, D., & Meads, D. (2021). What factors affect patients’ ability to access healthcare? An overview of systematic reviews. Tropical Medicine & International Health, 26(10), 1177–1188. https://doi.org/10.1111/tmi.13651
Syed, S. T., Gerber, B. S., & Sharp, L. K. (2013). Traveling towards disease: Transportation barriers to health care access. Journal of Community Health, 38(5), 976–993. https://doi.org/10.1007/s10900-013-9681-1
Starbird, L. E., DiMaina, C., Sun, C.-A., & Han, H.-R. (2019). A systematic review of interventions to minimize transportation barriers among people with chronic diseases. Journal of Community Health, 44(2), 400–411. https://doi.org/10.1007/s10900-018-0572-3
Almathami, H. K. Y., Win, K. T., & Vlahu-Gjorgievska, E. (2020). Barriers and facilitators that influence telemedicine-based, real-time, online consultation at patients’ homes: Systematic literature review. Journal of Medical Internet Research, 22(2), e16407. https://doi.org/10.2196/16407
Kruse, C. S., Karem, P., Shifflett, K., Vegi, L., Ravi, K., & Brooks, M. (2018). Evaluating barriers to adopting telemedicine worldwide: A systematic review. Journal of Telemedicine and Telecare, 24(1), 4–12. https://doi.org/10.1177/1357633X16674087

## Entry 011
**Date:** 2026-09-20
**Tool:**Google AI Studio (Build) - Gemini
**Goal:** Add new additions

**What I evaluated and changed, and why:**
- Update the PharmacySection to display the operating hours for each listed pharmacy, including a badge showing if it is currently open or closed.
-Each pharmacy card displays today's hours alongside the overall regular weekly schedule.
-The pharmacy drop-down menu displays [OPEN NOW] or [CLOSED] status tags and today's hours for instant visibility when selecting a pharmacy.

## Entry 012
**Date:** 2026-09-20
**Tool:**Google AI Studio (Build) - Gemini
**Goal:** Fix App to be sure everything is working

**What I evaluated and changed, and why:**
-The action menu under the "Wellness Online" title now uses a non-wrapping horizontal track (overflow-x-auto) with touch swipe and trackpad support, preventing multi-row clutter or clipped buttons on mobile and narrow screens.
- Added smooth-scroll chevron buttons (‹ and ›) on either side that allow users to easily slide the menu to the left or right with a click or tap.
-Clearly visible arrow buttons flank the horizontal menu bar. The right chevron pulses with an active indicator when additional items remain off-screen, and both arrows smoothly advance the menu
-Added a helper caption below the bar with a direct "Move to see the rest →" trigger button.
-Changed to make the page more accessible. The top bar was not moving when I was trying to look at it, so I had to tell ai.studio to fix it. There were a few errors in the system and needeed to be fixed so the app would work smoother. 

## Entry 013
**Date:** 2026-09-24
**Tool:**Google AI Studio (Build) - Gemini
**Goal:** Additions to make it easier to use

**What I evaluated and changed, and why:**
-added to menu: Telehealth Video Appointment (Video Call), Clinic Nurse Line (Call & Talk), Arm's-Length Accessibility (Larger Text (Aa+)), Dark / Light Mode Toggle, Patient Intake Summary, Quick-jump navigation buttons to each step on the page
-The printable patient intake record summary modal also reflects the pharmacy's operating hours and live status badge.
-There were small additions I wanted to change to make it quicker to use for those who have used the app previously and didn't need to scroll all the way down the page to find the options needed. The summary page has the operating hours so that patients can figure out when to pick up their medicine or when it can be dropped off. 

## Entry 014
**Date:** 2026-10-01
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Enhance horizontal menu navigation with desktop drag-to-scroll, wheel translation, and non-clipping language selector

**What I evaluated and changed, and why:**
- **Desktop Drag-to-Scroll & Mouse Wheel Translation:**
  - Implemented interactive click-and-drag mouse navigation (`cursor-grab` / `cursor-grabbing`) across the action bar under "Wellness Online", complete with movement threshold detection so dragging does not trigger accidental button clicks.
  - Added mouse wheel translation (`wheel` listener converting vertical wheel deltas into horizontal track scroll), allowing standard desktop mouse users to move side-to-side effortlessly without needing trackpad tilt or shift keys.
- **Flanking Scroll Controls & Visual Continuity Cues:**
  - Replaced absolute overlay buttons with cleanly pinned flanking chevron buttons that never cover up menu items or shortcuts.
  - Added an active pulsing indicator ring on the right scroll button when additional controls remain off-screen, along with soft gradient fade masks on both edges and a clear helper caption with a direct "Move to see the rest →" trigger button.
- **Non-Clipping Header Language Dropdown:**
  - Updated the header language menu with fixed viewport overlay positioning and a backdrop dismiss layer, preventing dropdown items from getting clipped or distorted by the horizontal overflow container.
- **Why it was changed:**
  - Users on desktop mice and laptops without touchscreens were unable to comfortably slide the menu sideways to see the rest of the navigation options (County, Symptoms, Insurance, Hospitals, Pharmacy, Messaging). Adding drag-to-scroll, mouse wheel translation, and visible flanking arrows guarantees that every rural patient can easily navigate all options on any device.

## Entry 015
**Date:** 2026-10-01
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Implement single-page unified system navigation linking healthcare and direct community social resources

**What I evaluated and changed, and why:**
- **Single-Page System Navigation (Teggart et al., 2023):**
  - Evaluated research showing that expecting patients to search through separate, disconnected websites for healthcare, food, and transit causes system breakdown.
  - Implemented `CommunitySupportSection.tsx` (Step 6) directly inside the single-page flow, positioning local medical transportation, food assistance, well water test kits, and winter heating assistance right alongside clinical appointment booking.
- **Direct Referrals vs. Passive Directory Lists (Ruiz Escobar et al., 2021; Steeves-Reece et al., 2022):**
  - Addressed the finding that simply handing a patient an indirect organization list often results in no actual help received.
  - Added direct, actionable dispatch links: one-click medical transit booking (`tel:` phone lines to Medicaid Non-Emergency Transportation dispatchers), emergency food bank contacts, and county health department test kit requests.
- **Why it was changed:**
  - In rural communities across Indiana, Kentucky, Ohio, and Illinois, knowing a service exists is not enough if the patient cannot reach it. Consolidating health and social needs onto a single screen with direct action triggers eliminates fragmentation and removes barriers to care.

## Entry 016
**Date:** 2026-10-01
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Integrate Community Health Worker (CHW) and Rural Care Navigator direct human guidance

**What I evaluated and changed, and why:**
- **Community Health Worker (CHW) Care Navigation (Mistry et al., 2021):**
  - Evaluated evidence demonstrating that community health workers significantly improve chronic disease management, appointment follow-through, and patient confidence by organizing complex systems into understandable steps.
  - Built `CareNavigatorModal.tsx` and placed dedicated "Care Navigator (CHW)" triggers in the top action bar, horizontal navigation toolbar, and Community Support section.
- **Closing the Need-to-Connection Gap (Schickedanz et al., 2019):**
  - Provided a structured intake request form where rural patients can request free 1-on-1 assistance via phone call, telehealth video, or in-clinic visit for:
    1. Scheduling free or low-cost medical transit rides.
    2. Applying for hospital sliding-scale fee discounts and financial assistance.
    3. Overcoming language or paperwork hurdles.
    4. Coordinating rural pharmacy medication courier drop-offs.
- **Why it was changed:**
  - Digital platforms alone cannot replace human empathy. Giving rural families direct access to a dedicated care navigator bridges the critical gap between identifying a health need and actually getting the person helped.

## Entry 017
**Date:** 2026-10-01
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Implement personalized "CommunityRx" resource matching by county and patient need

**What I evaluated and changed, and why:**
- **Personalized "CommunityRx" Resource Generation (Lindau et al., 2019):**
  - Evaluated the CommunityRx clinical trial model, which showed that tailored community resource prescriptions significantly increase patient confidence in finding and using local support compared to generic, overwhelming directories.
  - Created `src/data/communityResourcesData.ts` to dynamically match resources to the patient's selected County and State (IN, KY, OH, IL), filtering for rural transit, emergency groceries, certified well water test kits, and energy relief.
- **Hospital-to-Community Bridge in Patient Summary 
  - Enhanced `WellnessSummaryModal.tsx` with a dedicated **"CommunityRx Social Support Plan"** section.
  - When patients select resources or request a care navigator, the details (service name, eligibility, coverage area, and direct phone line) are automatically attached to their printable and saveable appointment record slip.
- **Why it was changed:**
  - Patients should not have to sift through irrelevant statewide listings. The app now acts as a tailored bridge between hospitals and local grassroots community programs based on where the patient lives.

## Entry 018
**Date:** 2026-10-01
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Empower patient voice and autonomy with granular social determinants disclosure controls

**What I evaluated and changed, and why:**
- **Patient Autonomy & Avoiding Algorithmic Stigma (Hartzler et al., 2023):**
  - Evaluated ethical research warning that automated extraction of social determinants of health (SDOH) can cause stigma, mistrust, and violations of patient autonomy if the patient does not have control over how their information is documented and shared.
  - Implemented an interactive **"Patient Voice & Autonomy: What to Disclose on This Slip"** panel inside `WellnessSummaryModal.tsx`.
- **Granular Disclosure Checkboxes:**
  - Added checkboxes giving patients complete sovereignty over what appears on their printed intake slip or message to clinic triage:
  - If a patient prefers to keep their financial status or food assistance private, unchecking the box instantly removes it from the record.
- **Why it was changed:**
  - Patients must maintain authority over their personal narratives and sensitive social needs. Respecting patient autonomy builds trust between rural patients and healthcare providers.

## Entry 019
**Date:** 2026-10-01
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Embed patient privacy guarantees, health equity accessibility, and UN SDG 3.8 alignment

**What I evaluated and changed, and why:**
- **Data Confidentiality & Privacy Considered from Inception (Alhammad et al., 2024):**
  - Evaluated systematic reviews of mHealth apps showing that patient trust depends on transparent data privacy policies established from the start rather than tacked on as an afterthought.
  - Created `PatientPrivacyEquityModal.tsx` (accessible from both header and footer), certifying 100% on-device client storage with zero tracking telemetry, zero selling of personal data, and a 1-click "Reset All Local Health Data" button for total data erasure.
- **Health Equity & UN Sustainable Development Goal 3.8 (Antonio et al., 2019):**
  - Grounded the application in **UN SDG Target 3.8** (*"Achieve universal health coverage, including financial risk protection, access to quality essential health-care services and access to safe, effective, quality and affordable essential medicines"*).
  - Addressed digital health inequities identified by Antonio et al.: removed login/account barriers, optimized layout for low-bandwidth rural cellular networks, maintained 8th-grade reading level, provided arm's-length text sizing (Aa+), and supported 8 regional languages with free interpreter requests.
- **Why it was changed:**
  - Technology must not exacerbate health disparities. Transparent privacy protections, zero-barrier access, and alignment with global health equity standards guarantee that Wellness Online serves vulnerable rural populations safely and inclusively.

## Entry 020
**Date:** 2026-10-05
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Shift application focus to community-based free healthcare and grassroots neighbor support

**What I evaluated and changed, and why:**
- Transition to Community-Driven Free Healthcare:
  - I evaluated how community members access care in rural areas and realized that formal hospital directories can feel intimidating and disconnected from immediate neighborhood needs.
  - I shifted the core focus of the platform away from hospital facilities and toward local free healthcare, volunteer support, and neighborhood assistance.
  - I completely removed the hospitals directory section from the navigation and main page.
  - I also took out the rural delivery courier options because medications are typically picked up at local counters where community pharmacists offer free consultations, or neighbors help each other pick up prescriptions.
- Eliminating Formal Appointment Barriers:
  - I removed the reason for appointment phrasing across all areas of the platform and replaced it with a compassionate health concerns and symptoms overview.
  - This change helps everyday community members feel comfortable sharing what they are experiencing without feeling pressured by medical appointment bureaucracy.
  - The messaging desk was also re-centered around neighborhood help and community volunteers rather than institutional hospital administration.
- Why it was changed:
  - Neighbors and local clinics are often the true first line of defense for rural families. Redesigning the app around everyday community aid makes free healthcare accessible, friendly, and grounded in the general public.

## Entry 021
**Date:** 2026-10-05
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Remove payment wording, implement Medicaid home health aide and paid family caregiver options, and connect volunteers seeking experience

**What I evaluated and changed, and why:**
- Removing Payment Language from Insurance:
  - I noticed that seeing the word payment can cause anxiety for uninsured families and individuals living on tight budgets.
  - I thoroughly removed the word payment and self-pay terms from the entire insurance section and replaced them with language focused on free community care and sliding scale support.
  - This ensures that anyone seeking assistance knows they will never be turned away for lack of money.
- Medicaid In-Home Care and Paid Family Attendant Care:
  - I added a comprehensive new section that activates whenever Medicaid coverage is selected.
  - This new section introduces certified Home Health Aides available locally and provides families with a clear path to sign up a family member to get paid as a homemaker or personal attendant through Medicaid waiver programs.
  - Eligible family members can receive fifteen to twenty-two dollars per hour for providing essential home care, relieving financial stress while keeping loved ones safely in their own homes at zero out-of-pocket cost.
  - I created a dedicated section at the bottom for nursing students, pre-med students, and caring neighbors who want to gain valuable hands-on clinical and caregiving experience.
  - At the top of the page, I placed an easy jump to the bottom button so that anyone interested in volunteering can immediately scroll down to see open community help requests and sign up.
- Why it was changed:
  - Families often do not realize that Medicaid can pay a relative to care for an aging or ill parent, and nursing students are actively looking for community service hours. Bringing these opportunities together creates a supportive circle of care without financial burdens.

## Entry 022
**Date:** 2026-10-07
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Remove the wellness summary and water or soil testing, and refocus the application description entirely on healthcare

**What I evaluated and changed, and why:**
- Removing the Wellness Summary:
  - I evaluated user feedback and realized that an administrative summary slip was unnecessary for community members who simply need immediate healthcare and everyday help.
  - I completely removed the summary modal, top summary buttons, and save or print actions to keep the experience direct, simple, and clutter-free.  - I audited the entire application to remove all traces of private well water testing, soil sampling, test kit requests, and water-related check-ins.
  - The first section of the platform was renamed to focus purely on location and county selection so people can quickly choose their state and county to connect with local services.
  - All volunteer tasks and helper listings were updated to remove water sample courier tasks and replace them with food pantry deliveries and vital signs assistance.
- Updating the Platform Description to Healthcare:
  - I updated the core application description across the platform headers, metadata, and browser descriptions to focus explicitly on healthcare access.
  - The application is now clearly defined as a community healthcare navigator connecting rural families with free clinics, home health aides, prescription support, and neighborhood assistance.
- Why it was changed:
  - Streamlining the interface removes unnecessary distractions. By retiring environmental testing features and summary slips, the platform stays completely dedicated to accessible healthcare and community aid.

## Entry 023
**Date:** 2026-10-07
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Introduce the help request section with multi-check dropdown and county-matched community resources with home delivery indicators

**What I evaluated and changed, and why:**
  - I added a new dedicated section that lets community members select exactly what they or their families need help with.
  - I built a dropdown menu that allows people to check off multiple categories at the same time, including affordable food, medical transportation, emergency housing, utility heating assistance, prescription aid, in-home chores, diaper supplies, and mental health support.
  - Users can easily check and uncheck multiple needs, clear all selections, or see their active selections displayed as convenient chips.
  - Based on the categories checked, the platform provides tailored resources specifically for the county chosen.
  - For food and nutrition, it connects people to local church pantries, regional food banks, soup kitchens, and Meals on Wheels programs.
  - To protect individual privacy and avoid clutter, no personal names or personal contact numbers are displayed. The cards show only official organization titles, facility service types, program telephone lines, and operating hours.
  - Every resource card now prominently includes a physical street address so community members know exactly where the facility is located.
  - Each card also features a clear badge indicating whether the organization offers to bring sources directly to the person’s house, such as Meals on Wheels drivers bringing warm lunches to homebound seniors or mobile food pantries delivering grocery boxes to rural doorsteps.
  - If a rural county does not have a local facility in a specific checked category, the system automatically retrieves the closest available resource from an adjacent neighboring county.
  - When this occurs, a clear notice explains that the resource is from a nearby county and extends support to surrounding rural areas.
- Why it was changed:
  - Families facing hard times need direct answers on where to get food, rides, and heating help. Providing verified physical addresses, delivery details, and neighboring county fallbacks ensures that no rural family is left without a lifeline.

## Entry 024
**Date:** 2026-10-07
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Transform telehealth video into Help Video Call to guide users through the app and talk about next steps

**What I evaluated and changed, and why:**
- Transitioning Telehealth Video to Help Video Call:
  - I realized that calling the video feature telehealth could feel overly clinical or intimidating to community members who are not looking for an appointment but simply need someone to help them navigate.
  - I replaced all instances of telehealth video with Help Video Call across the top action cards, navigation bars, buttons, and multilingual language options.
  - This reframing removes medical intimidation and makes the video call an accessible welcome desk for any community member.
  - I redesigned the video room so users connect with a caring community care navigator rather than an impersonal examination room.
  - The live guide is equipped to walk community members through every section of the application, including county selection, symptom reviews, Medicaid paid caregiver options, food and utility resources, and volunteer support.
  - I added a direct through the app guide panel inside the call so users can easily see where to go and jump directly to relevant sections with guidance from their helper.
  - I integrated an interactive next steps planning tool directly inside the video call session.
  - While on video with their guide, users can review, check off, and add personalized next steps, such as contacting local Meals on Wheels drivers, filing Medicaid caregiver paperwork, or coordinating volunteer rides to clinics.
  - Users can copy or keep their customized next steps list so they leave the video call with complete clarity on what to do next.
- Why it was changed:
  - Facing health challenges or food insecurity in rural areas is stressful, and people often feel lost when trying to navigate complex support systems on their own. Connecting face-to-face with a real person who guides them through the platform and maps out tangible next steps restores confidence and ensures nobody has to figure it out alone.

## Entry 025
**Date:** 2026-10-08
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Rename app to Community Healthcare and remove health concerns and symptoms to fit the updated community-focused criteria

**What I evaluated and changed, and why:**
- Renaming the Platform to Community Healthcare:
  - I evaluated the overall branding of the application following the removal of wellness summaries, water and soil testing, and clinical telehealth appointments.
  - The former name Wellness Online suggested a generic commercial wellness or lifestyle site rather than what this application has become: a practical, grassroots healthcare lifeline for rural families.
  - I updated the application title to Community Healthcare across the platform metadata, browser header titles, navigation bar, footer notices, and all translation dictionaries.
  - I verified that the new identity accurately represents every major feature now active in the platform: free community clinics, Medicaid paid caregiver programs for family members, multi-checked community help resources like food pantries and Meals on Wheels home delivery, local healthcare volunteers, and the Help Video Call navigator.
- Deleting Health Concerns and Symptoms:
  - I evaluated the health concerns and symptoms portion and determined that it no longer fit the app criteria since the platform has been completely redirected.
  - The symptoms checklist was originally created for a clinical diagnostic setting where users picked bodily ailments like stomach pain or fever.
  - As the application evolved into Community Healthcare, its true purpose became connecting rural families with vital community support, free clinics, Medicaid in-home family caregiver pay, food banks, Meals on Wheels doorstep deliveries, and volunteer assistance.
  - Retaining a clinical symptom selector felt disjointed, overly clinical, and did not match the community-first criteria of the application.
  - I completely removed the symptoms component, associated state logic, and navigation shortcuts, and elevated the What Assistance Is Needed section into Step 2 directly following county selection.
  - Now, community members immediately see verified assistance options for their county rather than filling out clinical symptom forms.
- Why it was changed:
  - Community Healthcare fits the exact scope and spirit of the changes made for the app. Eliminating the symptoms section removes clinical friction and aligns the entire platform around community assistance, neighborly support, and dignified access to food, rides, caregiving, and healthcare.

## Entry 026
**Date:** 2026-10-09
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Restructure the opening experience with four distinct role sections and delete the access request modal

**What I evaluated and changed, and why:**
- Restructuring Opening Experience into Four Dedicated Sections:
  - I evaluated how different people arrive at Community Healthcare and realized that forcing every visitor through a single uniform path caused confusion. A case manager managing a caseload has completely different needs than a resident needing free clinic rides, a person looking for paid caregiving work, or a pre-health student wanting to volunteer.
  - I designed a four-portal role selector that appears immediately when the application is first opened. Visitors can choose whether they are in need of help, a case manager, wanting employment, or wanting to help.
  - For visitors in need of help, the application displays our full patient navigation pathway: county selection, community assistance needed, insurance coverage analysis, Medicaid family attendant programs, local pharmacies, CommunityRx food and transit navigation, and volunteer help desks.
  - For case managers, the application opens a secure caseload portal displaying client files, care plan statuses, urgent service needs, and volunteer dispatch tools.
  - For visitors wanting employment, the application opens a dedicated jobs portal highlighting Medicaid Paid Family Caregiver Attendant positions paying 15 to 22.50 dollars per hour, certified Home Health Aide openings, and rural medical transit driver roles with a direct application intake.
  - For visitors wanting to help, the platform opens a volunteer hub where nursing students, pre-meds, and local neighbors can register to provide vital checks, companionship visits, and prescription pickups.
  - I also added a sticky role switcher to the top navigation bar so anyone can switch between sections at any time without losing their county or language settings.
- Deleting the Access Request:
  - I examined the previous Care Navigator access request modal and determined that requiring users to submit an access request created an unnecessary gatekeeping barrier.
  - In a true community healthcare system, case management should be integrated directly into insurance coverage and dedicated portals rather than requiring an administrative access request.
  - I completely removed the Care Navigator access request modal, its background state tracking, and all access request buttons across the application.
- Why it was changed:
  - Giving visitors clear, distinct sections the moment the app opens ensures everyone immediately finds what they need without digging through irrelevant forms. Deleting the access request removes friction and ensures immediate, dignified access to community resources.

## Entry 027
**Date:** 2026-10-09
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Cover case managers under insurance selection and provide concrete zero-cost support options when not covered

**What I evaluated and changed, and why:**
- Integrating Case Manager Coverage into Insurance Selection:
  - I evaluated how rural residents access case management and realized that many people do not know that their existing health coverage often pays for a dedicated case manager or care coordinator.
  - I updated the insurance selection section so that when a client selects their coverage, the platform clearly indicates whether a case manager is covered by that plan.
  - When a user selects Medicaid or Healthy Indiana Plan, the app highlights that a case manager is 100 percent covered at zero dollar copay through state managed care organizations to coordinate doctors, transportation, and home supplies.
  - When a user selects Medicare, the app confirms that case management is covered under Medicare Part B Chronic Care Management for individuals with two or more ongoing conditions.
  - When a user selects Veterans Affairs coverage, the app confirms that case management is covered through VA Patient Aligned Care Teams and rural community care programs.
  - When private or employer insurance is chosen, the app notes that case management coverage depends on individual policy rules and offers guidance on requesting care coordination benefits.
- Clear Guidance and Alternative Options When Not Covered:
  - When a client selects uninsured, the application explicitly states that a case manager is not covered under this option.
  - To ensure nobody is left stranded without assistance, I built a dedicated section outlining four free, zero-cost options:
  - First, Federally Qualified Health Centers, which provide sliding fee community health workers and care coordinators regardless of insurance status or ability to pay.
  - Second, Area Agency on Aging and the 211 network, which provide state-funded public care managers and benefits enrollment assistance.
  - Third, Hospital Financial Hardship and Charity Care Advocates, which provide certified patient financial advocates who assist with Medicaid enrollment and hospital charity write-offs.
  - Fourth, our in-app Live Care Navigator and Help Video Call, which connects clients directly with live app navigators at no charge.
- Why it was changed:
  - Transparency around insurance coverage prevents surprise expenses and empowers clients to take full advantage of benefits they already have. For uninsured neighbors, providing four actionable, free alternatives ensures they still receive human guidance and care management support.

## Entry 028
**Date:** 2026-10-09
**Tool/Model:** Google AI Studio (Build) - Gemini
**Goal:** Restrict personal information and contact details to authorized case manager accounts to protect client and volunteer privacy

**What I evaluated and changed, and why:**
- Protecting Personal Privacy and Restricting Private Information:
  - I evaluated the privacy and confidentiality of individuals listed across the application, including both clients receiving care and volunteers offering help.
  - In a public health directory, displaying personal phone numbers, physical addresses, and full names without authorization presents significant safety and privacy risks.
  - I implemented strict access controls so that personal information is only accessible when logged in through a verified Case Manager account.
- Privacy Masking for Public and General Users:
  - In all public views, including in need of help, wanting employment, and wanting to help, individual identities and contact numbers are masked.
  - Volunteer names appear as anonymized community profiles, such as Community Volunteer 1 (BSN Student) or Community Volunteer 2 (Pre-Med Student), and direct telephone numbers are locked behind a protected notice explaining that contact details are restricted to case manager accounts.
  - A prominent confidentiality badge informs users that personal information is secured under patient privacy standards.
- Full Caseload Access for Case Manager Accounts:
  - When operating within the Case Manager portal, authorized case managers unlock complete, actionable client and volunteer details.
  - Case managers can see client full names, ages, phone numbers, exact street addresses, assigned insurance coverage, active care plans, urgent assistance needs, and clinical case notes.
  - Case managers can also view complete volunteer contact information, dispatch qualified student volunteers to specific client cases, and add new clients to their caseload through an intake form.
- Why it was changed:
  - Community healthcare depends on trust. Restricting private phone numbers and personal client information to case manager accounts protects vulnerable community members from unwanted solicitation or data exposure while giving professional case managers the detailed tools they need to coordinate care effectively.


