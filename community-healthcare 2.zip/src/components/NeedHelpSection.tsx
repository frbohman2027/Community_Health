import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  CheckSquare,
  Square,
  ChevronDown,
  ChevronUp,
  MapPin,
  Phone,
  Truck,
  Building2,
  Clock,
  HeartHandshake,
  AlertCircle,
  Sparkles,
  Info,
  CheckCircle2,
  X,
  Filter,
  Search,
} from 'lucide-react';
import { LanguageCode, StateCode } from '../types';
import {
  HELP_NEED_CATEGORIES,
  HelpNeedCategoryId,
  CommunityHelpResource,
  getHelpResourcesForNeeds,
} from '../data/needHelpResourcesData';

interface NeedHelpSectionProps {
  lang: LanguageCode;
  countyName: string;
  state: StateCode;
  stepNumber?: number;
}

export const NeedHelpSection: React.FC<NeedHelpSectionProps> = ({
  lang,
  countyName,
  state,
  stepNumber = 4,
}) => {
  // Dropdown open/close state
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Checked categories (allow multiple checks)
  // Default to food_meals and medical_transportation as intuitive initial examples
  const [checkedCategories, setCheckedCategories] = useState<HelpNeedCategoryId[]>([
    'food_meals',
  ]);

  // Optional delivery filter: all, only delivery, or only on-site
  const [deliveryFilter, setDeliveryFilter] = useState<'all' | 'delivery_only'>('all');

  // Search keyword within results
  const [searchQuery, setSearchQuery] = useState('');

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Toggle category check
  const handleToggleCategory = (id: HelpNeedCategoryId) => {
    setCheckedCategories((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Check all / Clear all
  const handleSelectAll = () => {
    setCheckedCategories(HELP_NEED_CATEGORIES.map((c) => c.id));
  };

  const handleClearAll = () => {
    setCheckedCategories([]);
  };

  // Retrieve resources for current county and checked categories
  // (Uses closest county fallback ONLY if no resources are available in the county)
  const matchedResources = useMemo(() => {
    const raw = getHelpResourcesForNeeds(checkedCategories, countyName, state);
    return raw.filter((res) => {
      // Delivery filter
      if (deliveryFilter === 'delivery_only' && !res.offersHomeDelivery) {
        return false;
      }
      // Search query filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = res.organizationTitle.toLowerCase().includes(query);
        const matchesSummary = res.servicesSummary.toLowerCase().includes(query);
        const matchesType = res.serviceType.toLowerCase().includes(query);
        const matchesAddress = res.address.toLowerCase().includes(query);
        return matchesTitle || matchesSummary || matchesType || matchesAddress;
      }
      return true;
    });
  }, [checkedCategories, countyName, state, deliveryFilter, searchQuery]);

  // Count how many categories are checked
  const checkedCount = checkedCategories.length;

  return (
    <div
      id="need-help-section"
      className="bg-white dark:bg-slate-900 rounded-3xl border border-pale-sky/80 dark:border-slate-800 shadow-2xs p-5 sm:p-7 transition-colors"
    >
      {/* Section Header */}
      <div className="flex items-center gap-3.5 mb-5 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="w-10 h-10 rounded-2xl bg-seaweed-light dark:bg-seaweed-dark/40 text-seaweed dark:text-seaweed-light border border-seaweed/30 flex items-center justify-center font-bold text-base shrink-0 shadow-2xs">
          {stepNumber}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-xl sm:text-2xl font-bold text-coffee-bean dark:text-slate-100 tracking-tight">
              What Assistance Is Needed
            </h2>
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-seaweed-light dark:bg-seaweed-dark/40 text-seaweed-dark dark:text-seaweed-light border border-seaweed/30">
              Community Resources & Neighbor Support
            </span>
          </div>
          <p className="text-coffee-bean-muted dark:text-slate-400 text-xs sm:text-sm mt-0.5">
            Check off the areas of assistance you or a family member need. We connect you with local churches, food banks, Meals on Wheels, and community support in {countyName}, {state}.
          </p>
        </div>
      </div>

      {/* DROPDOWN LIST WITH MULTIPLE CHECK SELECTION */}
      <div className="relative mb-5" ref={dropdownRef}>
        <label
          htmlFor="need-help-dropdown-btn"
          className="block font-bold text-coffee-bean dark:text-slate-200 text-sm sm:text-base mb-2 flex items-center gap-2"
        >
          <HeartHandshake className="w-4 h-4 text-seaweed shrink-0" />
          <span>Dropdown List: Check Off What You Need Help With (Multiple Checks Allowed)</span>
        </label>

        {/* Dropdown Toggle Button */}
        <button
          type="button"
          id="need-help-dropdown-btn"
          onClick={() => setIsDropdownOpen(!isDropdownOpen)}
          aria-expanded={isDropdownOpen}
          aria-haspopup="listbox"
          className={`w-full p-3.5 rounded-2xl border text-left flex items-center justify-between gap-3 font-semibold text-sm sm:text-base transition-all shadow-2xs cursor-pointer ${
            isDropdownOpen
              ? 'border-seaweed bg-seaweed-light/20 dark:bg-seaweed-dark/20 ring-2 ring-seaweed/20 text-coffee-bean dark:text-slate-100'
              : 'border-pale-sky dark:border-slate-700 bg-white dark:bg-slate-800 text-coffee-bean dark:text-slate-100 hover:border-seaweed'
          }`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="w-6 h-6 rounded-lg bg-seaweed-light dark:bg-seaweed-dark text-seaweed dark:text-seaweed-light flex items-center justify-center font-bold text-xs shrink-0">
              {checkedCount}
            </span>
            <span className="truncate">
              {checkedCount === 0
                ? 'Click here to choose what you need help with...'
                : `${checkedCount} Help ${checkedCount === 1 ? 'Area' : 'Areas'} Checked: ${checkedCategories
                    .map((id) => HELP_NEED_CATEGORIES.find((c) => c.id === id)?.label)
                    .filter(Boolean)
                    .join(', ')}`}
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0 text-coffee-bean-muted dark:text-slate-400">
            <span className="text-xs font-semibold hidden sm:inline">
              {isDropdownOpen ? 'Close Menu' : 'Open Dropdown List'}
            </span>
            {isDropdownOpen ? (
              <ChevronUp className="w-5 h-5 text-seaweed" />
            ) : (
              <ChevronDown className="w-5 h-5 text-seaweed" />
            )}
          </div>
        </button>

        {/* Dropdown Panel Menu */}
        {isDropdownOpen && (
          <div
            id="need-help-dropdown-menu"
            role="listbox"
            aria-multiselectable="true"
            className="absolute left-0 right-0 top-full mt-2 z-30 bg-white dark:bg-slate-800 border border-pale-sky dark:border-slate-700 rounded-3xl shadow-2xl p-4 sm:p-5 max-h-[460px] overflow-y-auto animate-in fade-in slide-in-from-top-2 duration-150"
          >
            {/* Quick Actions in Dropdown Header */}
            <div className="flex items-center justify-between gap-3 pb-3 mb-3 border-b border-slate-100 dark:border-slate-700 text-xs">
              <span className="font-bold text-coffee-bean dark:text-slate-200">
                Check off any assistance you need:
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSelectAll}
                  className="font-bold text-seaweed dark:text-seaweed-light hover:underline py-0.5 px-1.5 rounded cursor-pointer"
                >
                  Check All
                </button>
                <span className="text-slate-300 dark:text-slate-600">•</span>
                <button
                  type="button"
                  onClick={handleClearAll}
                  className="font-bold text-rose-600 dark:text-rose-400 hover:underline py-0.5 px-1.5 rounded cursor-pointer"
                >
                  Clear All
                </button>
              </div>
            </div>

            {/* List of checkable options */}
            <div className="space-y-2">
              {HELP_NEED_CATEGORIES.map((cat) => {
                const isChecked = checkedCategories.includes(cat.id);
                return (
                  <div
                    key={cat.id}
                    onClick={() => handleToggleCategory(cat.id)}
                    role="option"
                    aria-selected={isChecked}
                    className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 select-none ${
                      isChecked
                        ? 'bg-seaweed-light/40 dark:bg-seaweed-dark/30 border-seaweed/50 text-coffee-bean dark:text-slate-100 shadow-2xs'
                        : 'bg-slate-50/70 dark:bg-slate-900/40 border-slate-200/80 dark:border-slate-700/60 text-coffee-bean dark:text-slate-300 hover:bg-slate-100/80 dark:hover:bg-slate-700/50'
                    }`}
                  >
                    <div className="mt-0.5 shrink-0 text-seaweed">
                      {isChecked ? (
                        <CheckSquare className="w-5 h-5 fill-seaweed text-white" />
                      ) : (
                        <Square className="w-5 h-5 text-slate-400 dark:text-slate-500" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-bold text-sm text-coffee-bean dark:text-slate-100 flex items-center justify-between gap-2">
                        <span>{cat.label}</span>
                        {isChecked && (
                          <span className="text-[11px] font-extrabold px-2 py-0.2 rounded-full bg-seaweed text-white">
                            Checked
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-coffee-bean-muted dark:text-slate-400 mt-0.5 leading-relaxed">
                        {cat.description}
                      </p>
                      <div className="mt-1 text-[11px] font-medium text-seaweed-dark dark:text-seaweed-light">
                        Includes: {cat.exampleServices}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Dropdown footer button */}
            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700 flex justify-end">
              <button
                type="button"
                onClick={() => setIsDropdownOpen(false)}
                className="px-4 py-2 bg-seaweed hover:bg-seaweed-hover text-white rounded-xl text-xs sm:text-sm font-bold shadow-2xs transition-colors cursor-pointer"
              >
                Done / View Matched Resources
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ACTIVE CHECKED CHIPS & QUICK TOGGLES */}
      {checkedCategories.length > 0 && (
        <div className="mb-4">
          <div className="text-xs font-bold text-coffee-bean-muted dark:text-slate-400 mb-1.5 flex items-center justify-between">
            <span>Currently Checked ({checkedCategories.length}):</span>
            <button
              type="button"
              onClick={handleClearAll}
              className="text-[11px] font-semibold text-rose-600 dark:text-rose-400 hover:underline cursor-pointer"
            >
              Reset All
            </button>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            {checkedCategories.map((id) => {
              const cat = HELP_NEED_CATEGORIES.find((c) => c.id === id);
              if (!cat) return null;
              return (
                <span
                  key={id}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-seaweed-light text-seaweed-dark dark:bg-seaweed-dark/40 dark:text-seaweed-light border border-seaweed/30 shadow-2xs"
                >
                  <span>{cat.label}</span>
                  <button
                    type="button"
                    onClick={() => handleToggleCategory(id)}
                    className="hover:bg-seaweed/20 rounded-full p-0.5 cursor-pointer"
                    title={`Remove ${cat.label}`}
                  >
                    <X className="w-3.5 h-3.5 text-seaweed" />
                  </button>
                </span>
              );
            })}
          </div>
        </div>
      )}

      {/* FILTER & SEARCH BAR */}
      <div className="mb-5 p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-pale-sky/80 dark:border-slate-700 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Delivery filter toggle */}
        <div className="flex items-center gap-1.5 flex-wrap text-xs">
          <span className="font-bold text-coffee-bean dark:text-slate-200 flex items-center gap-1 mr-1">
            <Filter className="w-3.5 h-3.5 text-seaweed" />
            <span>Delivery:</span>
          </span>
          <button
            type="button"
            onClick={() => setDeliveryFilter('all')}
            className={`px-2.5 py-1 rounded-xl font-bold transition-all cursor-pointer ${
              deliveryFilter === 'all'
                ? 'bg-seaweed text-white shadow-2xs'
                : 'bg-white dark:bg-slate-800 text-coffee-bean dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100'
            }`}
          >
            All Services ({matchedResources.length})
          </button>
          <button
            type="button"
            onClick={() => setDeliveryFilter('delivery_only')}
            className={`px-2.5 py-1 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1 ${
              deliveryFilter === 'delivery_only'
                ? 'bg-seaweed text-white shadow-2xs'
                : 'bg-white dark:bg-slate-800 text-coffee-bean dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100'
            }`}
          >
            <Truck className="w-3 h-3" />
            <span>Offers Home Delivery</span>
          </button>
        </div>

        {/* Search input */}
        <div className="relative min-w-[200px]">
          <Search className="w-3.5 h-3.5 text-coffee-bean-muted dark:text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search resources or address..."
            className="w-full text-xs pl-8 pr-3 py-1.5 rounded-xl border border-pale-sky dark:border-slate-700 bg-white dark:bg-slate-900 text-coffee-bean dark:text-slate-100 placeholder:text-coffee-bean-muted focus:outline-none focus:border-seaweed"
          />
        </div>
      </div>

      {/* RESOURCE RESULTS */}
      {checkedCategories.length === 0 ? (
        <div className="p-8 rounded-3xl border border-dashed border-pale-sky dark:border-slate-700 text-center bg-slate-50/50 dark:bg-slate-800/30">
          <HeartHandshake className="w-10 h-10 text-seaweed mx-auto mb-2 opacity-80" />
          <h3 className="font-bold text-coffee-bean dark:text-slate-100 text-base mb-1">
            No Help Areas Selected Yet
          </h3>
          <p className="text-coffee-bean-muted dark:text-slate-400 text-xs sm:text-sm max-w-md mx-auto mb-4">
            Click the dropdown button above to check off what you or your family need assistance with (such as food, rides, heating, or prescription aid).
          </p>
          <button
            type="button"
            onClick={() => setIsDropdownOpen(true)}
            className="px-4 py-2 bg-seaweed hover:bg-seaweed-hover text-white rounded-xl font-bold text-xs sm:text-sm shadow-2xs transition-colors cursor-pointer"
          >
            Open Dropdown Menu to Check Items
          </button>
        </div>
      ) : matchedResources.length === 0 ? (
        <div className="p-8 rounded-3xl border border-slate-200 dark:border-slate-700 text-center bg-slate-50 dark:bg-slate-800/40">
          <AlertCircle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
          <h3 className="font-bold text-coffee-bean dark:text-slate-100 text-base mb-1">
            No Matching Services Found with Current Filters
          </h3>
          <p className="text-coffee-bean-muted dark:text-slate-400 text-xs sm:text-sm max-w-md mx-auto">
            Try switching the delivery filter back to &quot;All Services&quot; or clearing your search term to see all available community resources.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-coffee-bean-muted dark:text-slate-400 px-1">
            <span>
              Showing <strong>{matchedResources.length}</strong> community resources for{' '}
              <strong className="text-coffee-bean dark:text-slate-200">{countyName}, {state}</strong>
            </span>
            <span className="text-[11px] font-semibold text-seaweed dark:text-seaweed-light">
              No personal info displayed • Official facility services only
            </span>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {matchedResources.map((res) => (
              <div
                key={res.id}
                className={`p-5 rounded-3xl border transition-all ${
                  res.isClosestCountyFallback
                    ? 'bg-amber-50/50 dark:bg-amber-950/20 border-amber-300 dark:border-amber-700/60 shadow-2xs'
                    : 'bg-white dark:bg-slate-800/80 border-pale-sky/80 dark:border-slate-700 shadow-2xs hover:shadow-xs'
                }`}
              >
                {/* Fallback Warning Banner if pulled from closest county */}
                {res.isClosestCountyFallback && (
                  <div className="mb-3.5 p-3 rounded-2xl bg-amber-100/90 dark:bg-amber-900/50 border border-amber-300 dark:border-amber-700 text-amber-900 dark:text-amber-200 text-xs flex items-start gap-2.5">
                    <AlertCircle className="w-4 h-4 text-amber-700 dark:text-amber-300 shrink-0 mt-0.5" />
                    <div className="leading-relaxed">
                      <strong className="block font-bold">
                        Nearest Available Service in Closest County:
                      </strong>
                      No direct {res.categoryLabel.toLowerCase()} facility is listed inside {countyName}. This service is provided from{' '}
                      <strong>{res.fallbackCountyName || 'neighboring county'}</strong>, which extends coverage to neighboring rural communities.
                    </div>
                  </div>
                )}

                {/* Top Badges: Category & Organization Type */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-seaweed-light text-seaweed-dark dark:bg-seaweed-dark/40 dark:text-seaweed-light border border-seaweed/30">
                      {res.categoryLabel}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-600">
                      {res.serviceType}
                    </span>
                  </div>

                  {/* Brings Sources to Person's House Status Badge */}
                  {res.offersHomeDelivery ? (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 shadow-2xs">
                      <Truck className="w-3.5 h-3.5 text-emerald-700 dark:text-emerald-400 shrink-0" />
                      <span>Offers to Bring Sources to Your House</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 dark:bg-slate-700/60 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                      <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>On-Site Counter Service Only</span>
                    </span>
                  )}
                </div>

                {/* Organization Title (No personal names) */}
                <h3 className="text-base sm:text-lg font-bold text-coffee-bean dark:text-slate-100 tracking-tight mb-2">
                  {res.organizationTitle}
                </h3>

                {/* MANDATORY: Physical Street Address */}
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-700/80 mb-3 text-xs sm:text-sm space-y-1.5">
                  <div className="flex items-start gap-2 text-coffee-bean dark:text-slate-200">
                    <MapPin className="w-4 h-4 text-seaweed shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-coffee-bean dark:text-slate-100">Physical Address: </span>
                      <span className="font-semibold text-coffee-bean dark:text-slate-200">{res.address}</span>
                      <span className="text-coffee-bean-muted dark:text-slate-400 text-xs ml-1">
                        ({res.county} County, {res.state})
                      </span>
                    </div>
                  </div>

                  {/* Delivery details if home drop-off is offered */}
                  {res.offersHomeDelivery && res.homeDeliveryDetails && (
                    <div className="flex items-start gap-2 pt-1 border-t border-slate-200/60 dark:border-slate-700/60 text-emerald-800 dark:text-emerald-300 text-xs">
                      <Truck className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <div className="leading-relaxed">
                        <strong className="font-bold">Home Delivery Details: </strong>
                        {res.homeDeliveryDetails}
                      </div>
                    </div>
                  )}
                </div>

                {/* Services Provided Summary */}
                <p className="text-xs sm:text-sm text-coffee-bean-muted dark:text-slate-300 leading-relaxed mb-3">
                  {res.servicesSummary}
                </p>

                {/* Hours & Contact Bar */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-700/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-1.5 text-coffee-bean dark:text-slate-300">
                    <Clock className="w-3.5 h-3.5 text-seaweed shrink-0" />
                    <span><strong>Hours: </strong>{res.hours}</span>
                  </div>

                  <a
                    href={`tel:${res.phone.replace(/[^0-9]/g, '')}`}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-seaweed hover:bg-seaweed-hover text-white font-bold text-xs shadow-2xs transition-colors cursor-pointer"
                  >
                    <Phone className="w-3.5 h-3.5 text-neon-ice" />
                    <span>Call Service: {res.phone}</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
