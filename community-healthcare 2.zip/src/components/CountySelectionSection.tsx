import React, { useMemo } from 'react';
import { MapPin } from 'lucide-react';
import { CountyOption, LanguageCode, StateCode } from '../types';
import { PLACEHOLDER_COUNTIES } from '../data/placeholderData';
import { TRANSLATIONS } from '../utils/translations';

interface CountySelectionSectionProps {
  lang: LanguageCode;
  selectedState: StateCode | 'ALL';
  onStateChange: (state: StateCode | 'ALL') => void;
  selectedCountyCode: string;
  onCountyChange: (countyCode: string) => void;
}

export const CountySelectionSection: React.FC<CountySelectionSectionProps> = ({
  lang,
  selectedState,
  onStateChange,
  selectedCountyCode,
  onCountyChange,
}) => {
  const t = TRANSLATIONS[lang];

  // Filter counties by selected state or show all
  const filteredCounties = useMemo(() => {
    if (selectedState === 'ALL') {
      return PLACEHOLDER_COUNTIES;
    }
    return PLACEHOLDER_COUNTIES.filter((c) => c.state === selectedState);
  }, [selectedState]);

  return (
    <div
      id="county-selection-section"
      className="bg-white dark:bg-slate-900 rounded-3xl border border-pale-sky/80 dark:border-slate-800 shadow-2xs p-5 sm:p-7 transition-colors"
    >
      <div className="flex items-center gap-3.5 mb-5 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="w-10 h-10 rounded-2xl bg-seaweed-light dark:bg-seaweed-dark/40 text-seaweed dark:text-seaweed-light border border-seaweed/30 flex items-center justify-center font-bold text-base shrink-0 shadow-2xs">
          1
        </div>
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-coffee-bean dark:text-slate-100 tracking-tight">
            {t.step1Title}
          </h2>
          <p className="text-coffee-bean-muted dark:text-slate-400 text-xs sm:text-sm mt-0.5">{t.step1Subtitle}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* State Selection Dropdown Menu */}
        <div>
          <label
            htmlFor="state-select"
            className="block font-bold text-coffee-bean dark:text-slate-200 text-sm sm:text-base mb-2"
          >
            {t.selectYourState}
          </label>
          <select
            id="state-select"
            value={selectedState}
            onChange={(e) => {
              const newState = e.target.value as StateCode | 'ALL';
              onStateChange(newState);
              const firstInState = PLACEHOLDER_COUNTIES.find(
                (c) => newState === 'ALL' || c.state === newState
              );
              if (firstInState) {
                onCountyChange(firstInState.code);
              }
            }}
            className="w-full text-sm sm:text-base p-3.5 rounded-2xl border border-pale-sky dark:border-slate-700 bg-white dark:bg-slate-800 text-coffee-bean dark:text-slate-100 font-semibold focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20 transition-all shadow-2xs cursor-pointer"
          >
            <option value="IN">Indiana (IN) - 92 Counties</option>
            <option value="KY">Kentucky (KY) - 120 Counties</option>
            <option value="OH">Ohio (OH) - 88 Counties</option>
            <option value="IL">Illinois (IL) - 102 Counties</option>
            <option value="ALL">All States (IN, KY, OH, IL)</option>
          </select>
        </div>

        {/* County Selection Dropdown Menu */}
        <div>
          <label
            htmlFor="county-dropdown"
            className="block font-bold text-coffee-bean dark:text-slate-200 text-sm sm:text-base mb-2 flex items-center gap-1.5"
          >
            <MapPin className="w-4 h-4 text-seaweed shrink-0" />
            <span>{t.selectYourCounty}</span>
          </label>
          <select
            id="county-dropdown"
            value={selectedCountyCode}
            onChange={(e) => {
              const code = e.target.value;
              onCountyChange(code);
              const c = PLACEHOLDER_COUNTIES.find((x) => x.code === code);
              if (c && selectedState !== 'ALL' && c.state !== selectedState) {
                onStateChange(c.state);
              }
            }}
            className="w-full text-sm sm:text-base p-3.5 rounded-2xl border border-pale-sky dark:border-slate-700 bg-white dark:bg-slate-800 text-coffee-bean dark:text-slate-100 font-semibold focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20 transition-all shadow-2xs cursor-pointer"
          >
            {filteredCounties.map((c: CountyOption) => (
              <option key={c.code} value={c.code}>
                {c.name} County, {c.state}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};
