import { HomeHealthAide, StateCode } from '../types';

export const MEDICAID_PROGRAM_DETAILS: Record<StateCode, {
  programName: string;
  waiverTitle: string;
  payRateRange: string;
  fiscalAgent: string;
  helpline: string;
  summary: string;
  eligibleCaregivers: string[];
}> = {
  IN: {
    programName: 'Indiana Structured Family Caregiving & Attendant Care (A&D Waiver)',
    waiverTitle: 'FSSA Division of Aging Medicaid Waiver',
    payRateRange: '$16 – $21 / hour (or up to $850/week tax-exempt stipend)',
    fiscalAgent: 'ACASA Senior Care / Caregiver Homes of Indiana / FSSA Enrollment Desk',
    helpline: '1-800-986-3505',
    summary:
      'Under Indiana Medicaid waivers, eligible family members (adult children, siblings, relatives, in-laws) can get paid legally by Medicaid to provide daily homemaker and attendant care to their loved one at home with $0 cost to the family.',
    eligibleCaregivers: ['Adult children (18+)', 'Siblings', 'Nieces/Nephews', 'In-laws', 'Close family friends / neighbors'],
  },
  KY: {
    programName: 'Kentucky Participant Directed Services (PDS / HCB Waiver)',
    waiverTitle: 'Cabinet for Health and Family Services Medicaid Waiver',
    payRateRange: '$15 – $20 / hour',
    fiscalAgent: 'Kentucky PDS Financial Intermediary / Area Agency on Aging',
    helpline: '1-844-784-5614',
    summary:
      'Kentucky Medicaid Participant-Directed Services empowers Medicaid beneficiaries to hire and pay chosen family members as their personal attendant care providers at home.',
    eligibleCaregivers: ['Adult daughters/sons', 'Sisters/Brothers', 'Grandchildren', 'Relatives', 'Trusted friends'],
  },
  OH: {
    programName: 'Ohio PASSPORT Waiver & Home Care Attendant Program',
    waiverTitle: 'Ohio Department of Medicaid PASSPORT Waiver',
    payRateRange: '$16 – $22 / hour',
    fiscalAgent: 'Ohio Area Agencies on Aging (AAA) / Morning Sun Financial',
    helpline: '1-866-243-5678',
    summary:
      'Ohio PASSPORT allows Medicaid recipients to select family members as certified individual providers for attendant care, personal hygiene, and homemaking services.',
    eligibleCaregivers: ['Adult children', 'Siblings', 'Extended relatives', 'Trusted family friends'],
  },
  IL: {
    programName: 'Illinois Community Care Program (CCP) & Home Services Program',
    waiverTitle: 'Illinois Department of Healthcare and Family Services (HFS)',
    payRateRange: '$17 – $22 / hour',
    fiscalAgent: 'Illinois Care Coordination Units (CCU) / SEIU Home Care Partner',
    helpline: '1-800-252-8966',
    summary:
      'Illinois allows individuals receiving Medicaid to designate family members as individual personal assistants (PA) who receive competitive hourly pay through state-managed payroll.',
    eligibleCaregivers: ['Adult family members', 'Children', 'Siblings', 'Relatives', 'Community members'],
  },
};

export const PLACEHOLDER_HHAS: HomeHealthAide[] = [
  {
    id: 'hha-1',
    name: 'Brenda Miller, HHA',
    credentials: 'Certified Home Health Aide • CPR/First Aid Certified',
    experienceYears: 9,
    rating: 4.9,
    reviewsCount: 38,
    state: 'IN',
    countiesServed: ['Monroe County', 'Brown County', 'Lawrence County', 'Owen County', 'Morgan County'],
    bio: 'Dedicated rural home health aide with 9 years of hands-on experience supporting seniors and individuals with mobility challenges. Specializes in gentle morning routines, medication organization, and home safety.',
    services: [
      'Bathing & Personal Hygiene Assistance',
      'Medication Reminders & Charting',
      'Meal Preparation & Nutrition',
      'Safe Mobility & Transfer Support',
      'Companionship & Gentle Walks',
    ],
    languages: ['English'],
    acceptsMedicaid: true,
    phone: '(812) 555-0142',
    availability: 'Available Mon–Fri, Morning & Afternoon',
  },
  {
    id: 'hha-2',
    name: 'Carlos Hernandez, CNA / HHA',
    credentials: 'Certified Nursing Assistant • Medicaid Attendant Specialist',
    experienceYears: 6,
    rating: 5.0,
    reviewsCount: 29,
    state: 'IN',
    countiesServed: ['Monroe County', 'Greene County', 'Owen County', 'Sullivan County', 'Clay County'],
    bio: 'Bilingual certified caregiver passionate about rural community health and dignified elder care. Experienced with wheelchair transfers, range-of-motion exercises, and blood sugar log checks.',
    services: [
      'Vital Signs & Blood Sugar Logs',
      'Light Homemaking & Sanitizing',
      'Transfer & Ambulation Assistance',
      'Appointment Accompaniment',
      'Bilingual Patient Support (EN/ES)',
    ],
    languages: ['English', 'Spanish'],
    acceptsMedicaid: true,
    phone: '(812) 555-0188',
    availability: 'Available Weekdays & Saturday Mornings',
  },
  {
    id: 'hha-3',
    name: 'Rachel Vance, HHA',
    credentials: 'State Certified Attendant • Dementia & Alzheimer’s Care Certificate',
    experienceYears: 12,
    rating: 4.9,
    reviewsCount: 44,
    state: 'IN',
    countiesServed: ['Monroe County', 'Morgan County', 'Johnson County', 'Marion County'],
    bio: 'Compassionate attendant caregiver focusing on memory care, soothing daily structure, and family caregiver respite. Former nursing student who chose full-time community home care.',
    services: [
      'Dementia & Memory Care Routines',
      'Medication Cueing & Hydration Support',
      'Personal Grooming & Dressing',
      'Family Caregiver Respite Relief',
      'Home Safety Hazard Review',
    ],
    languages: ['English'],
    acceptsMedicaid: true,
    phone: '(812) 555-0211',
    availability: 'Available Mon–Thu, Full Days',
  },
  {
    id: 'hha-4',
    name: 'Darnell Washington, HHA',
    credentials: 'Certified Home Health Aide • Physical Therapy Aide Certificate',
    experienceYears: 7,
    rating: 4.8,
    reviewsCount: 26,
    state: 'KY',
    countiesServed: ['Jefferson County', 'Bullitt County', 'Oldham County', 'Shelby County', 'Spencer County'],
    bio: 'Patient, gentle caregiver specializing in post-surgery recovery, mobility preservation, and Parkinson’s support in rural Kentucky homes.',
    services: [
      'Assisted Ambulation & Exercise Routines',
      'Bed-to-Chair Transfers',
      'Wholesome Meal Cooking',
      'Personal Care & Hygiene',
      'Medication Tracking',
    ],
    languages: ['English'],
    acceptsMedicaid: true,
    phone: '(502) 555-0164',
    availability: 'Available Mon–Fri 8am–4pm',
  },
  {
    id: 'hha-5',
    name: 'Maria Elena Gomez, CNA',
    credentials: 'Certified Nursing Assistant • Medicaid Waiver Enrolled Provider',
    experienceYears: 11,
    rating: 5.0,
    reviewsCount: 52,
    state: 'KY',
    countiesServed: ['Fayette County', 'Clark County', 'Bourbon County', 'Jessamine County', 'Scott County'],
    bio: 'Warm, patient caregiver experienced in helping families navigate long-term home health. High expertise in stroke recovery, gentle repositioning, and companionship.',
    services: [
      'Full Personal Care & Sponge Bathing',
      'Light Housekeeping & Laundry',
      'Doctor Appointment Escort',
      'Healthy Grocery Meal Prep',
      'Bilingual Care (EN/ES)',
    ],
    languages: ['English', 'Spanish'],
    acceptsMedicaid: true,
    phone: '(859) 555-0175',
    availability: 'Available Flexible Hours / On Call',
  },
  {
    id: 'hha-6',
    name: 'Sarah Jenkins, HHA',
    credentials: 'Certified Home Health Aide • Rural Health Volunteer Veteran',
    experienceYears: 8,
    rating: 4.9,
    reviewsCount: 31,
    state: 'OH',
    countiesServed: ['Franklin County', 'Pickaway County', 'Fairfield County', 'Licking County', 'Madison County'],
    bio: 'Ohio native committed to serving rural households who cannot easily reach city clinics. Specializes in attendant care, diabetic meal planning, and companionship.',
    services: [
      'Homemaking & Attendant Care',
      'Personal Hygiene & Bathing',
      'Diabetic Friendly Cooking',
      'Vital Signs & Medication Monitoring',
      'Errands & Prescription Pick-up Help',
    ],
    languages: ['English'],
    acceptsMedicaid: true,
    phone: '(614) 555-0193',
    availability: 'Available Mon–Fri & Weekend Respite',
  },
  {
    id: 'hha-7',
    name: 'Evelyn Kowalski, CNA / HHA',
    credentials: 'State Certified Personal Assistant • CPR & First Aid',
    experienceYears: 10,
    rating: 5.0,
    reviewsCount: 40,
    state: 'IL',
    countiesServed: ['Champaign County', 'Vermilion County', 'Douglas County', 'Piatt County', 'Edgar County'],
    bio: 'Experienced attendant who treats every client like beloved family. Deep experience with rural seniors, arthritis care, and adaptive equipment assistance.',
    services: [
      'Adaptive Equipment Assistance (Walkers/Wheelchairs)',
      'Companion Care & Conversation',
      'Personal Hygiene & Grooming',
      'Household Errands & Nutrition',
      'Medication Reminders',
    ],
    languages: ['English'],
    acceptsMedicaid: true,
    phone: '(217) 555-0139',
    availability: 'Available Weekdays & Alternating Weekends',
  },
];

export function getHomeHealthAidesForCounty(countyName: string, state: StateCode): HomeHealthAide[] {
  // First match aides whose service counties list contains the county or state
  const directMatch = PLACEHOLDER_HHAS.filter((hha) => {
    const stateMatch = hha.state === state;
    const countyMatch = hha.countiesServed.some((c) =>
      c.toLowerCase().includes(countyName.toLowerCase().replace(' county', ''))
    );
    return stateMatch && countyMatch;
  });

  if (directMatch.length > 0) {
    return directMatch;
  }

  // Fallback to state match
  const stateMatch = PLACEHOLDER_HHAS.filter((hha) => hha.state === state);
  if (stateMatch.length > 0) {
    return stateMatch;
  }

  // Fallback to all HHAs
  return PLACEHOLDER_HHAS;
}
