import React, { useMemo, useState, useEffect } from 'react';
import {
  Pill,
  MapPin,
  Phone,
  Check,
  Clock,
  ChevronDown,
  ChevronUp,
  Calendar,
} from 'lucide-react';
import { LanguageCode } from '../types';
import { getPharmaciesForCounty, PLACEHOLDER_COUNTIES } from '../data/placeholderData';
import { TRANSLATIONS } from '../utils/translations';
import { getPharmacyStatus } from '../utils/pharmacyHours';

interface PharmacySectionProps {
  lang: LanguageCode;
  selectedCountyCode: string;
  selectedPharmacyId: string;
  onSelectPharmacy: (id: string) => void;
}

export const PharmacySection: React.FC<PharmacySectionProps> = ({
  lang,
  selectedCountyCode,
  selectedPharmacyId,
  onSelectPharmacy,
}) => {
  const t = TRANSLATIONS[lang];

  // Live timer to keep open/closed calculation accurate in real-time
  const [currentTime, setCurrentTime] = useState<Date>(() => new Date());
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  // Track which pharmacy cards have their full weekly hours expanded
  const [expandedHoursMap, setExpandedHoursMap] = useState<Record<string, boolean>>({});

  const toggleHoursExpand = (id: string, e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    setExpandedHoursMap((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  // Look up county object
  const countyObj = useMemo(
    () => PLACEHOLDER_COUNTIES.find((c) => c.code === selectedCountyCode),
    [selectedCountyCode]
  );

  // Match county local pharmacies directly for the chosen county
  const localPharmacies = useMemo(
    () => getPharmaciesForCounty(selectedCountyCode),
    [selectedCountyCode]
  );

  // Auto-sync if selected pharmacy does not match any pharmacy in this county
  useEffect(() => {
    if (localPharmacies.length > 0 && !localPharmacies.some((p) => p.id === selectedPharmacyId)) {
      onSelectPharmacy(localPharmacies[0].id);
    }
  }, [localPharmacies, selectedPharmacyId, onSelectPharmacy]);

  // Formatted local time string for reference
  const formattedLocalTime = useMemo(() => {
    try {
      return currentTime.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    } catch {
      return '';
    }
  }, [currentTime]);

  return (
    <div
      id="pharmacy-section"
      className="bg-white dark:bg-slate-900 rounded-3xl border border-pale-sky/80 dark:border-slate-800 shadow-2xs p-5 sm:p-7 transition-colors"
    >
      {/* Header */}
      <div className="flex items-center gap-3.5 mb-5 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="w-10 h-10 rounded-2xl bg-seaweed-light text-seaweed border border-seaweed/30 flex items-center justify-center font-bold text-base shrink-0 shadow-2xs">
          5
        </div>
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-coffee-bean dark:text-slate-100 tracking-tight">
            {t.pharmacySectionTitle}
          </h2>
          <p className="text-coffee-bean-muted dark:text-slate-400 text-xs sm:text-sm mt-0.5">
            {t.pharmacySectionSubtitle}
          </p>
        </div>
      </div>

      {/* Active Chosen County Location & Live Hours Indicator */}
      <div className="mb-4 p-3 sm:p-3.5 rounded-2xl bg-seaweed-light/40 dark:bg-seaweed-dark/20 border border-seaweed/30 flex flex-wrap items-center justify-between gap-2.5">
        <div className="flex items-center gap-2 min-w-0">
          <MapPin className="w-4 h-4 text-seaweed shrink-0" />
          <div className="text-xs sm:text-sm text-coffee-bean dark:text-slate-200 font-semibold truncate">
            Local Pharmacies in{' '}
            <span className="font-extrabold text-seaweed-dark dark:text-seaweed-light">
              {countyObj ? `${countyObj.name}, ${countyObj.state}` : 'Selected County'}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {formattedLocalTime && (
            <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-white/80 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-coffee-bean dark:text-slate-300 flex items-center gap-1 shadow-2xs">
              <Clock className="w-3 h-3 text-seaweed" />
              <span>Local Time: {formattedLocalTime}</span>
            </span>
          )}
          <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-white dark:bg-slate-800 border border-seaweed/30 text-seaweed-dark dark:text-seaweed-light shadow-2xs">
            {localPharmacies.length} Local Options
          </span>
        </div>
      </div>

      {/* 1. Drop Down Menu to Select Local Pharmacy with Live Open/Closed Badges */}
      <div className="mb-4">
        <label
          htmlFor="pharmacy-dropdown"
          className="block font-bold text-coffee-bean dark:text-slate-200 text-sm sm:text-base mb-2 flex items-center gap-2"
        >
          <Pill className="w-4 h-4 text-seaweed shrink-0" />
          <span>Select Preferred Pharmacy from Drop Down Menu:</span>
        </label>
        <select
          id="pharmacy-dropdown"
          value={selectedPharmacyId}
          onChange={(e) => onSelectPharmacy(e.target.value)}
          className="w-full text-sm sm:text-base p-3.5 rounded-2xl border border-pale-sky dark:border-slate-700 bg-white dark:bg-slate-800 text-coffee-bean dark:text-slate-100 font-semibold focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20 transition-all shadow-2xs cursor-pointer"
        >
          {localPharmacies.map((pharmacy) => {
            const status = getPharmacyStatus(pharmacy.hours, pharmacy.id, currentTime);
            const statusTag = status.isOpen ? 'OPEN NOW' : 'CLOSED';
            return (
              <option key={pharmacy.id} value={pharmacy.id}>
                [{statusTag}] {pharmacy.name} — Today: {status.todayHoursText} ({pharmacy.address})
              </option>
            );
          })}
        </select>
      </div>

      {/* 2. Pharmacy Selection Radio Cards with Hours & Status Badges */}
      <div className="space-y-3 mb-6">
        <label className="block text-xs sm:text-sm font-bold text-coffee-bean dark:text-slate-300 mb-1">
          Or review operating hours and tap to select your pharmacy below:
        </label>
        {localPharmacies.map((pharmacy) => {
          const isSelected = selectedPharmacyId === pharmacy.id;
          const status = getPharmacyStatus(pharmacy.hours, pharmacy.id, currentTime);
          const isExpanded = !!expandedHoursMap[pharmacy.id];

          return (
            <div
              key={pharmacy.id}
              id={`pharmacy-option-${pharmacy.id}`}
              onClick={() => onSelectPharmacy(pharmacy.id)}
              className={`p-4 sm:p-4.5 rounded-2xl border transition-all cursor-pointer ${
                isSelected
                  ? 'border-seaweed bg-seaweed-light/60 dark:bg-seaweed-dark/30 ring-2 ring-seaweed/20 shadow-2xs'
                  : 'border-pale-sky/80 dark:border-slate-800 bg-pale-sky-light/20 dark:bg-slate-800/40 hover:bg-pale-sky-light/40 dark:hover:bg-slate-800/70 hover:border-pale-sky'
              }`}
            >
              {/* Top row: Radio + Name + Badges */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 min-w-0">
                  <input
                    type="radio"
                    id={`pharmacy-radio-${pharmacy.id}`}
                    name="pharmacy-choice"
                    checked={isSelected}
                    onChange={() => onSelectPharmacy(pharmacy.id)}
                    className="w-5 h-5 text-seaweed focus:ring-seaweed border-slate-300 dark:border-slate-600 mt-0.5 cursor-pointer shrink-0"
                  />
                  <div className="min-w-0">
                    <div className="font-bold text-sm sm:text-base text-coffee-bean dark:text-slate-100 flex items-center gap-2 flex-wrap">
                      <span>{pharmacy.name}</span>
                      {isSelected && (
                        <span className="w-4 h-4 rounded-full bg-seaweed text-white inline-flex items-center justify-center shrink-0">
                          <Check className="w-2.5 h-2.5" />
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 text-xs text-coffee-bean-muted dark:text-slate-400 mt-1">
                      <MapPin className="w-3.5 h-3.5 text-coffee-bean-muted shrink-0" />
                      <span className="truncate">{pharmacy.address}</span>
                    </div>

                    {pharmacy.phone && (
                      <div className="flex items-center gap-1.5 text-xs text-coffee-bean-muted dark:text-slate-400 mt-0.5">
                        <Phone className="w-3.5 h-3.5 text-coffee-bean-muted shrink-0" />
                        <span>{pharmacy.phone}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Status Badge: Open / Closed Badge */}
                <div className="flex flex-col items-end gap-1.5 shrink-0">
                  {status.isOpen ? (
                    <span
                      id={`pharmacy-badge-open-${pharmacy.id}`}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 shadow-2xs"
                    >
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      <span>Open Now</span>
                    </span>
                  ) : (
                    <span
                      id={`pharmacy-badge-closed-${pharmacy.id}`}
                      className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-extrabold bg-rose-100 text-rose-800 dark:bg-rose-950/70 dark:text-rose-300 border border-rose-300 dark:border-rose-700 shadow-2xs"
                    >
                      <span className="w-2 h-2 rounded-full bg-rose-500" />
                      <span>Closed</span>
                    </span>
                  )}
                </div>
              </div>

              {/* Operating Hours Card Section */}
              <div className="mt-3 pt-2.5 border-t border-slate-200/70 dark:border-slate-700/60">
                {/* Today's Hours Highlight + Next Timing Note */}
                <div className="flex items-center justify-between gap-2 flex-wrap text-xs">
                  <div className="flex items-center gap-1.5 font-medium text-coffee-bean dark:text-slate-200">
                    <Clock className="w-3.5 h-3.5 text-seaweed shrink-0" />
                    <span>
                      Today's Hours:{' '}
                      <strong className="text-coffee-bean dark:text-white font-bold">
                        {status.todayHoursText}
                      </strong>
                    </span>
                    <span className="text-coffee-bean-muted dark:text-slate-400 text-[11px]">
                      • {status.timingNote}
                    </span>
                  </div>

                  {/* Toggle to view all 7 days */}
                  <button
                    type="button"
                    onClick={(e) => toggleHoursExpand(pharmacy.id, e)}
                    className="text-[11px] font-bold text-seaweed dark:text-seaweed-light hover:underline inline-flex items-center gap-1 py-0.5 px-1.5 rounded-md hover:bg-white/60 dark:hover:bg-slate-700/60 cursor-pointer transition-colors"
                    aria-expanded={isExpanded}
                    aria-label={`Toggle weekly schedule for ${pharmacy.name}`}
                  >
                    <Calendar className="w-3 h-3 text-seaweed" />
                    <span>{isExpanded ? 'Hide Hours' : 'View Weekly Hours'}</span>
                    {isExpanded ? (
                      <ChevronUp className="w-3 h-3" />
                    ) : (
                      <ChevronDown className="w-3 h-3" />
                    )}
                  </button>
                </div>

                {/* Operating hours regular summary */}
                <div className="mt-1 text-[11px] text-coffee-bean-muted dark:text-slate-400 leading-tight">
                  <span className="font-semibold text-coffee-bean dark:text-slate-300">
                    Weekly Hours:
                  </span>{' '}
                  {status.summaryText}
                </div>

                {/* Full Expandable 7-Day Schedule Grid */}
                {isExpanded && (
                  <div className="mt-2.5 pt-2 border-t border-pale-sky/40 dark:border-slate-700">
                    <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-1.5 text-[11px]">
                      {status.weeklySchedule.map((day) => (
                        <div
                          key={day.dayName}
                          className={`p-2 rounded-xl flex flex-col justify-between transition-all ${
                            day.isToday
                              ? 'bg-seaweed-light dark:bg-seaweed-dark/40 text-seaweed-dark dark:text-seaweed-light font-bold border border-seaweed/40 ring-1 ring-seaweed/30'
                              : 'bg-white dark:bg-slate-800 text-coffee-bean dark:text-slate-300 border border-slate-200/80 dark:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between text-[10px] uppercase font-bold tracking-wider">
                            <span>{day.dayShort}</span>
                            {day.isToday && (
                              <span className="text-[9px] px-1 py-0.2 bg-seaweed text-white rounded font-extrabold normal-case">
                                Today
                              </span>
                            )}
                          </div>
                          <span
                            className={`mt-1 font-semibold text-[11px] leading-tight ${
                              day.isClosed
                                ? 'text-rose-600 dark:text-rose-400'
                                : 'text-coffee-bean dark:text-slate-200'
                            }`}
                          >
                            {day.hoursText}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Community Pharmacist Consultations Notice */}
      <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
        <div className="p-4 rounded-2xl bg-seaweed-light/40 dark:bg-seaweed-dark/20 border border-seaweed/30 text-xs sm:text-sm text-coffee-bean dark:text-slate-200 flex items-start gap-3">
          <Pill className="w-5 h-5 text-seaweed shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <strong className="block font-bold text-coffee-bean dark:text-slate-100 mb-0.5">
              Free Community Pharmacist Consultations & Support
            </strong>
            Local pharmacists can review your medications, explain dosage instructions, check for drug interactions, and help you find generic assistance programs at no extra cost. Bring your bottle or call the numbers listed above.
          </div>
        </div>
      </div>
    </div>
  );
};
