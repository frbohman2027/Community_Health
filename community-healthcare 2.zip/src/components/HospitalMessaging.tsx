import React, { useState } from 'react';
import {
  MessageSquare,
  Send,
  Building2,
  Clock,
  CheckCheck,
  User,
  ShieldAlert,
  Sparkles,
  HelpCircle,
} from 'lucide-react';
import { Hospital, HospitalMessage, LanguageCode } from '../types';
import { TRANSLATIONS } from '../utils/translations';

interface HospitalMessagingProps {
  lang: LanguageCode;
  selectedHospital?: Hospital;
  messages: HospitalMessage[];
  onSendMessage: (text: string, category: string) => void;
  selectedCountyName?: string;
  allHospitals?: Hospital[];
  onSelectHospital?: (id: string) => void;
}

export const HospitalMessaging: React.FC<HospitalMessagingProps> = ({
  messages,
  onSendMessage,
  selectedCountyName = 'Local Community',
}) => {
  const [inputText, setInputText] = useState('');
  const [category, setCategory] = useState('Assistance needed & health questions');
  const [, setQuickPromptSelected] = useState<string | null>(null);

  const categories = [
    'Assistance needed & health questions',
    'Community volunteer help request',
    'Medicaid in-home aide & family care question',
    'Free community clinic & financial assistance',
    'General question for community health volunteer',
  ];

  const quickPrompts = [
    'Can a volunteer check my blood pressure at home this week?',
    'How do I sign up to get paid by Medicaid to care for a family member?',
    'Where is the nearest free community clinic that does not charge fees?',
    'Can a student volunteer help me pick up my medicine from the local pharmacy?',
  ];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    onSendMessage(inputText.trim(), category);
    setInputText('');
    setQuickPromptSelected(null);
  };

  return (
    <div
      id="hospital-messaging-section"
      className="bg-white rounded-3xl border border-pale-sky/80 shadow-2xs p-5 sm:p-7"
    >
      <div className="flex items-center gap-3.5 mb-5 pb-3 border-b border-slate-100">
        <div className="w-10 h-10 rounded-2xl bg-seaweed-light text-seaweed border border-seaweed/30 flex items-center justify-center font-bold text-base shrink-0 shadow-2xs">
          7
        </div>
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-coffee-bean tracking-tight">
            Community Health & Volunteer Help Desk
          </h2>
          <p className="text-coffee-bean-muted text-xs sm:text-sm mt-0.5">
            Ask questions to local community health workers, nurses, and volunteers in {selectedCountyName}.
          </p>
        </div>
      </div>

      {/* Community Care Desk Banner */}
      <div className="mb-5 p-4 rounded-2xl bg-pale-sky-light/40 border border-pale-sky flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-seaweed-light text-seaweed flex items-center justify-center shrink-0 shadow-2xs">
            <Sparkles className="w-5 h-5 text-seaweed" />
          </div>
          <div>
            <span className="text-[11px] font-bold text-seaweed uppercase tracking-wider block">
              Sending question to:
            </span>
            <h3 className="font-bold text-sm sm:text-base text-coffee-bean">
              {selectedCountyName} Community Health & Volunteer Care Desk
            </h3>
            <p className="text-xs text-coffee-bean-muted mt-0.5">
              Coordinated with local community health workers, free clinics, and student volunteers
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 self-start md:self-auto">
          <div className="text-xs text-seaweed bg-seaweed-light border border-seaweed/20 px-3 py-1.5 rounded-xl shrink-0 font-medium flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            Volunteer Desk Active
          </div>
        </div>
      </div>

      {/* Message History Container */}
      <div className="border border-pale-sky/80 rounded-2xl bg-pale-sky-light/15 p-4 min-h-[150px] max-h-[340px] overflow-y-auto space-y-3 mb-4">
        {messages.length === 0 ? (
          <div className="text-center py-6 text-coffee-bean-muted">
            <MessageSquare className="w-8 h-8 mx-auto text-pale-sky mb-2" />
            <p className="font-semibold text-sm text-coffee-bean">No questions sent yet.</p>
            <p className="text-xs text-coffee-bean-muted mt-1 max-w-md mx-auto">
              Type your question below or click one of the quick suggestions to reach community health helpers.
            </p>
          </div>
        ) : (
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-3.5 sm:p-4 text-xs sm:text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-seaweed text-white rounded-br-xs shadow-2xs'
                    : 'bg-white border border-pale-sky text-coffee-bean rounded-bl-xs shadow-2xs'
                }`}
              >
                <div className="flex items-center gap-2 mb-1 text-[11px] opacity-85">
                  {msg.sender === 'user' ? (
                    <>
                      <User className="w-3 h-3" />
                      <span className="font-semibold">You</span>
                      {msg.category && <span>• {msg.category}</span>}
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3 h-3 text-seaweed" />
                      <span className="font-bold text-seaweed">Community Health Team</span>
                    </>
                  )}
                  <span className="ml-auto">{msg.timestamp}</span>
                </div>
                <p className="whitespace-pre-line">{msg.text}</p>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Quick question suggestions */}
      <div className="mb-4">
        <span className="block text-xs font-bold text-coffee-bean-muted mb-2 uppercase tracking-wide">
          Quick Question Suggestions:
        </span>
        <div className="flex flex-wrap gap-1.5">
          {quickPrompts.map((q, i) => (
            <button
              key={i}
              type="button"
              onClick={() => {
                setInputText(q);
                setQuickPromptSelected(q);
              }}
              className="text-xs px-3 py-1.5 rounded-xl border border-pale-sky bg-white text-coffee-bean hover:bg-seaweed-light/40 hover:text-seaweed-dark hover:border-seaweed text-left transition-colors cursor-pointer shadow-2xs"
            >
              "{q}"
            </button>
          ))}
        </div>
      </div>

      {/* Form to compose a message */}
      <form onSubmit={handleSend} className="space-y-3">
        <div>
          <label
            htmlFor="message-category-select"
            className="block text-xs sm:text-sm font-bold text-coffee-bean mb-1"
          >
            What is your question about?
          </label>
          <select
            id="message-category-select"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full text-xs sm:text-sm p-2.5 rounded-xl border border-pale-sky bg-white text-coffee-bean focus:outline-none focus:ring-2 focus:ring-seaweed/20 focus:border-seaweed shadow-2xs"
          >
            {categories.map((c, i) => (
              <option key={i} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label
            htmlFor="message-text-input"
            className="block text-xs sm:text-sm font-bold text-coffee-bean mb-1"
          >
            Type your message here:
          </label>
          <textarea
            id="message-text-input"
            rows={3}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Example: Can a volunteer visit my father to check his blood pressure? How do we sign up for Medicaid family caregiving?"
            className="w-full text-xs sm:text-sm p-3.5 rounded-2xl border border-pale-sky bg-white text-coffee-bean placeholder:text-coffee-bean-muted/60 focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20 shadow-2xs transition-all"
          />
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
          <p className="text-xs text-coffee-bean-muted leading-normal order-2 sm:order-1">
            For medical emergencies, call 911 immediately. Community health volunteers and nurses reply during daytime hours.
          </p>
          <button
            id="send-hospital-message-btn"
            type="submit"
            disabled={!inputText.trim()}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-seaweed hover:bg-seaweed-dark disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-xs sm:text-sm rounded-xl shadow-2xs transition-colors order-1 sm:order-2 shrink-0 cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Send Message to Community Desk</span>
          </button>
        </div>
      </form>
    </div>
  );
};
