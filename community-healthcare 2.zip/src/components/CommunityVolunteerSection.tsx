import React, { useState } from 'react';
import {
  Heart,
  Award,
  Users,
  GraduationCap,
  Clock,
  CheckCircle2,
  Phone,
  Send,
  Sparkles,
  MapPin,
  Calendar,
  AlertCircle,
  FileCheck,
  Stethoscope,
  BookOpen,
  Lock,
  ShieldAlert,
} from 'lucide-react';
import { LanguageCode, StateCode, CommunityVolunteer, CommunityHelpRequest } from '../types';
import { INITIAL_COMMUNITY_VOLUNTEERS, INITIAL_HELP_REQUESTS } from '../data/communityVolunteersData';

interface CommunityVolunteerSectionProps {
  lang: LanguageCode;
  countyName: string;
  state: StateCode;
  isCaseManager?: boolean;
}

export const CommunityVolunteerSection: React.FC<CommunityVolunteerSectionProps> = ({
  countyName,
  state,
  isCaseManager = false,
}) => {
  const [volunteers, setVolunteers] = useState<CommunityVolunteer[]>(INITIAL_COMMUNITY_VOLUNTEERS);
  const [helpRequests, setHelpRequests] = useState<CommunityHelpRequest[]>(INITIAL_HELP_REQUESTS);

  // New Volunteer Registration State
  const [volName, setVolName] = useState('');
  const [roleOrStudy, setRoleOrStudy] = useState('Nursing Student (BSN)');
  const [school, setSchool] = useState('');
  const [phone, setPhone] = useState('');
  const [selectedServices, setSelectedServices] = useState<string[]>([
    'Blood Pressure & Vital Signs Checks',
    'Companionship & Friendly Check-ins',
    'Prescription & Grocery Pickup',
  ]);
  const [hoursOffered, setHoursOffered] = useState('2-4 hours / week');
  const [bio, setBio] = useState('');
  const [registrationSuccess, setRegistrationSuccess] = useState<CommunityVolunteer | null>(null);

  // Accepted Help Request State
  const [acceptedReqId, setAcceptedReqId] = useState<string | null>(null);

  const toggleService = (svc: string) => {
    setSelectedServices((prev) =>
      prev.includes(svc) ? prev.filter((s) => s !== svc) : [...prev, svc]
    );
  };

  const handleRegisterVolunteer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!volName.trim() || !phone.trim()) return;

    const newVol: CommunityVolunteer = {
      id: `vol-${Date.now()}`,
      name: volName.trim(),
      roleOrStudy,
      schoolOrOrg: school.trim() || 'Community Independent Volunteer',
      county: countyName,
      state,
      hoursVolunteered: 0,
      verifiedHours: true,
      servicesOffered: selectedServices,
      contactPhone: phone.trim(),
      availability: hoursOffered,
      bio: bio.trim() || 'Eager to support local neighbors and gain valuable hands-on community healthcare experience.',
    };

    setVolunteers((prev) => [newVol, ...prev]);
    setRegistrationSuccess(newVol);
    setVolName('');
    setSchool('');
    setPhone('');
    setBio('');
  };

  const handleAcceptRequest = (reqId: string) => {
    setAcceptedReqId(reqId);
    setHelpRequests((prev) =>
      prev.map((r) =>
        r.id === reqId ? { ...r, volunteersAssigned: r.volunteersAssigned + 1 } : r
      )
    );
  };

  return (
    <section
      id="community-volunteers-section"
      className="bg-white rounded-3xl border-2 border-seaweed/30 shadow-sm p-5 sm:p-7 space-y-6 scroll-mt-24"
    >
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div className="flex items-start gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-seaweed text-white flex items-center justify-center shrink-0 shadow-2xs font-bold text-lg">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <span className="px-2.5 py-0.5 rounded-full bg-seaweed-light text-seaweed-dark font-extrabold text-[11px] uppercase tracking-wider border border-seaweed/30 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-seaweed" />
                Community Experience Network
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-purple-100 text-purple-800 font-bold text-[11px] border border-purple-200">
                Verified Clinical & Volunteer Hours
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-coffee-bean tracking-tight">
              Interested in Helping Community Members for Experience?
            </h2>
            <p className="text-coffee-bean-muted text-xs sm:text-sm mt-0.5 max-w-2xl leading-relaxed">
              Designed for nursing students, pre-meds, health science majors, EMT trainees, and
              caring community members. Gain real-world patient interaction hours, letters of
              recommendation, and volunteer certificates by assisting neighbors with everyday health
              needs.
            </p>
          </div>
        </div>

        {/* Benefits Card */}
        <div className="bg-pale-sky-light/40 border border-pale-sky rounded-2xl p-3.5 text-xs text-coffee-bean space-y-1.5 shrink-0 max-w-xs shadow-2xs">
          <div className="font-bold flex items-center gap-1.5 text-seaweed">
            <Award className="w-4 h-4 text-seaweed" />
            <span>Why Volunteer Here?</span>
          </div>
          <ul className="text-[11px] text-coffee-bean-muted space-y-1">
            <li className="flex items-center gap-1">✓ Verified log of clinical/shadowing hours</li>
            <li className="flex items-center gap-1">✓ Reference letters for school applications</li>
            <li className="flex items-center gap-1">✓ 1-on-1 vital checks & companion care practice</li>
          </ul>
        </div>
      </div>

      {/* Grid: Open Community Requests + Active Volunteers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: Open Community Member Requests */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-base text-coffee-bean flex items-center gap-2">
              <Users className="w-4 h-4 text-seaweed" />
              <span>Open Help Requests in {countyName} ({helpRequests.length})</span>
            </h3>
            <span className="text-xs text-coffee-bean-muted">Neighbors in need</span>
          </div>

          <div className="space-y-3">
            {helpRequests.map((req) => {
              const isAccepted = acceptedReqId === req.id;

              return (
                <div
                  key={req.id}
                  className="p-4 rounded-2xl border border-pale-sky/80 bg-white hover:border-seaweed/50 transition-all shadow-2xs space-y-2.5"
                >
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="font-bold text-xs sm:text-sm text-coffee-bean leading-snug">
                      {req.title}
                    </h4>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${
                        req.urgency === 'immediate'
                          ? 'bg-rose-100 text-rose-700 border border-rose-200'
                          : req.urgency === 'this_week'
                          ? 'bg-amber-100 text-amber-800 border border-amber-200'
                          : 'bg-slate-100 text-slate-700 border border-slate-200'
                      }`}
                    >
                      {req.urgency === 'immediate'
                        ? 'Urgent'
                        : req.urgency === 'this_week'
                        ? 'This Week'
                        : 'Flexible'}
                    </span>
                  </div>

                  <p className="text-xs text-coffee-bean-muted leading-relaxed">
                    {req.description}
                  </p>

                  <div className="flex items-center justify-between text-[11px] pt-2 border-t border-slate-100">
                    <span className="text-coffee-bean-muted">
                      📍 {req.county} • Posted {req.postedDate}
                    </span>

                    {isAccepted ? (
                      <span className="font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Accepted! Check in details sent</span>
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleAcceptRequest(req.id)}
                        className="font-bold text-xs px-3 py-1.5 rounded-xl bg-seaweed hover:bg-seaweed-hover text-white transition-colors cursor-pointer shadow-2xs active:scale-95"
                      >
                        Offer Help for Experience
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Community Volunteer Roster */}
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <h3 className="font-bold text-base text-coffee-bean flex items-center gap-2">
              <Stethoscope className="w-4 h-4 text-seaweed" />
              <span>Current Volunteer Helpers ({volunteers.length})</span>
            </h3>
            <span
              className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1 ${
                isCaseManager
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-slate-100 text-slate-600 border border-slate-200'
              }`}
            >
              <Lock className="w-3 h-3" />
              {isCaseManager ? 'Case Manager View: Unlocked' : 'Personal Info Protected'}
            </span>
          </div>

          {!isCaseManager && (
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-coffee-bean-muted flex items-start gap-2">
              <Lock className="w-3.5 h-3.5 text-seaweed shrink-0 mt-0.5" />
              <span>
                <strong>Confidentiality Notice:</strong> People’s personal names and direct phone numbers are only available to verified Case Manager accounts. Volunteer sign-ups and matching are handled securely.
              </span>
            </div>
          )}

          <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
            {volunteers.map((vol, idx) => (
              <div
                key={vol.id}
                className="p-4 rounded-2xl border border-pale-sky/70 bg-slate-50/60 hover:bg-white transition-all shadow-2xs space-y-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-sm text-coffee-bean">
                        {isCaseManager ? vol.name : `Community Volunteer #${idx + 1}`}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-100 text-purple-800 border border-purple-200">
                        {vol.roleOrStudy}
                      </span>
                    </div>
                    {vol.schoolOrOrg && (
                      <p className="text-[11px] text-coffee-bean-muted mt-0.5">
                        {vol.schoolOrOrg} • {vol.county}
                      </p>
                    )}
                  </div>

                  <div className="text-right shrink-0">
                    <span className="inline-block text-[11px] font-bold text-seaweed bg-seaweed-light px-2 py-0.5 rounded-md border border-seaweed/30">
                      {vol.hoursVolunteered} hrs completed
                    </span>
                  </div>
                </div>

                <p className="text-xs text-coffee-bean-muted leading-relaxed">{vol.bio}</p>

                <div className="flex flex-wrap gap-1 pt-1">
                  {vol.servicesOffered.map((svc, sIdx) => (
                    <span
                      key={sIdx}
                      className="text-[10px] px-2 py-0.5 rounded bg-white text-coffee-bean border border-slate-200 font-medium"
                    >
                      ✓ {svc}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between text-[11px] pt-2 border-t border-slate-200/60 text-coffee-bean-muted">
                  <span>⏰ {vol.availability}</span>
                  {isCaseManager ? (
                    <a
                      href={`tel:${vol.contactPhone}`}
                      className="font-bold text-seaweed hover:underline flex items-center gap-1"
                    >
                      <Phone className="w-3 h-3" />
                      <span>{vol.contactPhone}</span>
                    </a>
                  ) : (
                    <span className="text-slate-400 font-medium flex items-center gap-1">
                      <Lock className="w-3 h-3 text-slate-400" />
                      <span>Contact Protected (Case Manager Only)</span>
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Volunteer Registration Form */}
      <div className="pt-6 border-t border-slate-100">
        <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-pale-sky-light/40 via-white to-seaweed-light/30 border border-pale-sky shadow-2xs space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="text-base sm:text-lg font-bold text-coffee-bean flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-seaweed" />
                <span>Sign Up to Help Community Members for Experience</span>
              </h3>
              <p className="text-xs text-coffee-bean-muted mt-0.5">
                Join our free community healthcare network. We connect you with local residents who need companionship, vital checks, and errand help.
              </p>
            </div>
            <span className="px-3 py-1 rounded-full bg-seaweed text-white text-xs font-bold shadow-2xs">
              Fast 2-Minute Sign Up
            </span>
          </div>

          {registrationSuccess && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-950 space-y-1.5 text-xs sm:text-sm">
              <div className="font-bold text-emerald-900 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <span>Welcome to the Network, {registrationSuccess.name}!</span>
              </div>
              <p>
                Your helper profile has been added to the community directory. A verification
                packet has been generated so your hours can be tracked for academic credit and
                recommendation letters.
              </p>
            </div>
          )}

          <form onSubmit={handleRegisterVolunteer} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-coffee-bean mb-1">
                  Your Full Name: *
                </label>
                <input
                  type="text"
                  required
                  value={volName}
                  onChange={(e) => setVolName(e.target.value)}
                  placeholder="e.g. Jordan Taylor"
                  className="w-full text-xs sm:text-sm p-3 rounded-xl border border-pale-sky bg-white text-coffee-bean focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-coffee-bean mb-1">
                  Field of Study or Role: *
                </label>
                <select
                  value={roleOrStudy}
                  onChange={(e) => setRoleOrStudy(e.target.value)}
                  className="w-full text-xs sm:text-sm p-3 rounded-xl border border-pale-sky bg-white text-coffee-bean focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20"
                >
                  <option>Nursing Student (BSN / ASN)</option>
                  <option>Pre-Med Student</option>
                  <option>Physical / Occupational Therapy Student</option>
                  <option>Public Health / Social Work Major</option>
                  <option>EMT / Paramedic Trainee</option>
                  <option>Retired Healthcare Professional</option>
                  <option>General Caring Community Member</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-coffee-bean mb-1">
                  School or Organization (Optional):
                </label>
                <input
                  type="text"
                  value={school}
                  onChange={(e) => setSchool(e.target.value)}
                  placeholder="e.g. Local Community College"
                  className="w-full text-xs sm:text-sm p-3 rounded-xl border border-pale-sky bg-white text-coffee-bean focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-coffee-bean mb-1">
                  Contact Phone Number: *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="(e.g. 812-555-0144)"
                  className="w-full text-xs sm:text-sm p-3 rounded-xl border border-pale-sky bg-white text-coffee-bean focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-coffee-bean mb-1">
                  Available Hours per Week:
                </label>
                <select
                  value={hoursOffered}
                  onChange={(e) => setHoursOffered(e.target.value)}
                  className="w-full text-xs sm:text-sm p-3 rounded-xl border border-pale-sky bg-white text-coffee-bean focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20"
                >
                  <option>1 – 2 hours / week</option>
                  <option>2 – 4 hours / week</option>
                  <option>5 – 8 hours / week</option>
                  <option>Flexible / Weekends only</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-coffee-bean mb-1">
                  County where you can help:
                </label>
                <input
                  type="text"
                  readOnly
                  value={`${countyName}, ${state}`}
                  className="w-full text-xs sm:text-sm p-3 rounded-xl border border-slate-200 bg-slate-100 text-coffee-bean font-semibold cursor-not-allowed"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-coffee-bean mb-1.5">
                Services you can help with:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 text-xs">
                {[
                  'Blood Pressure & Vital Signs Checks',
                  'Companionship & Friendly Check-ins',
                  'Prescription & Grocery Pickup',
                  'Food Pantry & Meals on Wheels Delivery',
                  'Health Education & Pillbox Sorting',
                  'Family Caregiver Respite Relief',
                ].map((svc) => (
                  <label
                    key={svc}
                    className={`flex items-center gap-2 p-2.5 rounded-xl border transition-all cursor-pointer ${
                      selectedServices.includes(svc)
                        ? 'bg-seaweed-light/60 border-seaweed text-seaweed-dark font-semibold'
                        : 'bg-white border-slate-200 text-coffee-bean hover:bg-slate-50'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={selectedServices.includes(svc)}
                      onChange={() => toggleService(svc)}
                      className="w-4 h-4 text-seaweed rounded focus:ring-seaweed border-slate-300"
                    />
                    <span>{svc}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-coffee-bean mb-1">
                Short Bio or Why you want experience (Optional):
              </label>
              <textarea
                rows={2}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Share a sentence or two about your study goals, patient care interest, or why you want to help neighbors..."
                className="w-full text-xs sm:text-sm p-3 rounded-xl border border-pale-sky bg-white text-coffee-bean focus:border-seaweed focus:outline-none focus:ring-2 focus:ring-seaweed/20"
              />
            </div>

            <div className="flex items-center justify-between flex-wrap gap-3 pt-2">
              <button
                type="submit"
                id="register-community-helper-btn"
                className="px-6 py-3 rounded-xl bg-seaweed hover:bg-seaweed-hover text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-2xs transition-all cursor-pointer active:scale-98"
              >
                <GraduationCap className="w-4 h-4" />
                <span>Register to Help for Experience</span>
              </button>

              <p className="text-[11px] text-coffee-bean-muted max-w-md">
                All volunteers agree to confidentiality standards and compassionate care for neighbors.
              </p>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};
